<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-03 20:19:25 --> Config Class Initialized
INFO - 2017-02-03 20:19:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:19:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:19:26 --> Utf8 Class Initialized
INFO - 2017-02-03 20:19:26 --> URI Class Initialized
DEBUG - 2017-02-03 20:19:26 --> No URI present. Default controller set.
INFO - 2017-02-03 20:19:26 --> Router Class Initialized
INFO - 2017-02-03 20:19:26 --> Output Class Initialized
INFO - 2017-02-03 20:19:26 --> Security Class Initialized
DEBUG - 2017-02-03 20:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:19:26 --> Input Class Initialized
INFO - 2017-02-03 20:19:26 --> Language Class Initialized
INFO - 2017-02-03 20:19:26 --> Language Class Initialized
INFO - 2017-02-03 20:19:26 --> Config Class Initialized
INFO - 2017-02-03 20:19:26 --> Loader Class Initialized
INFO - 2017-02-03 20:19:26 --> Controller Class Initialized
DEBUG - 2017-02-03 20:19:26 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:19:26 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:19:26 --> Final output sent to browser
DEBUG - 2017-02-03 20:19:26 --> Total execution time: 0.2938
INFO - 2017-02-03 20:23:22 --> Config Class Initialized
INFO - 2017-02-03 20:23:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:23:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:23:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:23:22 --> URI Class Initialized
DEBUG - 2017-02-03 20:23:22 --> No URI present. Default controller set.
INFO - 2017-02-03 20:23:22 --> Router Class Initialized
INFO - 2017-02-03 20:23:22 --> Output Class Initialized
INFO - 2017-02-03 20:23:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:23:22 --> Input Class Initialized
INFO - 2017-02-03 20:23:22 --> Language Class Initialized
INFO - 2017-02-03 20:23:22 --> Language Class Initialized
INFO - 2017-02-03 20:23:22 --> Config Class Initialized
INFO - 2017-02-03 20:23:22 --> Loader Class Initialized
INFO - 2017-02-03 20:23:22 --> Model Class Initialized
ERROR - 2017-02-03 20:23:22 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:23:24 --> Config Class Initialized
INFO - 2017-02-03 20:23:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:23:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:23:24 --> Utf8 Class Initialized
INFO - 2017-02-03 20:23:24 --> URI Class Initialized
DEBUG - 2017-02-03 20:23:24 --> No URI present. Default controller set.
INFO - 2017-02-03 20:23:24 --> Router Class Initialized
INFO - 2017-02-03 20:23:24 --> Output Class Initialized
INFO - 2017-02-03 20:23:24 --> Security Class Initialized
DEBUG - 2017-02-03 20:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:23:24 --> Input Class Initialized
INFO - 2017-02-03 20:23:24 --> Language Class Initialized
INFO - 2017-02-03 20:23:24 --> Language Class Initialized
INFO - 2017-02-03 20:23:24 --> Config Class Initialized
INFO - 2017-02-03 20:23:24 --> Loader Class Initialized
INFO - 2017-02-03 20:23:24 --> Model Class Initialized
ERROR - 2017-02-03 20:23:24 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:24:47 --> Config Class Initialized
INFO - 2017-02-03 20:24:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:24:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:24:47 --> Utf8 Class Initialized
INFO - 2017-02-03 20:24:47 --> URI Class Initialized
DEBUG - 2017-02-03 20:24:47 --> No URI present. Default controller set.
INFO - 2017-02-03 20:24:47 --> Router Class Initialized
INFO - 2017-02-03 20:24:47 --> Output Class Initialized
INFO - 2017-02-03 20:24:47 --> Security Class Initialized
DEBUG - 2017-02-03 20:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:24:47 --> Input Class Initialized
INFO - 2017-02-03 20:24:47 --> Language Class Initialized
INFO - 2017-02-03 20:24:47 --> Language Class Initialized
INFO - 2017-02-03 20:24:47 --> Config Class Initialized
INFO - 2017-02-03 20:24:47 --> Loader Class Initialized
INFO - 2017-02-03 20:24:47 --> Model Class Initialized
ERROR - 2017-02-03 20:24:47 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:24:48 --> Config Class Initialized
INFO - 2017-02-03 20:24:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:24:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:24:48 --> Utf8 Class Initialized
INFO - 2017-02-03 20:24:48 --> URI Class Initialized
DEBUG - 2017-02-03 20:24:48 --> No URI present. Default controller set.
INFO - 2017-02-03 20:24:48 --> Router Class Initialized
INFO - 2017-02-03 20:24:48 --> Output Class Initialized
INFO - 2017-02-03 20:24:48 --> Security Class Initialized
DEBUG - 2017-02-03 20:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:24:48 --> Input Class Initialized
INFO - 2017-02-03 20:24:48 --> Language Class Initialized
INFO - 2017-02-03 20:24:48 --> Language Class Initialized
INFO - 2017-02-03 20:24:48 --> Config Class Initialized
INFO - 2017-02-03 20:24:48 --> Loader Class Initialized
INFO - 2017-02-03 20:24:48 --> Model Class Initialized
ERROR - 2017-02-03 20:24:48 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:24:48 --> Config Class Initialized
INFO - 2017-02-03 20:24:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:24:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:24:48 --> Utf8 Class Initialized
INFO - 2017-02-03 20:24:48 --> URI Class Initialized
DEBUG - 2017-02-03 20:24:48 --> No URI present. Default controller set.
INFO - 2017-02-03 20:24:48 --> Router Class Initialized
INFO - 2017-02-03 20:24:48 --> Output Class Initialized
INFO - 2017-02-03 20:24:48 --> Security Class Initialized
DEBUG - 2017-02-03 20:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:24:48 --> Input Class Initialized
INFO - 2017-02-03 20:24:48 --> Language Class Initialized
INFO - 2017-02-03 20:24:48 --> Language Class Initialized
INFO - 2017-02-03 20:24:48 --> Config Class Initialized
INFO - 2017-02-03 20:24:48 --> Loader Class Initialized
INFO - 2017-02-03 20:24:48 --> Model Class Initialized
ERROR - 2017-02-03 20:24:48 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:24:48 --> Config Class Initialized
INFO - 2017-02-03 20:24:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:24:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:24:48 --> Utf8 Class Initialized
INFO - 2017-02-03 20:24:48 --> URI Class Initialized
DEBUG - 2017-02-03 20:24:48 --> No URI present. Default controller set.
INFO - 2017-02-03 20:24:48 --> Router Class Initialized
INFO - 2017-02-03 20:24:48 --> Output Class Initialized
INFO - 2017-02-03 20:24:48 --> Security Class Initialized
DEBUG - 2017-02-03 20:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:24:48 --> Input Class Initialized
INFO - 2017-02-03 20:24:48 --> Language Class Initialized
INFO - 2017-02-03 20:24:48 --> Language Class Initialized
INFO - 2017-02-03 20:24:48 --> Config Class Initialized
INFO - 2017-02-03 20:24:48 --> Loader Class Initialized
INFO - 2017-02-03 20:24:48 --> Model Class Initialized
ERROR - 2017-02-03 20:24:48 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:24:49 --> Config Class Initialized
INFO - 2017-02-03 20:24:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:24:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:24:49 --> Utf8 Class Initialized
INFO - 2017-02-03 20:24:49 --> URI Class Initialized
DEBUG - 2017-02-03 20:24:49 --> No URI present. Default controller set.
INFO - 2017-02-03 20:24:49 --> Router Class Initialized
INFO - 2017-02-03 20:24:49 --> Output Class Initialized
INFO - 2017-02-03 20:24:49 --> Security Class Initialized
DEBUG - 2017-02-03 20:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:24:49 --> Input Class Initialized
INFO - 2017-02-03 20:24:49 --> Language Class Initialized
INFO - 2017-02-03 20:24:49 --> Language Class Initialized
INFO - 2017-02-03 20:24:49 --> Config Class Initialized
INFO - 2017-02-03 20:24:49 --> Loader Class Initialized
INFO - 2017-02-03 20:24:49 --> Model Class Initialized
ERROR - 2017-02-03 20:24:49 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:24:49 --> Config Class Initialized
INFO - 2017-02-03 20:24:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:24:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:24:49 --> Utf8 Class Initialized
INFO - 2017-02-03 20:24:49 --> URI Class Initialized
DEBUG - 2017-02-03 20:24:49 --> No URI present. Default controller set.
INFO - 2017-02-03 20:24:49 --> Router Class Initialized
INFO - 2017-02-03 20:24:49 --> Output Class Initialized
INFO - 2017-02-03 20:24:49 --> Security Class Initialized
DEBUG - 2017-02-03 20:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:24:49 --> Input Class Initialized
INFO - 2017-02-03 20:24:49 --> Language Class Initialized
INFO - 2017-02-03 20:24:49 --> Language Class Initialized
INFO - 2017-02-03 20:24:49 --> Config Class Initialized
INFO - 2017-02-03 20:24:49 --> Loader Class Initialized
INFO - 2017-02-03 20:24:49 --> Model Class Initialized
ERROR - 2017-02-03 20:24:49 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:26:30 --> Config Class Initialized
INFO - 2017-02-03 20:26:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:26:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:26:30 --> Utf8 Class Initialized
INFO - 2017-02-03 20:26:30 --> URI Class Initialized
DEBUG - 2017-02-03 20:26:30 --> No URI present. Default controller set.
INFO - 2017-02-03 20:26:30 --> Router Class Initialized
INFO - 2017-02-03 20:26:30 --> Output Class Initialized
INFO - 2017-02-03 20:26:30 --> Security Class Initialized
DEBUG - 2017-02-03 20:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:26:30 --> Input Class Initialized
INFO - 2017-02-03 20:26:30 --> Language Class Initialized
INFO - 2017-02-03 20:26:30 --> Language Class Initialized
INFO - 2017-02-03 20:26:30 --> Config Class Initialized
INFO - 2017-02-03 20:26:30 --> Loader Class Initialized
INFO - 2017-02-03 20:26:30 --> Model Class Initialized
ERROR - 2017-02-03 20:26:30 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:26:32 --> Config Class Initialized
INFO - 2017-02-03 20:26:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:26:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:26:32 --> Utf8 Class Initialized
INFO - 2017-02-03 20:26:32 --> URI Class Initialized
DEBUG - 2017-02-03 20:26:32 --> No URI present. Default controller set.
INFO - 2017-02-03 20:26:32 --> Router Class Initialized
INFO - 2017-02-03 20:26:32 --> Output Class Initialized
INFO - 2017-02-03 20:26:32 --> Security Class Initialized
DEBUG - 2017-02-03 20:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:26:32 --> Input Class Initialized
INFO - 2017-02-03 20:26:32 --> Language Class Initialized
INFO - 2017-02-03 20:26:32 --> Language Class Initialized
INFO - 2017-02-03 20:26:32 --> Config Class Initialized
INFO - 2017-02-03 20:26:32 --> Loader Class Initialized
INFO - 2017-02-03 20:26:32 --> Model Class Initialized
ERROR - 2017-02-03 20:26:32 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:25 --> Config Class Initialized
INFO - 2017-02-03 20:27:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:25 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:25 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:25 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:25 --> Router Class Initialized
INFO - 2017-02-03 20:27:25 --> Output Class Initialized
INFO - 2017-02-03 20:27:25 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:25 --> Input Class Initialized
INFO - 2017-02-03 20:27:25 --> Language Class Initialized
INFO - 2017-02-03 20:27:25 --> Language Class Initialized
INFO - 2017-02-03 20:27:25 --> Config Class Initialized
INFO - 2017-02-03 20:27:25 --> Loader Class Initialized
INFO - 2017-02-03 20:27:25 --> Model Class Initialized
ERROR - 2017-02-03 20:27:25 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:26 --> Config Class Initialized
INFO - 2017-02-03 20:27:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:26 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:26 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:26 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:26 --> Router Class Initialized
INFO - 2017-02-03 20:27:26 --> Output Class Initialized
INFO - 2017-02-03 20:27:26 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:26 --> Input Class Initialized
INFO - 2017-02-03 20:27:26 --> Language Class Initialized
INFO - 2017-02-03 20:27:26 --> Language Class Initialized
INFO - 2017-02-03 20:27:26 --> Config Class Initialized
INFO - 2017-02-03 20:27:26 --> Loader Class Initialized
INFO - 2017-02-03 20:27:26 --> Model Class Initialized
ERROR - 2017-02-03 20:27:26 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:27 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:27 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:27 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:27 --> Router Class Initialized
INFO - 2017-02-03 20:27:27 --> Output Class Initialized
INFO - 2017-02-03 20:27:27 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:27 --> Input Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Loader Class Initialized
INFO - 2017-02-03 20:27:27 --> Model Class Initialized
ERROR - 2017-02-03 20:27:27 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:27 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:27 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:27 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:27 --> Router Class Initialized
INFO - 2017-02-03 20:27:27 --> Output Class Initialized
INFO - 2017-02-03 20:27:27 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:27 --> Input Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Loader Class Initialized
INFO - 2017-02-03 20:27:27 --> Model Class Initialized
ERROR - 2017-02-03 20:27:27 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:27 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:27 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:27 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:27 --> Router Class Initialized
INFO - 2017-02-03 20:27:27 --> Output Class Initialized
INFO - 2017-02-03 20:27:27 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:27 --> Input Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Loader Class Initialized
INFO - 2017-02-03 20:27:27 --> Model Class Initialized
ERROR - 2017-02-03 20:27:27 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:27 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:27 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:27 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:27 --> Router Class Initialized
INFO - 2017-02-03 20:27:27 --> Output Class Initialized
INFO - 2017-02-03 20:27:27 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:27 --> Input Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Loader Class Initialized
INFO - 2017-02-03 20:27:27 --> Model Class Initialized
ERROR - 2017-02-03 20:27:27 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:27 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:27 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:27 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:27 --> Router Class Initialized
INFO - 2017-02-03 20:27:27 --> Output Class Initialized
INFO - 2017-02-03 20:27:27 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:27 --> Input Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Language Class Initialized
INFO - 2017-02-03 20:27:27 --> Config Class Initialized
INFO - 2017-02-03 20:27:27 --> Loader Class Initialized
INFO - 2017-02-03 20:27:27 --> Model Class Initialized
ERROR - 2017-02-03 20:27:27 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:28 --> Config Class Initialized
INFO - 2017-02-03 20:27:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:28 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:28 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:28 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:28 --> Router Class Initialized
INFO - 2017-02-03 20:27:28 --> Output Class Initialized
INFO - 2017-02-03 20:27:28 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:28 --> Input Class Initialized
INFO - 2017-02-03 20:27:28 --> Language Class Initialized
INFO - 2017-02-03 20:27:28 --> Language Class Initialized
INFO - 2017-02-03 20:27:28 --> Config Class Initialized
INFO - 2017-02-03 20:27:28 --> Loader Class Initialized
INFO - 2017-02-03 20:27:28 --> Model Class Initialized
ERROR - 2017-02-03 20:27:28 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:27:28 --> Config Class Initialized
INFO - 2017-02-03 20:27:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:27:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:27:28 --> Utf8 Class Initialized
INFO - 2017-02-03 20:27:28 --> URI Class Initialized
DEBUG - 2017-02-03 20:27:28 --> No URI present. Default controller set.
INFO - 2017-02-03 20:27:28 --> Router Class Initialized
INFO - 2017-02-03 20:27:28 --> Output Class Initialized
INFO - 2017-02-03 20:27:28 --> Security Class Initialized
DEBUG - 2017-02-03 20:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:27:28 --> Input Class Initialized
INFO - 2017-02-03 20:27:28 --> Language Class Initialized
INFO - 2017-02-03 20:27:28 --> Language Class Initialized
INFO - 2017-02-03 20:27:28 --> Config Class Initialized
INFO - 2017-02-03 20:27:28 --> Loader Class Initialized
INFO - 2017-02-03 20:27:28 --> Model Class Initialized
ERROR - 2017-02-03 20:27:28 --> Severity: Error --> Class 'Core' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:28:02 --> Config Class Initialized
INFO - 2017-02-03 20:28:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:28:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:28:02 --> Utf8 Class Initialized
INFO - 2017-02-03 20:28:02 --> URI Class Initialized
DEBUG - 2017-02-03 20:28:02 --> No URI present. Default controller set.
INFO - 2017-02-03 20:28:02 --> Router Class Initialized
INFO - 2017-02-03 20:28:02 --> Output Class Initialized
INFO - 2017-02-03 20:28:02 --> Security Class Initialized
DEBUG - 2017-02-03 20:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:28:02 --> Input Class Initialized
INFO - 2017-02-03 20:28:02 --> Language Class Initialized
INFO - 2017-02-03 20:28:02 --> Language Class Initialized
INFO - 2017-02-03 20:28:02 --> Config Class Initialized
INFO - 2017-02-03 20:28:02 --> Loader Class Initialized
INFO - 2017-02-03 20:28:02 --> Model Class Initialized
ERROR - 2017-02-03 20:28:02 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:28:46 --> Config Class Initialized
INFO - 2017-02-03 20:28:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:28:46 --> Utf8 Class Initialized
INFO - 2017-02-03 20:28:46 --> URI Class Initialized
DEBUG - 2017-02-03 20:28:46 --> No URI present. Default controller set.
INFO - 2017-02-03 20:28:46 --> Router Class Initialized
INFO - 2017-02-03 20:28:46 --> Output Class Initialized
INFO - 2017-02-03 20:28:46 --> Security Class Initialized
DEBUG - 2017-02-03 20:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:28:46 --> Input Class Initialized
INFO - 2017-02-03 20:28:46 --> Language Class Initialized
INFO - 2017-02-03 20:28:46 --> Language Class Initialized
INFO - 2017-02-03 20:28:46 --> Config Class Initialized
INFO - 2017-02-03 20:28:46 --> Loader Class Initialized
INFO - 2017-02-03 20:28:46 --> Controller Class Initialized
DEBUG - 2017-02-03 20:28:46 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:28:46 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:28:46 --> Final output sent to browser
DEBUG - 2017-02-03 20:28:46 --> Total execution time: 0.0027
INFO - 2017-02-03 20:28:50 --> Config Class Initialized
INFO - 2017-02-03 20:28:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:28:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:28:50 --> Utf8 Class Initialized
INFO - 2017-02-03 20:28:50 --> URI Class Initialized
INFO - 2017-02-03 20:28:50 --> Router Class Initialized
INFO - 2017-02-03 20:28:50 --> Output Class Initialized
INFO - 2017-02-03 20:28:50 --> Security Class Initialized
DEBUG - 2017-02-03 20:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:28:50 --> Input Class Initialized
INFO - 2017-02-03 20:28:50 --> Language Class Initialized
ERROR - 2017-02-03 20:28:50 --> 404 Page Not Found: /index
INFO - 2017-02-03 20:29:36 --> Config Class Initialized
INFO - 2017-02-03 20:29:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:29:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:29:36 --> Utf8 Class Initialized
INFO - 2017-02-03 20:29:36 --> URI Class Initialized
DEBUG - 2017-02-03 20:29:36 --> No URI present. Default controller set.
INFO - 2017-02-03 20:29:36 --> Router Class Initialized
INFO - 2017-02-03 20:29:36 --> Output Class Initialized
INFO - 2017-02-03 20:29:36 --> Security Class Initialized
DEBUG - 2017-02-03 20:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:29:36 --> Input Class Initialized
INFO - 2017-02-03 20:29:36 --> Language Class Initialized
INFO - 2017-02-03 20:29:36 --> Language Class Initialized
INFO - 2017-02-03 20:29:36 --> Config Class Initialized
INFO - 2017-02-03 20:29:36 --> Loader Class Initialized
INFO - 2017-02-03 20:29:36 --> Controller Class Initialized
DEBUG - 2017-02-03 20:29:36 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:29:36 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:29:36 --> Final output sent to browser
DEBUG - 2017-02-03 20:29:36 --> Total execution time: 0.0060
INFO - 2017-02-03 20:30:21 --> Config Class Initialized
INFO - 2017-02-03 20:30:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:21 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:21 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:21 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:21 --> Router Class Initialized
INFO - 2017-02-03 20:30:21 --> Output Class Initialized
INFO - 2017-02-03 20:30:21 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:21 --> Input Class Initialized
INFO - 2017-02-03 20:30:21 --> Language Class Initialized
INFO - 2017-02-03 20:30:21 --> Language Class Initialized
INFO - 2017-02-03 20:30:21 --> Config Class Initialized
INFO - 2017-02-03 20:30:21 --> Loader Class Initialized
INFO - 2017-02-03 20:30:21 --> Model Class Initialized
ERROR - 2017-02-03 20:30:21 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:30:21 --> Config Class Initialized
INFO - 2017-02-03 20:30:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:21 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:21 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:21 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:21 --> Router Class Initialized
INFO - 2017-02-03 20:30:21 --> Output Class Initialized
INFO - 2017-02-03 20:30:21 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:21 --> Input Class Initialized
INFO - 2017-02-03 20:30:21 --> Language Class Initialized
INFO - 2017-02-03 20:30:21 --> Language Class Initialized
INFO - 2017-02-03 20:30:21 --> Config Class Initialized
INFO - 2017-02-03 20:30:21 --> Loader Class Initialized
INFO - 2017-02-03 20:30:21 --> Model Class Initialized
ERROR - 2017-02-03 20:30:21 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:22 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:22 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:22 --> Router Class Initialized
INFO - 2017-02-03 20:30:22 --> Output Class Initialized
INFO - 2017-02-03 20:30:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:22 --> Input Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Loader Class Initialized
INFO - 2017-02-03 20:30:22 --> Model Class Initialized
ERROR - 2017-02-03 20:30:22 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:22 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:22 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:22 --> Router Class Initialized
INFO - 2017-02-03 20:30:22 --> Output Class Initialized
INFO - 2017-02-03 20:30:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:22 --> Input Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Loader Class Initialized
INFO - 2017-02-03 20:30:22 --> Model Class Initialized
ERROR - 2017-02-03 20:30:22 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:22 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:22 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:22 --> Router Class Initialized
INFO - 2017-02-03 20:30:22 --> Output Class Initialized
INFO - 2017-02-03 20:30:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:22 --> Input Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Loader Class Initialized
INFO - 2017-02-03 20:30:22 --> Model Class Initialized
ERROR - 2017-02-03 20:30:22 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:22 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:22 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:22 --> Router Class Initialized
INFO - 2017-02-03 20:30:22 --> Output Class Initialized
INFO - 2017-02-03 20:30:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:22 --> Input Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Loader Class Initialized
INFO - 2017-02-03 20:30:22 --> Model Class Initialized
ERROR - 2017-02-03 20:30:22 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:22 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:22 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:22 --> Router Class Initialized
INFO - 2017-02-03 20:30:22 --> Output Class Initialized
INFO - 2017-02-03 20:30:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:22 --> Input Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Language Class Initialized
INFO - 2017-02-03 20:30:22 --> Config Class Initialized
INFO - 2017-02-03 20:30:22 --> Loader Class Initialized
INFO - 2017-02-03 20:30:22 --> Model Class Initialized
ERROR - 2017-02-03 20:30:22 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:30:23 --> Config Class Initialized
INFO - 2017-02-03 20:30:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:30:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:30:23 --> Utf8 Class Initialized
INFO - 2017-02-03 20:30:23 --> URI Class Initialized
DEBUG - 2017-02-03 20:30:23 --> No URI present. Default controller set.
INFO - 2017-02-03 20:30:23 --> Router Class Initialized
INFO - 2017-02-03 20:30:23 --> Output Class Initialized
INFO - 2017-02-03 20:30:23 --> Security Class Initialized
DEBUG - 2017-02-03 20:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:30:23 --> Input Class Initialized
INFO - 2017-02-03 20:30:23 --> Language Class Initialized
INFO - 2017-02-03 20:30:23 --> Language Class Initialized
INFO - 2017-02-03 20:30:23 --> Config Class Initialized
INFO - 2017-02-03 20:30:23 --> Loader Class Initialized
INFO - 2017-02-03 20:30:23 --> Model Class Initialized
ERROR - 2017-02-03 20:30:23 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:31:57 --> Config Class Initialized
INFO - 2017-02-03 20:31:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:31:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:31:57 --> Utf8 Class Initialized
INFO - 2017-02-03 20:31:57 --> URI Class Initialized
DEBUG - 2017-02-03 20:31:57 --> No URI present. Default controller set.
INFO - 2017-02-03 20:31:57 --> Router Class Initialized
INFO - 2017-02-03 20:31:57 --> Output Class Initialized
INFO - 2017-02-03 20:31:57 --> Security Class Initialized
DEBUG - 2017-02-03 20:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:31:57 --> Input Class Initialized
INFO - 2017-02-03 20:31:57 --> Language Class Initialized
INFO - 2017-02-03 20:31:57 --> Language Class Initialized
INFO - 2017-02-03 20:31:57 --> Config Class Initialized
INFO - 2017-02-03 20:31:57 --> Loader Class Initialized
INFO - 2017-02-03 20:31:57 --> Model Class Initialized
ERROR - 2017-02-03 20:31:57 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:31:58 --> Config Class Initialized
INFO - 2017-02-03 20:31:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:31:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:31:58 --> Utf8 Class Initialized
INFO - 2017-02-03 20:31:58 --> URI Class Initialized
DEBUG - 2017-02-03 20:31:58 --> No URI present. Default controller set.
INFO - 2017-02-03 20:31:58 --> Router Class Initialized
INFO - 2017-02-03 20:31:58 --> Output Class Initialized
INFO - 2017-02-03 20:31:58 --> Security Class Initialized
DEBUG - 2017-02-03 20:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:31:58 --> Input Class Initialized
INFO - 2017-02-03 20:31:58 --> Language Class Initialized
INFO - 2017-02-03 20:31:58 --> Language Class Initialized
INFO - 2017-02-03 20:31:58 --> Config Class Initialized
INFO - 2017-02-03 20:31:58 --> Loader Class Initialized
INFO - 2017-02-03 20:31:58 --> Model Class Initialized
ERROR - 2017-02-03 20:31:58 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:31:58 --> Config Class Initialized
INFO - 2017-02-03 20:31:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:31:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:31:58 --> Utf8 Class Initialized
INFO - 2017-02-03 20:31:58 --> URI Class Initialized
DEBUG - 2017-02-03 20:31:58 --> No URI present. Default controller set.
INFO - 2017-02-03 20:31:58 --> Router Class Initialized
INFO - 2017-02-03 20:31:58 --> Output Class Initialized
INFO - 2017-02-03 20:31:58 --> Security Class Initialized
DEBUG - 2017-02-03 20:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:31:58 --> Input Class Initialized
INFO - 2017-02-03 20:31:58 --> Language Class Initialized
INFO - 2017-02-03 20:31:58 --> Language Class Initialized
INFO - 2017-02-03 20:31:58 --> Config Class Initialized
INFO - 2017-02-03 20:31:58 --> Loader Class Initialized
INFO - 2017-02-03 20:31:58 --> Model Class Initialized
ERROR - 2017-02-03 20:31:58 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:31:59 --> Config Class Initialized
INFO - 2017-02-03 20:31:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:31:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:31:59 --> Utf8 Class Initialized
INFO - 2017-02-03 20:31:59 --> URI Class Initialized
DEBUG - 2017-02-03 20:31:59 --> No URI present. Default controller set.
INFO - 2017-02-03 20:31:59 --> Router Class Initialized
INFO - 2017-02-03 20:31:59 --> Output Class Initialized
INFO - 2017-02-03 20:31:59 --> Security Class Initialized
DEBUG - 2017-02-03 20:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:31:59 --> Input Class Initialized
INFO - 2017-02-03 20:31:59 --> Language Class Initialized
INFO - 2017-02-03 20:31:59 --> Language Class Initialized
INFO - 2017-02-03 20:31:59 --> Config Class Initialized
INFO - 2017-02-03 20:31:59 --> Loader Class Initialized
INFO - 2017-02-03 20:31:59 --> Model Class Initialized
ERROR - 2017-02-03 20:31:59 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:31:59 --> Config Class Initialized
INFO - 2017-02-03 20:31:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:31:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:31:59 --> Utf8 Class Initialized
INFO - 2017-02-03 20:31:59 --> URI Class Initialized
DEBUG - 2017-02-03 20:31:59 --> No URI present. Default controller set.
INFO - 2017-02-03 20:31:59 --> Router Class Initialized
INFO - 2017-02-03 20:31:59 --> Output Class Initialized
INFO - 2017-02-03 20:31:59 --> Security Class Initialized
DEBUG - 2017-02-03 20:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:31:59 --> Input Class Initialized
INFO - 2017-02-03 20:31:59 --> Language Class Initialized
INFO - 2017-02-03 20:31:59 --> Language Class Initialized
INFO - 2017-02-03 20:31:59 --> Config Class Initialized
INFO - 2017-02-03 20:31:59 --> Loader Class Initialized
INFO - 2017-02-03 20:31:59 --> Model Class Initialized
ERROR - 2017-02-03 20:31:59 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:32:46 --> Config Class Initialized
INFO - 2017-02-03 20:32:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:46 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:46 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:46 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:46 --> Router Class Initialized
INFO - 2017-02-03 20:32:46 --> Output Class Initialized
INFO - 2017-02-03 20:32:46 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:46 --> Input Class Initialized
INFO - 2017-02-03 20:32:46 --> Language Class Initialized
INFO - 2017-02-03 20:32:46 --> Language Class Initialized
INFO - 2017-02-03 20:32:46 --> Config Class Initialized
INFO - 2017-02-03 20:32:46 --> Loader Class Initialized
INFO - 2017-02-03 20:32:46 --> Model Class Initialized
ERROR - 2017-02-03 20:32:46 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:32:47 --> Config Class Initialized
INFO - 2017-02-03 20:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:47 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:47 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:47 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:47 --> Router Class Initialized
INFO - 2017-02-03 20:32:47 --> Output Class Initialized
INFO - 2017-02-03 20:32:47 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:47 --> Input Class Initialized
INFO - 2017-02-03 20:32:47 --> Language Class Initialized
INFO - 2017-02-03 20:32:47 --> Language Class Initialized
INFO - 2017-02-03 20:32:47 --> Config Class Initialized
INFO - 2017-02-03 20:32:47 --> Loader Class Initialized
INFO - 2017-02-03 20:32:47 --> Model Class Initialized
ERROR - 2017-02-03 20:32:47 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:32:47 --> Config Class Initialized
INFO - 2017-02-03 20:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:47 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:47 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:47 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:47 --> Router Class Initialized
INFO - 2017-02-03 20:32:47 --> Output Class Initialized
INFO - 2017-02-03 20:32:47 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:47 --> Input Class Initialized
INFO - 2017-02-03 20:32:47 --> Language Class Initialized
INFO - 2017-02-03 20:32:47 --> Language Class Initialized
INFO - 2017-02-03 20:32:47 --> Config Class Initialized
INFO - 2017-02-03 20:32:47 --> Loader Class Initialized
INFO - 2017-02-03 20:32:47 --> Model Class Initialized
ERROR - 2017-02-03 20:32:47 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:32:47 --> Config Class Initialized
INFO - 2017-02-03 20:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:47 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:47 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:47 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:47 --> Router Class Initialized
INFO - 2017-02-03 20:32:47 --> Output Class Initialized
INFO - 2017-02-03 20:32:47 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:47 --> Input Class Initialized
INFO - 2017-02-03 20:32:47 --> Language Class Initialized
INFO - 2017-02-03 20:32:47 --> Language Class Initialized
INFO - 2017-02-03 20:32:47 --> Config Class Initialized
INFO - 2017-02-03 20:32:47 --> Loader Class Initialized
INFO - 2017-02-03 20:32:47 --> Model Class Initialized
ERROR - 2017-02-03 20:32:47 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:32:48 --> Config Class Initialized
INFO - 2017-02-03 20:32:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:48 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:48 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:48 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:48 --> Router Class Initialized
INFO - 2017-02-03 20:32:48 --> Output Class Initialized
INFO - 2017-02-03 20:32:48 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:48 --> Input Class Initialized
INFO - 2017-02-03 20:32:48 --> Language Class Initialized
INFO - 2017-02-03 20:32:48 --> Language Class Initialized
INFO - 2017-02-03 20:32:48 --> Config Class Initialized
INFO - 2017-02-03 20:32:48 --> Loader Class Initialized
INFO - 2017-02-03 20:32:48 --> Model Class Initialized
ERROR - 2017-02-03 20:32:48 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:32:48 --> Config Class Initialized
INFO - 2017-02-03 20:32:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:48 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:48 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:48 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:48 --> Router Class Initialized
INFO - 2017-02-03 20:32:48 --> Output Class Initialized
INFO - 2017-02-03 20:32:48 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:48 --> Input Class Initialized
INFO - 2017-02-03 20:32:48 --> Language Class Initialized
INFO - 2017-02-03 20:32:48 --> Language Class Initialized
INFO - 2017-02-03 20:32:48 --> Config Class Initialized
INFO - 2017-02-03 20:32:48 --> Loader Class Initialized
INFO - 2017-02-03 20:32:48 --> Model Class Initialized
ERROR - 2017-02-03 20:32:48 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:32:56 --> Config Class Initialized
INFO - 2017-02-03 20:32:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:56 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:56 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:56 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:56 --> Router Class Initialized
INFO - 2017-02-03 20:32:56 --> Output Class Initialized
INFO - 2017-02-03 20:32:56 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:56 --> Input Class Initialized
INFO - 2017-02-03 20:32:56 --> Language Class Initialized
INFO - 2017-02-03 20:32:56 --> Language Class Initialized
INFO - 2017-02-03 20:32:56 --> Config Class Initialized
INFO - 2017-02-03 20:32:56 --> Loader Class Initialized
INFO - 2017-02-03 20:32:56 --> Controller Class Initialized
DEBUG - 2017-02-03 20:32:56 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:32:56 --> Model Class Initialized
DEBUG - 2017-02-03 20:32:56 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/models/Main_models.php
ERROR - 2017-02-03 20:32:56 --> Severity: Error --> Class 'Main_models' not found /var/www/html/wartabandung/application/third_party/MX/Loader.php 225
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:57 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:57 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:57 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:57 --> Router Class Initialized
INFO - 2017-02-03 20:32:57 --> Output Class Initialized
INFO - 2017-02-03 20:32:57 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:57 --> Input Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Loader Class Initialized
INFO - 2017-02-03 20:32:57 --> Controller Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:32:57 --> Model Class Initialized
DEBUG - 2017-02-03 20:32:57 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/models/Main_models.php
ERROR - 2017-02-03 20:32:57 --> Severity: Error --> Class 'Main_models' not found /var/www/html/wartabandung/application/third_party/MX/Loader.php 225
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:57 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:57 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:57 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:57 --> Router Class Initialized
INFO - 2017-02-03 20:32:57 --> Output Class Initialized
INFO - 2017-02-03 20:32:57 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:57 --> Input Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Loader Class Initialized
INFO - 2017-02-03 20:32:57 --> Controller Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:32:57 --> Model Class Initialized
DEBUG - 2017-02-03 20:32:57 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/models/Main_models.php
ERROR - 2017-02-03 20:32:57 --> Severity: Error --> Class 'Main_models' not found /var/www/html/wartabandung/application/third_party/MX/Loader.php 225
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:57 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:57 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:57 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:57 --> Router Class Initialized
INFO - 2017-02-03 20:32:57 --> Output Class Initialized
INFO - 2017-02-03 20:32:57 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:57 --> Input Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Loader Class Initialized
INFO - 2017-02-03 20:32:57 --> Controller Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:32:57 --> Model Class Initialized
DEBUG - 2017-02-03 20:32:57 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/models/Main_models.php
ERROR - 2017-02-03 20:32:57 --> Severity: Error --> Class 'Main_models' not found /var/www/html/wartabandung/application/third_party/MX/Loader.php 225
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:57 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:57 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:57 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:57 --> Router Class Initialized
INFO - 2017-02-03 20:32:57 --> Output Class Initialized
INFO - 2017-02-03 20:32:57 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:57 --> Input Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Language Class Initialized
INFO - 2017-02-03 20:32:57 --> Config Class Initialized
INFO - 2017-02-03 20:32:57 --> Loader Class Initialized
INFO - 2017-02-03 20:32:57 --> Controller Class Initialized
DEBUG - 2017-02-03 20:32:57 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:32:57 --> Model Class Initialized
DEBUG - 2017-02-03 20:32:57 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/models/Main_models.php
ERROR - 2017-02-03 20:32:57 --> Severity: Error --> Class 'Main_models' not found /var/www/html/wartabandung/application/third_party/MX/Loader.php 225
INFO - 2017-02-03 20:32:58 --> Config Class Initialized
INFO - 2017-02-03 20:32:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:32:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:32:58 --> Utf8 Class Initialized
INFO - 2017-02-03 20:32:58 --> URI Class Initialized
DEBUG - 2017-02-03 20:32:58 --> No URI present. Default controller set.
INFO - 2017-02-03 20:32:58 --> Router Class Initialized
INFO - 2017-02-03 20:32:58 --> Output Class Initialized
INFO - 2017-02-03 20:32:58 --> Security Class Initialized
DEBUG - 2017-02-03 20:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:32:58 --> Input Class Initialized
INFO - 2017-02-03 20:32:58 --> Language Class Initialized
INFO - 2017-02-03 20:32:58 --> Language Class Initialized
INFO - 2017-02-03 20:32:58 --> Config Class Initialized
INFO - 2017-02-03 20:32:58 --> Loader Class Initialized
INFO - 2017-02-03 20:32:58 --> Controller Class Initialized
DEBUG - 2017-02-03 20:32:58 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:32:58 --> Model Class Initialized
DEBUG - 2017-02-03 20:32:58 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/models/Main_models.php
ERROR - 2017-02-03 20:32:58 --> Severity: Error --> Class 'Main_models' not found /var/www/html/wartabandung/application/third_party/MX/Loader.php 225
INFO - 2017-02-03 20:33:11 --> Config Class Initialized
INFO - 2017-02-03 20:33:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:11 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:11 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:11 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:11 --> Router Class Initialized
INFO - 2017-02-03 20:33:11 --> Output Class Initialized
INFO - 2017-02-03 20:33:11 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:11 --> Input Class Initialized
INFO - 2017-02-03 20:33:11 --> Language Class Initialized
INFO - 2017-02-03 20:33:11 --> Language Class Initialized
INFO - 2017-02-03 20:33:11 --> Config Class Initialized
INFO - 2017-02-03 20:33:11 --> Loader Class Initialized
INFO - 2017-02-03 20:33:11 --> Controller Class Initialized
DEBUG - 2017-02-03 20:33:11 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:33:11 --> Model Class Initialized
ERROR - 2017-02-03 20:33:11 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:33:12 --> Config Class Initialized
INFO - 2017-02-03 20:33:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:12 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:12 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:12 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:12 --> Router Class Initialized
INFO - 2017-02-03 20:33:12 --> Output Class Initialized
INFO - 2017-02-03 20:33:12 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:12 --> Input Class Initialized
INFO - 2017-02-03 20:33:12 --> Language Class Initialized
INFO - 2017-02-03 20:33:12 --> Language Class Initialized
INFO - 2017-02-03 20:33:12 --> Config Class Initialized
INFO - 2017-02-03 20:33:12 --> Loader Class Initialized
INFO - 2017-02-03 20:33:12 --> Controller Class Initialized
DEBUG - 2017-02-03 20:33:12 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:33:12 --> Model Class Initialized
ERROR - 2017-02-03 20:33:12 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:13 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:13 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:13 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:13 --> Router Class Initialized
INFO - 2017-02-03 20:33:13 --> Output Class Initialized
INFO - 2017-02-03 20:33:13 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:13 --> Input Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Loader Class Initialized
INFO - 2017-02-03 20:33:13 --> Controller Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:33:13 --> Model Class Initialized
ERROR - 2017-02-03 20:33:13 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:13 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:13 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:13 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:13 --> Router Class Initialized
INFO - 2017-02-03 20:33:13 --> Output Class Initialized
INFO - 2017-02-03 20:33:13 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:13 --> Input Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Loader Class Initialized
INFO - 2017-02-03 20:33:13 --> Controller Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:33:13 --> Model Class Initialized
ERROR - 2017-02-03 20:33:13 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:13 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:13 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:13 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:13 --> Router Class Initialized
INFO - 2017-02-03 20:33:13 --> Output Class Initialized
INFO - 2017-02-03 20:33:13 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:13 --> Input Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Loader Class Initialized
INFO - 2017-02-03 20:33:13 --> Controller Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:33:13 --> Model Class Initialized
ERROR - 2017-02-03 20:33:13 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:13 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:13 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:13 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:13 --> Router Class Initialized
INFO - 2017-02-03 20:33:13 --> Output Class Initialized
INFO - 2017-02-03 20:33:13 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:13 --> Input Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Language Class Initialized
INFO - 2017-02-03 20:33:13 --> Config Class Initialized
INFO - 2017-02-03 20:33:13 --> Loader Class Initialized
INFO - 2017-02-03 20:33:13 --> Controller Class Initialized
DEBUG - 2017-02-03 20:33:13 --> Welcome MX_Controller Initialized
INFO - 2017-02-03 20:33:13 --> Model Class Initialized
ERROR - 2017-02-03 20:33:13 --> Severity: Error --> Class 'Main_model' not found /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:33:49 --> Config Class Initialized
INFO - 2017-02-03 20:33:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:33:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:33:49 --> Utf8 Class Initialized
INFO - 2017-02-03 20:33:49 --> URI Class Initialized
DEBUG - 2017-02-03 20:33:49 --> No URI present. Default controller set.
INFO - 2017-02-03 20:33:49 --> Router Class Initialized
INFO - 2017-02-03 20:33:49 --> Output Class Initialized
INFO - 2017-02-03 20:33:49 --> Security Class Initialized
DEBUG - 2017-02-03 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:33:49 --> Input Class Initialized
INFO - 2017-02-03 20:33:49 --> Language Class Initialized
INFO - 2017-02-03 20:33:49 --> Language Class Initialized
INFO - 2017-02-03 20:33:49 --> Config Class Initialized
INFO - 2017-02-03 20:33:49 --> Loader Class Initialized
INFO - 2017-02-03 20:33:49 --> Model Class Initialized
INFO - 2017-02-03 20:33:49 --> Model Class Initialized
INFO - 2017-02-03 20:33:49 --> Controller Class Initialized
DEBUG - 2017-02-03 20:33:49 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:33:49 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:33:49 --> Final output sent to browser
DEBUG - 2017-02-03 20:33:49 --> Total execution time: 0.0384
INFO - 2017-02-03 20:35:31 --> Config Class Initialized
INFO - 2017-02-03 20:35:31 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:35:31 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:35:31 --> Utf8 Class Initialized
INFO - 2017-02-03 20:35:31 --> URI Class Initialized
DEBUG - 2017-02-03 20:35:31 --> No URI present. Default controller set.
INFO - 2017-02-03 20:35:31 --> Router Class Initialized
INFO - 2017-02-03 20:35:31 --> Output Class Initialized
INFO - 2017-02-03 20:35:31 --> Security Class Initialized
DEBUG - 2017-02-03 20:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:35:31 --> Input Class Initialized
INFO - 2017-02-03 20:35:31 --> Language Class Initialized
INFO - 2017-02-03 20:35:31 --> Language Class Initialized
INFO - 2017-02-03 20:35:31 --> Config Class Initialized
INFO - 2017-02-03 20:35:31 --> Loader Class Initialized
INFO - 2017-02-03 20:35:31 --> Model Class Initialized
ERROR - 2017-02-03 20:35:31 --> Severity: Notice --> Use of undefined constant HOST_SERVER - assumed 'HOST_SERVER' /var/www/html/wartabandung/system/core/Loader.php 305
ERROR - 2017-02-03 20:35:31 --> Severity: Notice --> Use of undefined constant USER_DB - assumed 'USER_DB' /var/www/html/wartabandung/system/core/Loader.php 305
ERROR - 2017-02-03 20:35:31 --> Severity: Notice --> Use of undefined constant PASSWORD_DB - assumed 'PASSWORD_DB' /var/www/html/wartabandung/system/core/Loader.php 305
ERROR - 2017-02-03 20:35:31 --> Severity: Notice --> Use of undefined constant NAME_DB - assumed 'NAME_DB' /var/www/html/wartabandung/system/core/Loader.php 305
INFO - 2017-02-03 20:35:31 --> Model Class Initialized
INFO - 2017-02-03 20:35:31 --> Controller Class Initialized
DEBUG - 2017-02-03 20:35:31 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:35:31 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:35:31 --> Final output sent to browser
DEBUG - 2017-02-03 20:35:31 --> Total execution time: 0.0082
INFO - 2017-02-03 20:35:57 --> Config Class Initialized
INFO - 2017-02-03 20:35:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:35:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:35:57 --> Utf8 Class Initialized
INFO - 2017-02-03 20:35:57 --> URI Class Initialized
DEBUG - 2017-02-03 20:35:57 --> No URI present. Default controller set.
INFO - 2017-02-03 20:35:57 --> Router Class Initialized
INFO - 2017-02-03 20:35:57 --> Output Class Initialized
INFO - 2017-02-03 20:35:57 --> Security Class Initialized
DEBUG - 2017-02-03 20:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:35:57 --> Input Class Initialized
INFO - 2017-02-03 20:35:57 --> Language Class Initialized
INFO - 2017-02-03 20:35:57 --> Language Class Initialized
INFO - 2017-02-03 20:35:57 --> Config Class Initialized
INFO - 2017-02-03 20:35:57 --> Loader Class Initialized
INFO - 2017-02-03 20:35:57 --> Model Class Initialized
INFO - 2017-02-03 20:35:57 --> Model Class Initialized
INFO - 2017-02-03 20:35:57 --> Controller Class Initialized
DEBUG - 2017-02-03 20:35:57 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:35:57 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:35:57 --> Final output sent to browser
DEBUG - 2017-02-03 20:35:57 --> Total execution time: 0.0099
INFO - 2017-02-03 20:40:40 --> Config Class Initialized
INFO - 2017-02-03 20:40:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:40:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:40:40 --> Utf8 Class Initialized
INFO - 2017-02-03 20:40:40 --> URI Class Initialized
DEBUG - 2017-02-03 20:40:40 --> No URI present. Default controller set.
INFO - 2017-02-03 20:40:40 --> Router Class Initialized
INFO - 2017-02-03 20:40:40 --> Output Class Initialized
INFO - 2017-02-03 20:40:40 --> Security Class Initialized
DEBUG - 2017-02-03 20:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:40:40 --> Input Class Initialized
INFO - 2017-02-03 20:40:40 --> Language Class Initialized
INFO - 2017-02-03 20:40:40 --> Language Class Initialized
INFO - 2017-02-03 20:40:40 --> Config Class Initialized
INFO - 2017-02-03 20:40:40 --> Loader Class Initialized
INFO - 2017-02-03 20:40:40 --> Database Driver Class Initialized
INFO - 2017-02-03 20:40:40 --> Model Class Initialized
INFO - 2017-02-03 20:40:40 --> Model Class Initialized
INFO - 2017-02-03 20:40:40 --> Controller Class Initialized
DEBUG - 2017-02-03 20:40:40 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:40:40 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:40:40 --> Final output sent to browser
DEBUG - 2017-02-03 20:40:40 --> Total execution time: 0.2623
INFO - 2017-02-03 20:50:06 --> Config Class Initialized
INFO - 2017-02-03 20:50:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:50:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:50:06 --> Utf8 Class Initialized
INFO - 2017-02-03 20:50:06 --> URI Class Initialized
DEBUG - 2017-02-03 20:50:06 --> No URI present. Default controller set.
INFO - 2017-02-03 20:50:06 --> Router Class Initialized
INFO - 2017-02-03 20:50:06 --> Output Class Initialized
INFO - 2017-02-03 20:50:06 --> Security Class Initialized
DEBUG - 2017-02-03 20:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:50:06 --> Input Class Initialized
INFO - 2017-02-03 20:50:06 --> Language Class Initialized
INFO - 2017-02-03 20:50:06 --> Language Class Initialized
INFO - 2017-02-03 20:50:06 --> Config Class Initialized
INFO - 2017-02-03 20:50:06 --> Loader Class Initialized
INFO - 2017-02-03 20:50:06 --> Helper loaded: url_helper
INFO - 2017-02-03 20:50:06 --> Helper loaded: file_helper
INFO - 2017-02-03 20:50:06 --> Database Driver Class Initialized
INFO - 2017-02-03 20:50:06 --> Model Class Initialized
INFO - 2017-02-03 20:50:06 --> Model Class Initialized
INFO - 2017-02-03 20:50:06 --> Controller Class Initialized
DEBUG - 2017-02-03 20:50:06 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:50:06 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:50:06 --> Final output sent to browser
DEBUG - 2017-02-03 20:50:06 --> Total execution time: 0.0707
INFO - 2017-02-03 20:52:12 --> Config Class Initialized
INFO - 2017-02-03 20:52:12 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:52:12 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:52:12 --> Utf8 Class Initialized
INFO - 2017-02-03 20:52:12 --> URI Class Initialized
DEBUG - 2017-02-03 20:52:12 --> No URI present. Default controller set.
INFO - 2017-02-03 20:52:12 --> Router Class Initialized
INFO - 2017-02-03 20:52:12 --> Output Class Initialized
INFO - 2017-02-03 20:52:12 --> Security Class Initialized
DEBUG - 2017-02-03 20:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:52:12 --> Input Class Initialized
INFO - 2017-02-03 20:52:12 --> Language Class Initialized
INFO - 2017-02-03 20:52:12 --> Language Class Initialized
INFO - 2017-02-03 20:52:12 --> Config Class Initialized
INFO - 2017-02-03 20:52:12 --> Loader Class Initialized
INFO - 2017-02-03 20:52:12 --> Helper loaded: url_helper
INFO - 2017-02-03 20:52:12 --> Helper loaded: file_helper
INFO - 2017-02-03 20:52:12 --> Database Driver Class Initialized
INFO - 2017-02-03 20:52:12 --> Model Class Initialized
INFO - 2017-02-03 20:52:12 --> Model Class Initialized
INFO - 2017-02-03 20:52:12 --> Controller Class Initialized
DEBUG - 2017-02-03 20:52:12 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-03 20:52:12 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-03 20:52:12 --> Final output sent to browser
DEBUG - 2017-02-03 20:52:12 --> Total execution time: 0.0391
INFO - 2017-02-03 20:53:41 --> Config Class Initialized
INFO - 2017-02-03 20:53:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:53:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:53:41 --> Utf8 Class Initialized
INFO - 2017-02-03 20:53:41 --> URI Class Initialized
DEBUG - 2017-02-03 20:53:41 --> No URI present. Default controller set.
INFO - 2017-02-03 20:53:41 --> Router Class Initialized
INFO - 2017-02-03 20:53:41 --> Output Class Initialized
INFO - 2017-02-03 20:53:41 --> Security Class Initialized
DEBUG - 2017-02-03 20:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:53:41 --> Input Class Initialized
INFO - 2017-02-03 20:53:41 --> Language Class Initialized
INFO - 2017-02-03 20:53:41 --> Language Class Initialized
INFO - 2017-02-03 20:53:41 --> Config Class Initialized
INFO - 2017-02-03 20:53:41 --> Loader Class Initialized
INFO - 2017-02-03 20:53:41 --> Helper loaded: url_helper
INFO - 2017-02-03 20:53:41 --> Helper loaded: file_helper
INFO - 2017-02-03 20:53:41 --> Database Driver Class Initialized
INFO - 2017-02-03 20:53:41 --> Model Class Initialized
INFO - 2017-02-03 20:53:41 --> Model Class Initialized
INFO - 2017-02-03 20:53:41 --> Controller Class Initialized
DEBUG - 2017-02-03 20:53:41 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined variable: kw /var/www/html/wartabandung/application/views/index.php 12
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined variable: des /var/www/html/wartabandung/application/views/index.php 13
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Use of undefined constant BASE_PATH - assumed 'BASE_PATH' /var/www/html/wartabandung/application/models/Main_model.php 166
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 171
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 199
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 14
ERROR - 2017-02-03 20:53:41 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:53:41 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:53:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
DEBUG - 2017-02-03 20:53:41 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 20:53:41 --> Final output sent to browser
DEBUG - 2017-02-03 20:53:41 --> Total execution time: 0.1457
INFO - 2017-02-03 20:54:22 --> Config Class Initialized
INFO - 2017-02-03 20:54:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:54:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:54:22 --> Utf8 Class Initialized
INFO - 2017-02-03 20:54:22 --> URI Class Initialized
DEBUG - 2017-02-03 20:54:22 --> No URI present. Default controller set.
INFO - 2017-02-03 20:54:22 --> Router Class Initialized
INFO - 2017-02-03 20:54:22 --> Output Class Initialized
INFO - 2017-02-03 20:54:22 --> Security Class Initialized
DEBUG - 2017-02-03 20:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:54:22 --> Input Class Initialized
INFO - 2017-02-03 20:54:22 --> Language Class Initialized
INFO - 2017-02-03 20:54:22 --> Language Class Initialized
INFO - 2017-02-03 20:54:22 --> Config Class Initialized
INFO - 2017-02-03 20:54:22 --> Loader Class Initialized
INFO - 2017-02-03 20:54:22 --> Helper loaded: url_helper
INFO - 2017-02-03 20:54:22 --> Helper loaded: file_helper
INFO - 2017-02-03 20:54:22 --> Database Driver Class Initialized
INFO - 2017-02-03 20:54:22 --> Model Class Initialized
INFO - 2017-02-03 20:54:22 --> Model Class Initialized
INFO - 2017-02-03 20:54:22 --> Controller Class Initialized
DEBUG - 2017-02-03 20:54:22 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined variable: des /var/www/html/wartabandung/application/views/index.php 13
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Use of undefined constant BASE_PATH - assumed 'BASE_PATH' /var/www/html/wartabandung/application/models/Main_model.php 166
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 171
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 199
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 14
ERROR - 2017-02-03 20:54:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
DEBUG - 2017-02-03 20:54:22 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 20:54:22 --> Final output sent to browser
DEBUG - 2017-02-03 20:54:22 --> Total execution time: 0.0479
INFO - 2017-02-03 20:54:34 --> Config Class Initialized
INFO - 2017-02-03 20:54:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:54:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:54:34 --> Utf8 Class Initialized
INFO - 2017-02-03 20:54:34 --> URI Class Initialized
DEBUG - 2017-02-03 20:54:34 --> No URI present. Default controller set.
INFO - 2017-02-03 20:54:34 --> Router Class Initialized
INFO - 2017-02-03 20:54:34 --> Output Class Initialized
INFO - 2017-02-03 20:54:34 --> Security Class Initialized
DEBUG - 2017-02-03 20:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:54:34 --> Input Class Initialized
INFO - 2017-02-03 20:54:34 --> Language Class Initialized
INFO - 2017-02-03 20:54:34 --> Language Class Initialized
INFO - 2017-02-03 20:54:34 --> Config Class Initialized
INFO - 2017-02-03 20:54:34 --> Loader Class Initialized
INFO - 2017-02-03 20:54:34 --> Helper loaded: url_helper
INFO - 2017-02-03 20:54:34 --> Helper loaded: file_helper
INFO - 2017-02-03 20:54:34 --> Database Driver Class Initialized
INFO - 2017-02-03 20:54:34 --> Model Class Initialized
INFO - 2017-02-03 20:54:34 --> Model Class Initialized
INFO - 2017-02-03 20:54:34 --> Controller Class Initialized
DEBUG - 2017-02-03 20:54:34 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Use of undefined constant BASE_PATH - assumed 'BASE_PATH' /var/www/html/wartabandung/application/models/Main_model.php 166
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 171
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 199
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 13
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 14
ERROR - 2017-02-03 20:54:34 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:54:34 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:54:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
DEBUG - 2017-02-03 20:54:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 20:54:34 --> Final output sent to browser
DEBUG - 2017-02-03 20:54:34 --> Total execution time: 0.0247
INFO - 2017-02-03 20:56:06 --> Config Class Initialized
INFO - 2017-02-03 20:56:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:56:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:56:06 --> Utf8 Class Initialized
INFO - 2017-02-03 20:56:06 --> URI Class Initialized
DEBUG - 2017-02-03 20:56:06 --> No URI present. Default controller set.
INFO - 2017-02-03 20:56:06 --> Router Class Initialized
INFO - 2017-02-03 20:56:06 --> Output Class Initialized
INFO - 2017-02-03 20:56:06 --> Security Class Initialized
DEBUG - 2017-02-03 20:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:56:06 --> Input Class Initialized
INFO - 2017-02-03 20:56:06 --> Language Class Initialized
INFO - 2017-02-03 20:56:06 --> Language Class Initialized
INFO - 2017-02-03 20:56:06 --> Config Class Initialized
INFO - 2017-02-03 20:56:06 --> Loader Class Initialized
INFO - 2017-02-03 20:56:06 --> Helper loaded: url_helper
INFO - 2017-02-03 20:56:06 --> Helper loaded: file_helper
INFO - 2017-02-03 20:56:06 --> Database Driver Class Initialized
INFO - 2017-02-03 20:56:06 --> Model Class Initialized
INFO - 2017-02-03 20:56:06 --> Model Class Initialized
INFO - 2017-02-03 20:56:06 --> Controller Class Initialized
DEBUG - 2017-02-03 20:56:06 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Use of undefined constant BASE_PATH - assumed 'BASE_PATH' /var/www/html/wartabandung/application/models/Main_model.php 166
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 171
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 31
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 32
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Undefined offset: 1 /var/www/html/wartabandung/application/models/Main_model.php 60
ERROR - 2017-02-03 20:56:06 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 197
ERROR - 2017-02-03 20:56:06 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 199
ERROR - 2017-02-03 20:56:06 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 20:56:06 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 20
INFO - 2017-02-03 20:57:11 --> Config Class Initialized
INFO - 2017-02-03 20:57:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:57:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:57:11 --> Utf8 Class Initialized
INFO - 2017-02-03 20:57:11 --> URI Class Initialized
DEBUG - 2017-02-03 20:57:11 --> No URI present. Default controller set.
INFO - 2017-02-03 20:57:11 --> Router Class Initialized
INFO - 2017-02-03 20:57:11 --> Output Class Initialized
INFO - 2017-02-03 20:57:11 --> Security Class Initialized
DEBUG - 2017-02-03 20:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:57:11 --> Input Class Initialized
INFO - 2017-02-03 20:57:11 --> Language Class Initialized
INFO - 2017-02-03 20:57:11 --> Language Class Initialized
INFO - 2017-02-03 20:57:11 --> Config Class Initialized
INFO - 2017-02-03 20:57:11 --> Loader Class Initialized
INFO - 2017-02-03 20:57:11 --> Helper loaded: url_helper
INFO - 2017-02-03 20:57:11 --> Helper loaded: file_helper
INFO - 2017-02-03 20:57:11 --> Database Driver Class Initialized
INFO - 2017-02-03 20:57:11 --> Model Class Initialized
INFO - 2017-02-03 20:57:11 --> Model Class Initialized
INFO - 2017-02-03 20:57:11 --> Controller Class Initialized
DEBUG - 2017-02-03 20:57:11 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 20:57:11 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 34
INFO - 2017-02-03 20:58:43 --> Config Class Initialized
INFO - 2017-02-03 20:58:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 20:58:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 20:58:43 --> Utf8 Class Initialized
INFO - 2017-02-03 20:58:43 --> URI Class Initialized
DEBUG - 2017-02-03 20:58:43 --> No URI present. Default controller set.
INFO - 2017-02-03 20:58:43 --> Router Class Initialized
INFO - 2017-02-03 20:58:43 --> Output Class Initialized
INFO - 2017-02-03 20:58:43 --> Security Class Initialized
DEBUG - 2017-02-03 20:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 20:58:43 --> Input Class Initialized
INFO - 2017-02-03 20:58:43 --> Language Class Initialized
INFO - 2017-02-03 20:58:43 --> Language Class Initialized
INFO - 2017-02-03 20:58:43 --> Config Class Initialized
INFO - 2017-02-03 20:58:43 --> Loader Class Initialized
INFO - 2017-02-03 20:58:43 --> Helper loaded: url_helper
INFO - 2017-02-03 20:58:43 --> Helper loaded: file_helper
INFO - 2017-02-03 20:58:43 --> Database Driver Class Initialized
INFO - 2017-02-03 20:58:43 --> Model Class Initialized
INFO - 2017-02-03 20:58:43 --> Model Class Initialized
INFO - 2017-02-03 20:58:43 --> Controller Class Initialized
DEBUG - 2017-02-03 20:58:43 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/models/Main_model.php 156
ERROR - 2017-02-03 20:58:43 --> Severity: Notice --> Use of undefined constant BASE_PATH - assumed 'BASE_PATH' /var/www/html/wartabandung/application/models/Main_model.php 166
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/models/Main_model.php 171
ERROR - 2017-02-03 20:58:43 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 20:58:43 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 20:58:43 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 20:58:43 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:00:09 --> Config Class Initialized
INFO - 2017-02-03 21:00:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:00:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:00:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:00:09 --> URI Class Initialized
DEBUG - 2017-02-03 21:00:09 --> No URI present. Default controller set.
INFO - 2017-02-03 21:00:09 --> Router Class Initialized
INFO - 2017-02-03 21:00:09 --> Output Class Initialized
INFO - 2017-02-03 21:00:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:00:09 --> Input Class Initialized
INFO - 2017-02-03 21:00:09 --> Language Class Initialized
INFO - 2017-02-03 21:00:09 --> Language Class Initialized
INFO - 2017-02-03 21:00:09 --> Config Class Initialized
INFO - 2017-02-03 21:00:09 --> Loader Class Initialized
INFO - 2017-02-03 21:00:09 --> Helper loaded: url_helper
INFO - 2017-02-03 21:00:09 --> Helper loaded: file_helper
INFO - 2017-02-03 21:00:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:00:09 --> Model Class Initialized
INFO - 2017-02-03 21:00:09 --> Model Class Initialized
INFO - 2017-02-03 21:00:09 --> Controller Class Initialized
DEBUG - 2017-02-03 21:00:09 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 171
ERROR - 2017-02-03 21:00:09 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 21:00:09 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:00:09 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 21:00:09 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:01:22 --> Config Class Initialized
INFO - 2017-02-03 21:01:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:01:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:01:22 --> Utf8 Class Initialized
INFO - 2017-02-03 21:01:22 --> URI Class Initialized
DEBUG - 2017-02-03 21:01:22 --> No URI present. Default controller set.
INFO - 2017-02-03 21:01:22 --> Router Class Initialized
INFO - 2017-02-03 21:01:22 --> Output Class Initialized
INFO - 2017-02-03 21:01:22 --> Security Class Initialized
DEBUG - 2017-02-03 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:01:22 --> Input Class Initialized
INFO - 2017-02-03 21:01:22 --> Language Class Initialized
INFO - 2017-02-03 21:01:22 --> Language Class Initialized
INFO - 2017-02-03 21:01:22 --> Config Class Initialized
INFO - 2017-02-03 21:01:22 --> Loader Class Initialized
INFO - 2017-02-03 21:01:22 --> Helper loaded: url_helper
INFO - 2017-02-03 21:01:22 --> Helper loaded: file_helper
INFO - 2017-02-03 21:01:22 --> Database Driver Class Initialized
INFO - 2017-02-03 21:01:22 --> Model Class Initialized
INFO - 2017-02-03 21:01:22 --> Model Class Initialized
INFO - 2017-02-03 21:01:22 --> Controller Class Initialized
DEBUG - 2017-02-03 21:01:22 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:22 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 21:01:22 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:01:22 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 21:01:22 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:01:50 --> Config Class Initialized
INFO - 2017-02-03 21:01:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:01:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:01:50 --> Utf8 Class Initialized
INFO - 2017-02-03 21:01:50 --> URI Class Initialized
DEBUG - 2017-02-03 21:01:50 --> No URI present. Default controller set.
INFO - 2017-02-03 21:01:50 --> Router Class Initialized
INFO - 2017-02-03 21:01:50 --> Output Class Initialized
INFO - 2017-02-03 21:01:50 --> Security Class Initialized
DEBUG - 2017-02-03 21:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:01:50 --> Input Class Initialized
INFO - 2017-02-03 21:01:50 --> Language Class Initialized
INFO - 2017-02-03 21:01:50 --> Language Class Initialized
INFO - 2017-02-03 21:01:50 --> Config Class Initialized
INFO - 2017-02-03 21:01:50 --> Loader Class Initialized
INFO - 2017-02-03 21:01:50 --> Helper loaded: url_helper
INFO - 2017-02-03 21:01:50 --> Helper loaded: file_helper
INFO - 2017-02-03 21:01:50 --> Database Driver Class Initialized
INFO - 2017-02-03 21:01:50 --> Model Class Initialized
INFO - 2017-02-03 21:01:50 --> Model Class Initialized
INFO - 2017-02-03 21:01:50 --> Controller Class Initialized
DEBUG - 2017-02-03 21:01:50 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Use of undefined constant no - assumed 'no' /var/www/html/wartabandung/application/models/Main_model.php 173
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:01:50 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 21:01:50 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:01:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 21:01:50 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:02:04 --> Config Class Initialized
INFO - 2017-02-03 21:02:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:02:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:02:04 --> Utf8 Class Initialized
INFO - 2017-02-03 21:02:04 --> URI Class Initialized
DEBUG - 2017-02-03 21:02:04 --> No URI present. Default controller set.
INFO - 2017-02-03 21:02:04 --> Router Class Initialized
INFO - 2017-02-03 21:02:04 --> Output Class Initialized
INFO - 2017-02-03 21:02:04 --> Security Class Initialized
DEBUG - 2017-02-03 21:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:02:04 --> Input Class Initialized
INFO - 2017-02-03 21:02:04 --> Language Class Initialized
INFO - 2017-02-03 21:02:04 --> Language Class Initialized
INFO - 2017-02-03 21:02:04 --> Config Class Initialized
INFO - 2017-02-03 21:02:04 --> Loader Class Initialized
INFO - 2017-02-03 21:02:04 --> Helper loaded: url_helper
INFO - 2017-02-03 21:02:04 --> Helper loaded: file_helper
INFO - 2017-02-03 21:02:04 --> Database Driver Class Initialized
INFO - 2017-02-03 21:02:04 --> Model Class Initialized
INFO - 2017-02-03 21:02:04 --> Model Class Initialized
INFO - 2017-02-03 21:02:04 --> Controller Class Initialized
DEBUG - 2017-02-03 21:02:04 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 174
ERROR - 2017-02-03 21:02:04 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 21:02:04 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:02:04 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 21:02:04 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:02:39 --> Config Class Initialized
INFO - 2017-02-03 21:02:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:02:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:02:39 --> Utf8 Class Initialized
INFO - 2017-02-03 21:02:39 --> URI Class Initialized
DEBUG - 2017-02-03 21:02:39 --> No URI present. Default controller set.
INFO - 2017-02-03 21:02:39 --> Router Class Initialized
INFO - 2017-02-03 21:02:39 --> Output Class Initialized
INFO - 2017-02-03 21:02:39 --> Security Class Initialized
DEBUG - 2017-02-03 21:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:02:39 --> Input Class Initialized
INFO - 2017-02-03 21:02:39 --> Language Class Initialized
INFO - 2017-02-03 21:02:39 --> Language Class Initialized
INFO - 2017-02-03 21:02:39 --> Config Class Initialized
INFO - 2017-02-03 21:02:39 --> Loader Class Initialized
INFO - 2017-02-03 21:02:39 --> Helper loaded: url_helper
INFO - 2017-02-03 21:02:39 --> Helper loaded: file_helper
INFO - 2017-02-03 21:02:39 --> Database Driver Class Initialized
INFO - 2017-02-03 21:02:39 --> Model Class Initialized
INFO - 2017-02-03 21:02:39 --> Model Class Initialized
INFO - 2017-02-03 21:02:39 --> Controller Class Initialized
DEBUG - 2017-02-03 21:02:39 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:02:39 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 146
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 21:02:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:02:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 21:02:39 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:03:39 --> Config Class Initialized
INFO - 2017-02-03 21:03:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:03:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:03:39 --> Utf8 Class Initialized
INFO - 2017-02-03 21:03:39 --> URI Class Initialized
DEBUG - 2017-02-03 21:03:39 --> No URI present. Default controller set.
INFO - 2017-02-03 21:03:39 --> Router Class Initialized
INFO - 2017-02-03 21:03:39 --> Output Class Initialized
INFO - 2017-02-03 21:03:39 --> Security Class Initialized
DEBUG - 2017-02-03 21:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:03:39 --> Input Class Initialized
INFO - 2017-02-03 21:03:39 --> Language Class Initialized
INFO - 2017-02-03 21:03:39 --> Language Class Initialized
INFO - 2017-02-03 21:03:39 --> Config Class Initialized
INFO - 2017-02-03 21:03:39 --> Loader Class Initialized
INFO - 2017-02-03 21:03:39 --> Helper loaded: url_helper
INFO - 2017-02-03 21:03:39 --> Helper loaded: file_helper
INFO - 2017-02-03 21:03:39 --> Database Driver Class Initialized
INFO - 2017-02-03 21:03:39 --> Model Class Initialized
INFO - 2017-02-03 21:03:39 --> Model Class Initialized
INFO - 2017-02-03 21:03:39 --> Controller Class Initialized
DEBUG - 2017-02-03 21:03:39 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 21:03:39 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:03:39 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 21:03:39 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:04:16 --> Config Class Initialized
INFO - 2017-02-03 21:04:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:04:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:04:16 --> Utf8 Class Initialized
INFO - 2017-02-03 21:04:16 --> URI Class Initialized
DEBUG - 2017-02-03 21:04:16 --> No URI present. Default controller set.
INFO - 2017-02-03 21:04:16 --> Router Class Initialized
INFO - 2017-02-03 21:04:16 --> Output Class Initialized
INFO - 2017-02-03 21:04:16 --> Security Class Initialized
DEBUG - 2017-02-03 21:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:04:16 --> Input Class Initialized
INFO - 2017-02-03 21:04:16 --> Language Class Initialized
INFO - 2017-02-03 21:04:16 --> Language Class Initialized
INFO - 2017-02-03 21:04:16 --> Config Class Initialized
INFO - 2017-02-03 21:04:16 --> Loader Class Initialized
INFO - 2017-02-03 21:04:16 --> Helper loaded: url_helper
INFO - 2017-02-03 21:04:16 --> Helper loaded: file_helper
INFO - 2017-02-03 21:04:16 --> Database Driver Class Initialized
INFO - 2017-02-03 21:04:16 --> Model Class Initialized
INFO - 2017-02-03 21:04:16 --> Model Class Initialized
INFO - 2017-02-03 21:04:16 --> Controller Class Initialized
DEBUG - 2017-02-03 21:04:16 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 14
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 15
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 24
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 25
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 41
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 42
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 57
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 58
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 76
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 77
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 96
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 123
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 124
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 150
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 151
ERROR - 2017-02-03 21:04:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/module/home.php 160
ERROR - 2017-02-03 21:04:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/module/home.php 161
ERROR - 2017-02-03 21:04:16 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:05:30 --> Config Class Initialized
INFO - 2017-02-03 21:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:05:30 --> Utf8 Class Initialized
INFO - 2017-02-03 21:05:30 --> URI Class Initialized
DEBUG - 2017-02-03 21:05:30 --> No URI present. Default controller set.
INFO - 2017-02-03 21:05:30 --> Router Class Initialized
INFO - 2017-02-03 21:05:30 --> Output Class Initialized
INFO - 2017-02-03 21:05:30 --> Security Class Initialized
DEBUG - 2017-02-03 21:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:05:30 --> Input Class Initialized
INFO - 2017-02-03 21:05:30 --> Language Class Initialized
INFO - 2017-02-03 21:05:30 --> Language Class Initialized
INFO - 2017-02-03 21:05:30 --> Config Class Initialized
INFO - 2017-02-03 21:05:30 --> Loader Class Initialized
INFO - 2017-02-03 21:05:30 --> Helper loaded: url_helper
INFO - 2017-02-03 21:05:30 --> Helper loaded: file_helper
INFO - 2017-02-03 21:05:30 --> Database Driver Class Initialized
INFO - 2017-02-03 21:05:30 --> Model Class Initialized
INFO - 2017-02-03 21:05:30 --> Model Class Initialized
INFO - 2017-02-03 21:05:30 --> Controller Class Initialized
DEBUG - 2017-02-03 21:05:30 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 15
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 25
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 42
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 58
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 77
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 96
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 124
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 151
ERROR - 2017-02-03 21:05:30 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:05:30 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 161
ERROR - 2017-02-03 21:05:30 --> Severity: Error --> Call to undefined method MY_Loader::loadIklan() /var/www/html/wartabandung/application/modules/Welcome/views/home.php 176
INFO - 2017-02-03 21:06:15 --> Config Class Initialized
INFO - 2017-02-03 21:06:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:06:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:06:15 --> Utf8 Class Initialized
INFO - 2017-02-03 21:06:15 --> URI Class Initialized
DEBUG - 2017-02-03 21:06:15 --> No URI present. Default controller set.
INFO - 2017-02-03 21:06:15 --> Router Class Initialized
INFO - 2017-02-03 21:06:15 --> Output Class Initialized
INFO - 2017-02-03 21:06:15 --> Security Class Initialized
DEBUG - 2017-02-03 21:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:06:15 --> Input Class Initialized
INFO - 2017-02-03 21:06:15 --> Language Class Initialized
INFO - 2017-02-03 21:06:15 --> Language Class Initialized
INFO - 2017-02-03 21:06:15 --> Config Class Initialized
INFO - 2017-02-03 21:06:15 --> Loader Class Initialized
INFO - 2017-02-03 21:06:15 --> Helper loaded: url_helper
INFO - 2017-02-03 21:06:15 --> Helper loaded: file_helper
INFO - 2017-02-03 21:06:15 --> Database Driver Class Initialized
INFO - 2017-02-03 21:06:15 --> Model Class Initialized
INFO - 2017-02-03 21:06:15 --> Model Class Initialized
INFO - 2017-02-03 21:06:15 --> Controller Class Initialized
DEBUG - 2017-02-03 21:06:15 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 15
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 25
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 42
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 58
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 77
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 96
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 124
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 151
ERROR - 2017-02-03 21:06:15 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:06:15 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 161
ERROR - 2017-02-03 21:06:15 --> Severity: Error --> Call to undefined method MY_Loader::loadIklan() /var/www/html/wartabandung/application/modules/Welcome/views/home.php 176
INFO - 2017-02-03 21:09:14 --> Config Class Initialized
INFO - 2017-02-03 21:09:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:09:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:09:14 --> Utf8 Class Initialized
INFO - 2017-02-03 21:09:14 --> URI Class Initialized
DEBUG - 2017-02-03 21:09:14 --> No URI present. Default controller set.
INFO - 2017-02-03 21:09:14 --> Router Class Initialized
INFO - 2017-02-03 21:09:14 --> Output Class Initialized
INFO - 2017-02-03 21:09:14 --> Security Class Initialized
DEBUG - 2017-02-03 21:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:09:14 --> Input Class Initialized
INFO - 2017-02-03 21:09:14 --> Language Class Initialized
INFO - 2017-02-03 21:09:14 --> Language Class Initialized
INFO - 2017-02-03 21:09:14 --> Config Class Initialized
INFO - 2017-02-03 21:09:14 --> Loader Class Initialized
INFO - 2017-02-03 21:09:14 --> Helper loaded: url_helper
INFO - 2017-02-03 21:09:14 --> Helper loaded: file_helper
INFO - 2017-02-03 21:09:14 --> Database Driver Class Initialized
INFO - 2017-02-03 21:09:14 --> Model Class Initialized
INFO - 2017-02-03 21:09:14 --> Model Class Initialized
INFO - 2017-02-03 21:09:14 --> Controller Class Initialized
DEBUG - 2017-02-03 21:09:14 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 15
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 25
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 42
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 58
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 77
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 96
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 124
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 151
ERROR - 2017-02-03 21:09:14 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:09:14 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 161
ERROR - 2017-02-03 21:09:14 --> Severity: Error --> Call to undefined method MY_Loader::loadIklan() /var/www/html/wartabandung/application/modules/Welcome/views/home.php 176
INFO - 2017-02-03 21:09:16 --> Config Class Initialized
INFO - 2017-02-03 21:09:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:09:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:09:16 --> Utf8 Class Initialized
INFO - 2017-02-03 21:09:16 --> URI Class Initialized
DEBUG - 2017-02-03 21:09:16 --> No URI present. Default controller set.
INFO - 2017-02-03 21:09:16 --> Router Class Initialized
INFO - 2017-02-03 21:09:16 --> Output Class Initialized
INFO - 2017-02-03 21:09:16 --> Security Class Initialized
DEBUG - 2017-02-03 21:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:09:16 --> Input Class Initialized
INFO - 2017-02-03 21:09:16 --> Language Class Initialized
INFO - 2017-02-03 21:09:16 --> Language Class Initialized
INFO - 2017-02-03 21:09:16 --> Config Class Initialized
INFO - 2017-02-03 21:09:16 --> Loader Class Initialized
INFO - 2017-02-03 21:09:16 --> Helper loaded: url_helper
INFO - 2017-02-03 21:09:16 --> Helper loaded: file_helper
INFO - 2017-02-03 21:09:16 --> Database Driver Class Initialized
INFO - 2017-02-03 21:09:16 --> Model Class Initialized
INFO - 2017-02-03 21:09:16 --> Model Class Initialized
INFO - 2017-02-03 21:09:16 --> Controller Class Initialized
DEBUG - 2017-02-03 21:09:16 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 14
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 15
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 24
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 25
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 41
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 42
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 57
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 58
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 76
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 77
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 96
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 123
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 124
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 150
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 151
ERROR - 2017-02-03 21:09:16 --> Severity: 8192 --> mysql_query(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): Access denied for user ''@'localhost' (using password: NO) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_query(): A link to the server could not be established /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
ERROR - 2017-02-03 21:09:16 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 161
ERROR - 2017-02-03 21:09:16 --> Severity: Error --> Call to undefined method MY_Loader::loadIklan() /var/www/html/wartabandung/application/modules/Welcome/views/home.php 176
INFO - 2017-02-03 21:09:49 --> Config Class Initialized
INFO - 2017-02-03 21:09:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:09:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:09:49 --> Utf8 Class Initialized
INFO - 2017-02-03 21:09:49 --> URI Class Initialized
DEBUG - 2017-02-03 21:09:49 --> No URI present. Default controller set.
INFO - 2017-02-03 21:09:49 --> Router Class Initialized
INFO - 2017-02-03 21:09:49 --> Output Class Initialized
INFO - 2017-02-03 21:09:49 --> Security Class Initialized
DEBUG - 2017-02-03 21:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:09:49 --> Input Class Initialized
INFO - 2017-02-03 21:09:49 --> Language Class Initialized
INFO - 2017-02-03 21:09:49 --> Language Class Initialized
INFO - 2017-02-03 21:09:49 --> Config Class Initialized
INFO - 2017-02-03 21:09:49 --> Loader Class Initialized
INFO - 2017-02-03 21:09:49 --> Helper loaded: url_helper
INFO - 2017-02-03 21:09:49 --> Helper loaded: file_helper
INFO - 2017-02-03 21:09:49 --> Database Driver Class Initialized
INFO - 2017-02-03 21:09:49 --> Model Class Initialized
INFO - 2017-02-03 21:09:49 --> Model Class Initialized
INFO - 2017-02-03 21:09:49 --> Controller Class Initialized
DEBUG - 2017-02-03 21:09:49 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 16
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 17
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: rterkini /var/www/html/wartabandung/application/modules/Welcome/views/home.php 28
ERROR - 2017-02-03 21:09:49 --> Severity: Notice --> Undefined variable: qHl /var/www/html/wartabandung/application/modules/Welcome/views/home.php 44
ERROR - 2017-02-03 21:09:49 --> Severity: Error --> Call to a member function num_rows() on null /var/www/html/wartabandung/application/modules/Welcome/views/home.php 44
INFO - 2017-02-03 21:10:09 --> Config Class Initialized
INFO - 2017-02-03 21:10:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:10:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:10:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:10:09 --> URI Class Initialized
DEBUG - 2017-02-03 21:10:09 --> No URI present. Default controller set.
INFO - 2017-02-03 21:10:09 --> Router Class Initialized
INFO - 2017-02-03 21:10:09 --> Output Class Initialized
INFO - 2017-02-03 21:10:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:10:09 --> Input Class Initialized
INFO - 2017-02-03 21:10:09 --> Language Class Initialized
INFO - 2017-02-03 21:10:09 --> Language Class Initialized
INFO - 2017-02-03 21:10:09 --> Config Class Initialized
INFO - 2017-02-03 21:10:09 --> Loader Class Initialized
INFO - 2017-02-03 21:10:09 --> Helper loaded: url_helper
INFO - 2017-02-03 21:10:09 --> Helper loaded: file_helper
INFO - 2017-02-03 21:10:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:10:09 --> Model Class Initialized
INFO - 2017-02-03 21:10:09 --> Model Class Initialized
INFO - 2017-02-03 21:10:09 --> Controller Class Initialized
DEBUG - 2017-02-03 21:10:09 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:10:09 --> Severity: Notice --> Undefined variable: qHl /var/www/html/wartabandung/application/modules/Welcome/views/home.php 44
ERROR - 2017-02-03 21:10:09 --> Severity: Error --> Call to a member function num_rows() on null /var/www/html/wartabandung/application/modules/Welcome/views/home.php 44
INFO - 2017-02-03 21:10:25 --> Config Class Initialized
INFO - 2017-02-03 21:10:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:10:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:10:25 --> Utf8 Class Initialized
INFO - 2017-02-03 21:10:25 --> URI Class Initialized
DEBUG - 2017-02-03 21:10:25 --> No URI present. Default controller set.
INFO - 2017-02-03 21:10:25 --> Router Class Initialized
INFO - 2017-02-03 21:10:25 --> Output Class Initialized
INFO - 2017-02-03 21:10:25 --> Security Class Initialized
DEBUG - 2017-02-03 21:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:10:25 --> Input Class Initialized
INFO - 2017-02-03 21:10:25 --> Language Class Initialized
INFO - 2017-02-03 21:10:25 --> Language Class Initialized
INFO - 2017-02-03 21:10:25 --> Config Class Initialized
INFO - 2017-02-03 21:10:25 --> Loader Class Initialized
INFO - 2017-02-03 21:10:25 --> Helper loaded: url_helper
INFO - 2017-02-03 21:10:25 --> Helper loaded: file_helper
INFO - 2017-02-03 21:10:25 --> Database Driver Class Initialized
INFO - 2017-02-03 21:10:25 --> Model Class Initialized
INFO - 2017-02-03 21:10:25 --> Model Class Initialized
INFO - 2017-02-03 21:10:25 --> Controller Class Initialized
DEBUG - 2017-02-03 21:10:25 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:10:25 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 62
ERROR - 2017-02-03 21:10:25 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 90
ERROR - 2017-02-03 21:10:25 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 117
ERROR - 2017-02-03 21:10:25 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 127
ERROR - 2017-02-03 21:10:25 --> Severity: Error --> Call to undefined method MY_Loader::loadIklan() /var/www/html/wartabandung/application/modules/Welcome/views/home.php 142
INFO - 2017-02-03 21:12:58 --> Config Class Initialized
INFO - 2017-02-03 21:12:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:12:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:12:58 --> Utf8 Class Initialized
INFO - 2017-02-03 21:12:58 --> URI Class Initialized
DEBUG - 2017-02-03 21:12:58 --> No URI present. Default controller set.
INFO - 2017-02-03 21:12:58 --> Router Class Initialized
INFO - 2017-02-03 21:12:58 --> Output Class Initialized
INFO - 2017-02-03 21:12:58 --> Security Class Initialized
DEBUG - 2017-02-03 21:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:12:58 --> Input Class Initialized
INFO - 2017-02-03 21:12:58 --> Language Class Initialized
INFO - 2017-02-03 21:12:58 --> Language Class Initialized
INFO - 2017-02-03 21:12:58 --> Config Class Initialized
INFO - 2017-02-03 21:12:58 --> Loader Class Initialized
INFO - 2017-02-03 21:12:58 --> Helper loaded: url_helper
INFO - 2017-02-03 21:12:58 --> Helper loaded: file_helper
INFO - 2017-02-03 21:12:58 --> Database Driver Class Initialized
INFO - 2017-02-03 21:12:58 --> Model Class Initialized
INFO - 2017-02-03 21:12:58 --> Model Class Initialized
INFO - 2017-02-03 21:12:58 --> Controller Class Initialized
DEBUG - 2017-02-03 21:12:58 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:12:58 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 95
ERROR - 2017-02-03 21:12:58 --> Severity: Error --> Call to undefined method MY_Loader::loadIklan() /var/www/html/wartabandung/application/modules/Welcome/views/home.php 159
INFO - 2017-02-03 21:13:41 --> Config Class Initialized
INFO - 2017-02-03 21:13:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:13:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:13:41 --> Utf8 Class Initialized
INFO - 2017-02-03 21:13:41 --> URI Class Initialized
DEBUG - 2017-02-03 21:13:41 --> No URI present. Default controller set.
INFO - 2017-02-03 21:13:41 --> Router Class Initialized
INFO - 2017-02-03 21:13:41 --> Output Class Initialized
INFO - 2017-02-03 21:13:41 --> Security Class Initialized
DEBUG - 2017-02-03 21:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:13:41 --> Input Class Initialized
INFO - 2017-02-03 21:13:41 --> Language Class Initialized
INFO - 2017-02-03 21:13:41 --> Language Class Initialized
INFO - 2017-02-03 21:13:41 --> Config Class Initialized
INFO - 2017-02-03 21:13:41 --> Loader Class Initialized
INFO - 2017-02-03 21:13:41 --> Helper loaded: url_helper
INFO - 2017-02-03 21:13:41 --> Helper loaded: file_helper
INFO - 2017-02-03 21:13:41 --> Database Driver Class Initialized
INFO - 2017-02-03 21:13:41 --> Model Class Initialized
INFO - 2017-02-03 21:13:41 --> Model Class Initialized
INFO - 2017-02-03 21:13:41 --> Controller Class Initialized
DEBUG - 2017-02-03 21:13:41 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:13:41 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/html/wartabandung/application/modules/Welcome/views/home.php 96
INFO - 2017-02-03 21:13:55 --> Config Class Initialized
INFO - 2017-02-03 21:13:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:13:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:13:55 --> Utf8 Class Initialized
INFO - 2017-02-03 21:13:55 --> URI Class Initialized
DEBUG - 2017-02-03 21:13:55 --> No URI present. Default controller set.
INFO - 2017-02-03 21:13:55 --> Router Class Initialized
INFO - 2017-02-03 21:13:55 --> Output Class Initialized
INFO - 2017-02-03 21:13:55 --> Security Class Initialized
DEBUG - 2017-02-03 21:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:13:55 --> Input Class Initialized
INFO - 2017-02-03 21:13:55 --> Language Class Initialized
INFO - 2017-02-03 21:13:55 --> Language Class Initialized
INFO - 2017-02-03 21:13:55 --> Config Class Initialized
INFO - 2017-02-03 21:13:55 --> Loader Class Initialized
INFO - 2017-02-03 21:13:55 --> Helper loaded: url_helper
INFO - 2017-02-03 21:13:55 --> Helper loaded: file_helper
INFO - 2017-02-03 21:13:55 --> Database Driver Class Initialized
INFO - 2017-02-03 21:13:55 --> Model Class Initialized
INFO - 2017-02-03 21:13:55 --> Model Class Initialized
INFO - 2017-02-03 21:13:55 --> Controller Class Initialized
DEBUG - 2017-02-03 21:13:55 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:13:55 --> Severity: Error --> Call to undefined method MY_Loader::loadIklan() /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
INFO - 2017-02-03 21:14:24 --> Config Class Initialized
INFO - 2017-02-03 21:14:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:14:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:14:24 --> Utf8 Class Initialized
INFO - 2017-02-03 21:14:24 --> URI Class Initialized
DEBUG - 2017-02-03 21:14:24 --> No URI present. Default controller set.
INFO - 2017-02-03 21:14:24 --> Router Class Initialized
INFO - 2017-02-03 21:14:24 --> Output Class Initialized
INFO - 2017-02-03 21:14:24 --> Security Class Initialized
DEBUG - 2017-02-03 21:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:14:24 --> Input Class Initialized
INFO - 2017-02-03 21:14:24 --> Language Class Initialized
INFO - 2017-02-03 21:14:24 --> Language Class Initialized
INFO - 2017-02-03 21:14:24 --> Config Class Initialized
INFO - 2017-02-03 21:14:24 --> Loader Class Initialized
INFO - 2017-02-03 21:14:24 --> Helper loaded: url_helper
INFO - 2017-02-03 21:14:24 --> Helper loaded: file_helper
INFO - 2017-02-03 21:14:24 --> Database Driver Class Initialized
INFO - 2017-02-03 21:14:24 --> Model Class Initialized
INFO - 2017-02-03 21:14:24 --> Model Class Initialized
INFO - 2017-02-03 21:14:24 --> Controller Class Initialized
DEBUG - 2017-02-03 21:14:24 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:14:24 --> Severity: Notice --> Undefined property: CI::$main_models /var/www/html/wartabandung/application/third_party/MX/Loader.php 304
ERROR - 2017-02-03 21:14:24 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/application/modules/Welcome/views/home.php 160
INFO - 2017-02-03 21:14:51 --> Config Class Initialized
INFO - 2017-02-03 21:14:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:14:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:14:51 --> Utf8 Class Initialized
INFO - 2017-02-03 21:14:51 --> URI Class Initialized
DEBUG - 2017-02-03 21:14:51 --> No URI present. Default controller set.
INFO - 2017-02-03 21:14:51 --> Router Class Initialized
INFO - 2017-02-03 21:14:51 --> Output Class Initialized
INFO - 2017-02-03 21:14:51 --> Security Class Initialized
DEBUG - 2017-02-03 21:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:14:51 --> Input Class Initialized
INFO - 2017-02-03 21:14:51 --> Language Class Initialized
INFO - 2017-02-03 21:14:51 --> Language Class Initialized
INFO - 2017-02-03 21:14:51 --> Config Class Initialized
INFO - 2017-02-03 21:14:51 --> Loader Class Initialized
INFO - 2017-02-03 21:14:51 --> Helper loaded: url_helper
INFO - 2017-02-03 21:14:51 --> Helper loaded: file_helper
INFO - 2017-02-03 21:14:51 --> Database Driver Class Initialized
INFO - 2017-02-03 21:14:51 --> Model Class Initialized
INFO - 2017-02-03 21:14:51 --> Model Class Initialized
INFO - 2017-02-03 21:14:51 --> Controller Class Initialized
DEBUG - 2017-02-03 21:14:51 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:14:51 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 36
INFO - 2017-02-03 21:15:27 --> Config Class Initialized
INFO - 2017-02-03 21:15:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:15:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:15:27 --> Utf8 Class Initialized
INFO - 2017-02-03 21:15:27 --> URI Class Initialized
DEBUG - 2017-02-03 21:15:27 --> No URI present. Default controller set.
INFO - 2017-02-03 21:15:27 --> Router Class Initialized
INFO - 2017-02-03 21:15:27 --> Output Class Initialized
INFO - 2017-02-03 21:15:27 --> Security Class Initialized
DEBUG - 2017-02-03 21:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:15:27 --> Input Class Initialized
INFO - 2017-02-03 21:15:27 --> Language Class Initialized
INFO - 2017-02-03 21:15:27 --> Language Class Initialized
INFO - 2017-02-03 21:15:27 --> Config Class Initialized
INFO - 2017-02-03 21:15:27 --> Loader Class Initialized
INFO - 2017-02-03 21:15:27 --> Helper loaded: url_helper
INFO - 2017-02-03 21:15:27 --> Helper loaded: file_helper
INFO - 2017-02-03 21:15:27 --> Database Driver Class Initialized
INFO - 2017-02-03 21:15:27 --> Model Class Initialized
INFO - 2017-02-03 21:15:27 --> Model Class Initialized
INFO - 2017-02-03 21:15:27 --> Controller Class Initialized
DEBUG - 2017-02-03 21:15:27 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:15:27 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/modules/Welcome/views/home.php 173
DEBUG - 2017-02-03 21:15:27 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
ERROR - 2017-02-03 21:15:27 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 21:15:27 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 20
INFO - 2017-02-03 21:16:09 --> Config Class Initialized
INFO - 2017-02-03 21:16:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:16:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:16:09 --> Utf8 Class Initialized
INFO - 2017-02-03 21:16:09 --> URI Class Initialized
DEBUG - 2017-02-03 21:16:09 --> No URI present. Default controller set.
INFO - 2017-02-03 21:16:09 --> Router Class Initialized
INFO - 2017-02-03 21:16:09 --> Output Class Initialized
INFO - 2017-02-03 21:16:09 --> Security Class Initialized
DEBUG - 2017-02-03 21:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:16:09 --> Input Class Initialized
INFO - 2017-02-03 21:16:09 --> Language Class Initialized
INFO - 2017-02-03 21:16:09 --> Language Class Initialized
INFO - 2017-02-03 21:16:09 --> Config Class Initialized
INFO - 2017-02-03 21:16:09 --> Loader Class Initialized
INFO - 2017-02-03 21:16:09 --> Helper loaded: url_helper
INFO - 2017-02-03 21:16:09 --> Helper loaded: file_helper
INFO - 2017-02-03 21:16:09 --> Database Driver Class Initialized
INFO - 2017-02-03 21:16:09 --> Model Class Initialized
INFO - 2017-02-03 21:16:09 --> Model Class Initialized
INFO - 2017-02-03 21:16:09 --> Controller Class Initialized
DEBUG - 2017-02-03 21:16:09 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:16:09 --> Severity: Notice --> Undefined property: CI::$main_mode /var/www/html/wartabandung/application/third_party/MX/Loader.php 304
ERROR - 2017-02-03 21:16:09 --> Severity: Error --> Call to a member function listPostHome() on null /var/www/html/wartabandung/application/modules/Welcome/views/home.php 178
INFO - 2017-02-03 21:16:50 --> Config Class Initialized
INFO - 2017-02-03 21:16:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:16:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:16:50 --> Utf8 Class Initialized
INFO - 2017-02-03 21:16:50 --> URI Class Initialized
DEBUG - 2017-02-03 21:16:50 --> No URI present. Default controller set.
INFO - 2017-02-03 21:16:50 --> Router Class Initialized
INFO - 2017-02-03 21:16:50 --> Output Class Initialized
INFO - 2017-02-03 21:16:50 --> Security Class Initialized
DEBUG - 2017-02-03 21:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:16:50 --> Input Class Initialized
INFO - 2017-02-03 21:16:50 --> Language Class Initialized
INFO - 2017-02-03 21:16:50 --> Language Class Initialized
INFO - 2017-02-03 21:16:50 --> Config Class Initialized
INFO - 2017-02-03 21:16:50 --> Loader Class Initialized
INFO - 2017-02-03 21:16:50 --> Helper loaded: url_helper
INFO - 2017-02-03 21:16:50 --> Helper loaded: file_helper
INFO - 2017-02-03 21:16:50 --> Database Driver Class Initialized
INFO - 2017-02-03 21:16:50 --> Model Class Initialized
INFO - 2017-02-03 21:16:50 --> Model Class Initialized
INFO - 2017-02-03 21:16:50 --> Controller Class Initialized
DEBUG - 2017-02-03 21:16:50 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 105
ERROR - 2017-02-03 21:16:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 106
DEBUG - 2017-02-03 21:16:50 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
ERROR - 2017-02-03 21:16:50 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 21:16:50 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 20
INFO - 2017-02-03 21:17:38 --> Config Class Initialized
INFO - 2017-02-03 21:17:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:17:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:17:38 --> Utf8 Class Initialized
INFO - 2017-02-03 21:17:38 --> URI Class Initialized
DEBUG - 2017-02-03 21:17:38 --> No URI present. Default controller set.
INFO - 2017-02-03 21:17:38 --> Router Class Initialized
INFO - 2017-02-03 21:17:38 --> Output Class Initialized
INFO - 2017-02-03 21:17:38 --> Security Class Initialized
DEBUG - 2017-02-03 21:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:17:38 --> Input Class Initialized
INFO - 2017-02-03 21:17:38 --> Language Class Initialized
INFO - 2017-02-03 21:17:38 --> Language Class Initialized
INFO - 2017-02-03 21:17:38 --> Config Class Initialized
INFO - 2017-02-03 21:17:38 --> Loader Class Initialized
INFO - 2017-02-03 21:17:38 --> Helper loaded: url_helper
INFO - 2017-02-03 21:17:38 --> Helper loaded: file_helper
INFO - 2017-02-03 21:17:38 --> Database Driver Class Initialized
INFO - 2017-02-03 21:17:38 --> Model Class Initialized
INFO - 2017-02-03 21:17:38 --> Model Class Initialized
INFO - 2017-02-03 21:17:38 --> Controller Class Initialized
DEBUG - 2017-02-03 21:17:38 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:17:38 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given /var/www/html/wartabandung/application/models/Main_model.php 118
DEBUG - 2017-02-03 21:17:38 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
ERROR - 2017-02-03 21:17:38 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 21:17:38 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 20
INFO - 2017-02-03 21:18:26 --> Config Class Initialized
INFO - 2017-02-03 21:18:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:18:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:18:26 --> Utf8 Class Initialized
INFO - 2017-02-03 21:18:26 --> URI Class Initialized
DEBUG - 2017-02-03 21:18:26 --> No URI present. Default controller set.
INFO - 2017-02-03 21:18:26 --> Router Class Initialized
INFO - 2017-02-03 21:18:26 --> Output Class Initialized
INFO - 2017-02-03 21:18:26 --> Security Class Initialized
DEBUG - 2017-02-03 21:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:18:26 --> Input Class Initialized
INFO - 2017-02-03 21:18:26 --> Language Class Initialized
INFO - 2017-02-03 21:18:26 --> Language Class Initialized
INFO - 2017-02-03 21:18:26 --> Config Class Initialized
INFO - 2017-02-03 21:18:26 --> Loader Class Initialized
INFO - 2017-02-03 21:18:26 --> Helper loaded: url_helper
INFO - 2017-02-03 21:18:26 --> Helper loaded: file_helper
INFO - 2017-02-03 21:18:26 --> Database Driver Class Initialized
INFO - 2017-02-03 21:18:26 --> Model Class Initialized
INFO - 2017-02-03 21:18:26 --> Model Class Initialized
INFO - 2017-02-03 21:18:26 --> Controller Class Initialized
DEBUG - 2017-02-03 21:18:26 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 21:18:26 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
ERROR - 2017-02-03 21:18:26 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/views/index.php 148
ERROR - 2017-02-03 21:18:26 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 20
INFO - 2017-02-03 21:19:16 --> Config Class Initialized
INFO - 2017-02-03 21:19:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:19:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:19:16 --> Utf8 Class Initialized
INFO - 2017-02-03 21:19:16 --> URI Class Initialized
DEBUG - 2017-02-03 21:19:16 --> No URI present. Default controller set.
INFO - 2017-02-03 21:19:16 --> Router Class Initialized
INFO - 2017-02-03 21:19:16 --> Output Class Initialized
INFO - 2017-02-03 21:19:16 --> Security Class Initialized
DEBUG - 2017-02-03 21:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:19:16 --> Input Class Initialized
INFO - 2017-02-03 21:19:16 --> Language Class Initialized
INFO - 2017-02-03 21:19:16 --> Language Class Initialized
INFO - 2017-02-03 21:19:16 --> Config Class Initialized
INFO - 2017-02-03 21:19:16 --> Loader Class Initialized
INFO - 2017-02-03 21:19:16 --> Helper loaded: url_helper
INFO - 2017-02-03 21:19:16 --> Helper loaded: file_helper
INFO - 2017-02-03 21:19:16 --> Database Driver Class Initialized
INFO - 2017-02-03 21:19:16 --> Model Class Initialized
INFO - 2017-02-03 21:19:16 --> Model Class Initialized
INFO - 2017-02-03 21:19:16 --> Controller Class Initialized
DEBUG - 2017-02-03 21:19:16 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 21:19:16 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
ERROR - 2017-02-03 21:19:16 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/wartabandung/application/models/Main_model.php 20
INFO - 2017-02-03 21:19:53 --> Config Class Initialized
INFO - 2017-02-03 21:19:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:19:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:19:53 --> Utf8 Class Initialized
INFO - 2017-02-03 21:19:53 --> URI Class Initialized
DEBUG - 2017-02-03 21:19:53 --> No URI present. Default controller set.
INFO - 2017-02-03 21:19:53 --> Router Class Initialized
INFO - 2017-02-03 21:19:53 --> Output Class Initialized
INFO - 2017-02-03 21:19:53 --> Security Class Initialized
DEBUG - 2017-02-03 21:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:19:53 --> Input Class Initialized
INFO - 2017-02-03 21:19:53 --> Language Class Initialized
INFO - 2017-02-03 21:19:53 --> Language Class Initialized
INFO - 2017-02-03 21:19:53 --> Config Class Initialized
INFO - 2017-02-03 21:19:53 --> Loader Class Initialized
INFO - 2017-02-03 21:19:53 --> Helper loaded: url_helper
INFO - 2017-02-03 21:19:53 --> Helper loaded: file_helper
INFO - 2017-02-03 21:19:53 --> Database Driver Class Initialized
INFO - 2017-02-03 21:19:53 --> Model Class Initialized
INFO - 2017-02-03 21:19:53 --> Model Class Initialized
INFO - 2017-02-03 21:19:53 --> Controller Class Initialized
DEBUG - 2017-02-03 21:19:53 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:19:53 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 21:19:53 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 21:19:53 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 21:19:53 --> Final output sent to browser
DEBUG - 2017-02-03 21:19:53 --> Total execution time: 0.0848
INFO - 2017-02-03 21:20:15 --> Config Class Initialized
INFO - 2017-02-03 21:20:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:20:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:20:15 --> Utf8 Class Initialized
INFO - 2017-02-03 21:20:15 --> URI Class Initialized
DEBUG - 2017-02-03 21:20:15 --> No URI present. Default controller set.
INFO - 2017-02-03 21:20:15 --> Router Class Initialized
INFO - 2017-02-03 21:20:15 --> Output Class Initialized
INFO - 2017-02-03 21:20:15 --> Security Class Initialized
DEBUG - 2017-02-03 21:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:20:15 --> Input Class Initialized
INFO - 2017-02-03 21:20:15 --> Language Class Initialized
INFO - 2017-02-03 21:20:15 --> Language Class Initialized
INFO - 2017-02-03 21:20:15 --> Config Class Initialized
INFO - 2017-02-03 21:20:15 --> Loader Class Initialized
INFO - 2017-02-03 21:20:15 --> Helper loaded: url_helper
INFO - 2017-02-03 21:20:15 --> Helper loaded: file_helper
INFO - 2017-02-03 21:20:15 --> Database Driver Class Initialized
INFO - 2017-02-03 21:20:15 --> Model Class Initialized
INFO - 2017-02-03 21:20:15 --> Model Class Initialized
INFO - 2017-02-03 21:20:15 --> Controller Class Initialized
DEBUG - 2017-02-03 21:20:15 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:15 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 21:20:15 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 21:20:15 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 21:20:15 --> Final output sent to browser
DEBUG - 2017-02-03 21:20:15 --> Total execution time: 0.0657
INFO - 2017-02-03 21:20:20 --> Config Class Initialized
INFO - 2017-02-03 21:20:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:20:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:20:20 --> Utf8 Class Initialized
INFO - 2017-02-03 21:20:20 --> URI Class Initialized
DEBUG - 2017-02-03 21:20:20 --> No URI present. Default controller set.
INFO - 2017-02-03 21:20:20 --> Router Class Initialized
INFO - 2017-02-03 21:20:20 --> Output Class Initialized
INFO - 2017-02-03 21:20:20 --> Security Class Initialized
DEBUG - 2017-02-03 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:20:20 --> Input Class Initialized
INFO - 2017-02-03 21:20:20 --> Language Class Initialized
INFO - 2017-02-03 21:20:20 --> Language Class Initialized
INFO - 2017-02-03 21:20:20 --> Config Class Initialized
INFO - 2017-02-03 21:20:20 --> Loader Class Initialized
INFO - 2017-02-03 21:20:20 --> Helper loaded: url_helper
INFO - 2017-02-03 21:20:20 --> Helper loaded: file_helper
INFO - 2017-02-03 21:20:20 --> Database Driver Class Initialized
INFO - 2017-02-03 21:20:20 --> Model Class Initialized
INFO - 2017-02-03 21:20:20 --> Model Class Initialized
INFO - 2017-02-03 21:20:20 --> Controller Class Initialized
DEBUG - 2017-02-03 21:20:20 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:20:20 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 21:20:20 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 21:20:20 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 21:20:20 --> Final output sent to browser
DEBUG - 2017-02-03 21:20:20 --> Total execution time: 0.0484
INFO - 2017-02-03 21:20:21 --> Config Class Initialized
INFO - 2017-02-03 21:20:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:20:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:20:21 --> Utf8 Class Initialized
INFO - 2017-02-03 21:20:21 --> URI Class Initialized
INFO - 2017-02-03 21:20:21 --> Router Class Initialized
INFO - 2017-02-03 21:20:21 --> Output Class Initialized
INFO - 2017-02-03 21:20:21 --> Security Class Initialized
DEBUG - 2017-02-03 21:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:20:21 --> Input Class Initialized
INFO - 2017-02-03 21:20:21 --> Language Class Initialized
ERROR - 2017-02-03 21:20:21 --> 404 Page Not Found: /index
INFO - 2017-02-03 21:21:33 --> Config Class Initialized
INFO - 2017-02-03 21:21:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:21:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:21:33 --> Utf8 Class Initialized
INFO - 2017-02-03 21:21:33 --> URI Class Initialized
DEBUG - 2017-02-03 21:21:33 --> No URI present. Default controller set.
INFO - 2017-02-03 21:21:33 --> Router Class Initialized
INFO - 2017-02-03 21:21:33 --> Output Class Initialized
INFO - 2017-02-03 21:21:33 --> Security Class Initialized
DEBUG - 2017-02-03 21:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:21:33 --> Input Class Initialized
INFO - 2017-02-03 21:21:33 --> Language Class Initialized
INFO - 2017-02-03 21:21:33 --> Language Class Initialized
INFO - 2017-02-03 21:21:33 --> Config Class Initialized
INFO - 2017-02-03 21:21:33 --> Loader Class Initialized
INFO - 2017-02-03 21:21:33 --> Helper loaded: url_helper
INFO - 2017-02-03 21:21:33 --> Helper loaded: file_helper
INFO - 2017-02-03 21:21:33 --> Database Driver Class Initialized
INFO - 2017-02-03 21:21:33 --> Model Class Initialized
INFO - 2017-02-03 21:21:33 --> Model Class Initialized
INFO - 2017-02-03 21:21:33 --> Controller Class Initialized
DEBUG - 2017-02-03 21:21:33 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 21:21:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 21:21:33 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 21:21:33 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 21:21:33 --> Final output sent to browser
DEBUG - 2017-02-03 21:21:33 --> Total execution time: 0.1298
INFO - 2017-02-03 21:21:33 --> Config Class Initialized
INFO - 2017-02-03 21:21:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 21:21:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 21:21:33 --> Utf8 Class Initialized
INFO - 2017-02-03 21:21:33 --> URI Class Initialized
INFO - 2017-02-03 21:21:33 --> Router Class Initialized
INFO - 2017-02-03 21:21:33 --> Output Class Initialized
INFO - 2017-02-03 21:21:33 --> Security Class Initialized
DEBUG - 2017-02-03 21:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 21:21:33 --> Input Class Initialized
INFO - 2017-02-03 21:21:33 --> Language Class Initialized
ERROR - 2017-02-03 21:21:33 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:40:16 --> Config Class Initialized
INFO - 2017-02-03 22:40:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:40:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:40:16 --> Utf8 Class Initialized
INFO - 2017-02-03 22:40:16 --> URI Class Initialized
DEBUG - 2017-02-03 22:40:16 --> No URI present. Default controller set.
INFO - 2017-02-03 22:40:16 --> Router Class Initialized
INFO - 2017-02-03 22:40:16 --> Output Class Initialized
INFO - 2017-02-03 22:40:16 --> Security Class Initialized
DEBUG - 2017-02-03 22:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:40:16 --> Input Class Initialized
INFO - 2017-02-03 22:40:16 --> Language Class Initialized
INFO - 2017-02-03 22:40:16 --> Language Class Initialized
INFO - 2017-02-03 22:40:16 --> Config Class Initialized
INFO - 2017-02-03 22:40:16 --> Loader Class Initialized
INFO - 2017-02-03 22:40:16 --> Helper loaded: url_helper
INFO - 2017-02-03 22:40:16 --> Helper loaded: file_helper
INFO - 2017-02-03 22:40:16 --> Database Driver Class Initialized
INFO - 2017-02-03 22:40:16 --> Model Class Initialized
INFO - 2017-02-03 22:40:16 --> Model Class Initialized
INFO - 2017-02-03 22:40:16 --> Controller Class Initialized
DEBUG - 2017-02-03 22:40:16 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:40:16 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:40:16 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:40:16 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:40:16 --> Final output sent to browser
DEBUG - 2017-02-03 22:40:16 --> Total execution time: 0.0433
INFO - 2017-02-03 22:40:19 --> Config Class Initialized
INFO - 2017-02-03 22:40:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:40:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:40:19 --> Utf8 Class Initialized
INFO - 2017-02-03 22:40:20 --> URI Class Initialized
INFO - 2017-02-03 22:40:20 --> Router Class Initialized
INFO - 2017-02-03 22:40:20 --> Output Class Initialized
INFO - 2017-02-03 22:40:20 --> Security Class Initialized
DEBUG - 2017-02-03 22:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:40:20 --> Input Class Initialized
INFO - 2017-02-03 22:40:20 --> Language Class Initialized
ERROR - 2017-02-03 22:40:20 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:41:05 --> Config Class Initialized
INFO - 2017-02-03 22:41:05 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:41:05 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:41:05 --> Utf8 Class Initialized
INFO - 2017-02-03 22:41:05 --> URI Class Initialized
DEBUG - 2017-02-03 22:41:05 --> No URI present. Default controller set.
INFO - 2017-02-03 22:41:05 --> Router Class Initialized
INFO - 2017-02-03 22:41:05 --> Output Class Initialized
INFO - 2017-02-03 22:41:05 --> Security Class Initialized
DEBUG - 2017-02-03 22:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:41:05 --> Input Class Initialized
INFO - 2017-02-03 22:41:05 --> Language Class Initialized
INFO - 2017-02-03 22:41:05 --> Language Class Initialized
INFO - 2017-02-03 22:41:05 --> Config Class Initialized
INFO - 2017-02-03 22:41:05 --> Loader Class Initialized
INFO - 2017-02-03 22:41:05 --> Helper loaded: url_helper
INFO - 2017-02-03 22:41:05 --> Helper loaded: file_helper
INFO - 2017-02-03 22:41:05 --> Database Driver Class Initialized
INFO - 2017-02-03 22:41:05 --> Model Class Initialized
INFO - 2017-02-03 22:41:05 --> Model Class Initialized
INFO - 2017-02-03 22:41:05 --> Controller Class Initialized
DEBUG - 2017-02-03 22:41:05 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:05 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:41:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:41:06 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:41:06 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:41:06 --> Final output sent to browser
DEBUG - 2017-02-03 22:41:06 --> Total execution time: 0.2148
INFO - 2017-02-03 22:41:06 --> Config Class Initialized
INFO - 2017-02-03 22:41:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:41:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:41:06 --> Utf8 Class Initialized
INFO - 2017-02-03 22:41:06 --> URI Class Initialized
INFO - 2017-02-03 22:41:06 --> Router Class Initialized
INFO - 2017-02-03 22:41:06 --> Output Class Initialized
INFO - 2017-02-03 22:41:06 --> Security Class Initialized
DEBUG - 2017-02-03 22:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:41:06 --> Input Class Initialized
INFO - 2017-02-03 22:41:06 --> Language Class Initialized
ERROR - 2017-02-03 22:41:06 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:46:58 --> Config Class Initialized
INFO - 2017-02-03 22:46:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:46:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:46:58 --> Utf8 Class Initialized
INFO - 2017-02-03 22:46:58 --> URI Class Initialized
INFO - 2017-02-03 22:46:58 --> Router Class Initialized
INFO - 2017-02-03 22:46:58 --> Output Class Initialized
INFO - 2017-02-03 22:46:58 --> Security Class Initialized
DEBUG - 2017-02-03 22:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:46:58 --> Input Class Initialized
INFO - 2017-02-03 22:46:58 --> Language Class Initialized
INFO - 2017-02-03 22:46:58 --> Language Class Initialized
INFO - 2017-02-03 22:46:58 --> Config Class Initialized
INFO - 2017-02-03 22:46:58 --> Loader Class Initialized
INFO - 2017-02-03 22:46:58 --> Helper loaded: url_helper
INFO - 2017-02-03 22:46:58 --> Helper loaded: file_helper
INFO - 2017-02-03 22:46:58 --> Database Driver Class Initialized
INFO - 2017-02-03 22:46:58 --> Model Class Initialized
INFO - 2017-02-03 22:46:58 --> Model Class Initialized
INFO - 2017-02-03 22:46:58 --> Controller Class Initialized
ERROR - 2017-02-03 22:46:58 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/BERITA
INFO - 2017-02-03 22:48:20 --> Config Class Initialized
INFO - 2017-02-03 22:48:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:20 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:20 --> URI Class Initialized
INFO - 2017-02-03 22:48:20 --> Router Class Initialized
INFO - 2017-02-03 22:48:20 --> Output Class Initialized
INFO - 2017-02-03 22:48:20 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:20 --> Input Class Initialized
INFO - 2017-02-03 22:48:20 --> Language Class Initialized
INFO - 2017-02-03 22:48:20 --> Language Class Initialized
INFO - 2017-02-03 22:48:20 --> Config Class Initialized
INFO - 2017-02-03 22:48:20 --> Loader Class Initialized
INFO - 2017-02-03 22:48:20 --> Helper loaded: url_helper
INFO - 2017-02-03 22:48:20 --> Helper loaded: file_helper
INFO - 2017-02-03 22:48:20 --> Database Driver Class Initialized
INFO - 2017-02-03 22:48:20 --> Model Class Initialized
INFO - 2017-02-03 22:48:20 --> Model Class Initialized
INFO - 2017-02-03 22:48:20 --> Controller Class Initialized
ERROR - 2017-02-03 22:48:20 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/BERITA
INFO - 2017-02-03 22:48:33 --> Config Class Initialized
INFO - 2017-02-03 22:48:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:33 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:33 --> URI Class Initialized
INFO - 2017-02-03 22:48:33 --> Router Class Initialized
INFO - 2017-02-03 22:48:33 --> Output Class Initialized
INFO - 2017-02-03 22:48:33 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:33 --> Input Class Initialized
INFO - 2017-02-03 22:48:33 --> Language Class Initialized
INFO - 2017-02-03 22:48:33 --> Language Class Initialized
INFO - 2017-02-03 22:48:33 --> Config Class Initialized
INFO - 2017-02-03 22:48:33 --> Loader Class Initialized
INFO - 2017-02-03 22:48:33 --> Helper loaded: url_helper
INFO - 2017-02-03 22:48:33 --> Helper loaded: file_helper
INFO - 2017-02-03 22:48:33 --> Database Driver Class Initialized
INFO - 2017-02-03 22:48:33 --> Model Class Initialized
INFO - 2017-02-03 22:48:33 --> Model Class Initialized
INFO - 2017-02-03 22:48:33 --> Controller Class Initialized
ERROR - 2017-02-03 22:48:33 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/BERITA
INFO - 2017-02-03 22:48:49 --> Config Class Initialized
INFO - 2017-02-03 22:48:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:49 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:49 --> URI Class Initialized
INFO - 2017-02-03 22:48:49 --> Router Class Initialized
INFO - 2017-02-03 22:48:49 --> Output Class Initialized
INFO - 2017-02-03 22:48:49 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:49 --> Input Class Initialized
INFO - 2017-02-03 22:48:49 --> Language Class Initialized
INFO - 2017-02-03 22:48:49 --> Language Class Initialized
INFO - 2017-02-03 22:48:49 --> Config Class Initialized
INFO - 2017-02-03 22:48:49 --> Loader Class Initialized
INFO - 2017-02-03 22:48:49 --> Helper loaded: url_helper
INFO - 2017-02-03 22:48:49 --> Helper loaded: file_helper
INFO - 2017-02-03 22:48:49 --> Database Driver Class Initialized
INFO - 2017-02-03 22:48:49 --> Model Class Initialized
INFO - 2017-02-03 22:48:49 --> Model Class Initialized
INFO - 2017-02-03 22:48:49 --> Controller Class Initialized
DEBUG - 2017-02-03 22:48:49 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 22:48:49 --> Config Class Initialized
INFO - 2017-02-03 22:48:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:49 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:49 --> URI Class Initialized
INFO - 2017-02-03 22:48:49 --> Router Class Initialized
INFO - 2017-02-03 22:48:49 --> Output Class Initialized
INFO - 2017-02-03 22:48:49 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:49 --> Input Class Initialized
INFO - 2017-02-03 22:48:49 --> Language Class Initialized
ERROR - 2017-02-03 22:48:49 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:48:49 --> Config Class Initialized
INFO - 2017-02-03 22:48:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:49 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:49 --> URI Class Initialized
INFO - 2017-02-03 22:48:49 --> Router Class Initialized
INFO - 2017-02-03 22:48:49 --> Output Class Initialized
INFO - 2017-02-03 22:48:49 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:49 --> Input Class Initialized
INFO - 2017-02-03 22:48:49 --> Language Class Initialized
ERROR - 2017-02-03 22:48:49 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:48:49 --> Config Class Initialized
INFO - 2017-02-03 22:48:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:48:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:48:49 --> Utf8 Class Initialized
INFO - 2017-02-03 22:48:49 --> URI Class Initialized
INFO - 2017-02-03 22:48:49 --> Router Class Initialized
INFO - 2017-02-03 22:48:49 --> Output Class Initialized
INFO - 2017-02-03 22:48:49 --> Security Class Initialized
DEBUG - 2017-02-03 22:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:48:49 --> Input Class Initialized
INFO - 2017-02-03 22:48:49 --> Language Class Initialized
ERROR - 2017-02-03 22:48:49 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:49:22 --> Config Class Initialized
INFO - 2017-02-03 22:49:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:22 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:22 --> URI Class Initialized
INFO - 2017-02-03 22:49:22 --> Router Class Initialized
INFO - 2017-02-03 22:49:22 --> Output Class Initialized
INFO - 2017-02-03 22:49:22 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:22 --> Input Class Initialized
INFO - 2017-02-03 22:49:22 --> Language Class Initialized
INFO - 2017-02-03 22:49:22 --> Language Class Initialized
INFO - 2017-02-03 22:49:22 --> Config Class Initialized
INFO - 2017-02-03 22:49:22 --> Loader Class Initialized
INFO - 2017-02-03 22:49:22 --> Helper loaded: url_helper
INFO - 2017-02-03 22:49:22 --> Helper loaded: file_helper
INFO - 2017-02-03 22:49:22 --> Database Driver Class Initialized
INFO - 2017-02-03 22:49:22 --> Model Class Initialized
INFO - 2017-02-03 22:49:22 --> Model Class Initialized
INFO - 2017-02-03 22:49:22 --> Controller Class Initialized
DEBUG - 2017-02-03 22:49:22 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 22:49:22 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/models/Main_model.php 287
ERROR - 2017-02-03 22:49:22 --> Severity: Error --> Class 'PageNumber' not found /var/www/html/wartabandung/application/models/Main_model.php 607
INFO - 2017-02-03 22:49:22 --> Config Class Initialized
INFO - 2017-02-03 22:49:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:22 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:22 --> URI Class Initialized
INFO - 2017-02-03 22:49:22 --> Router Class Initialized
INFO - 2017-02-03 22:49:22 --> Output Class Initialized
INFO - 2017-02-03 22:49:22 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:22 --> Input Class Initialized
INFO - 2017-02-03 22:49:22 --> Language Class Initialized
ERROR - 2017-02-03 22:49:22 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:49:22 --> Config Class Initialized
INFO - 2017-02-03 22:49:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:22 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:22 --> URI Class Initialized
INFO - 2017-02-03 22:49:22 --> Router Class Initialized
INFO - 2017-02-03 22:49:22 --> Output Class Initialized
INFO - 2017-02-03 22:49:22 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:22 --> Input Class Initialized
INFO - 2017-02-03 22:49:22 --> Language Class Initialized
ERROR - 2017-02-03 22:49:22 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:49:22 --> Config Class Initialized
INFO - 2017-02-03 22:49:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:22 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:22 --> URI Class Initialized
INFO - 2017-02-03 22:49:22 --> Router Class Initialized
INFO - 2017-02-03 22:49:22 --> Output Class Initialized
INFO - 2017-02-03 22:49:22 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:22 --> Input Class Initialized
INFO - 2017-02-03 22:49:22 --> Language Class Initialized
ERROR - 2017-02-03 22:49:22 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:49:22 --> Config Class Initialized
INFO - 2017-02-03 22:49:22 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:22 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:22 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:22 --> URI Class Initialized
INFO - 2017-02-03 22:49:22 --> Router Class Initialized
INFO - 2017-02-03 22:49:22 --> Output Class Initialized
INFO - 2017-02-03 22:49:22 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:22 --> Input Class Initialized
INFO - 2017-02-03 22:49:22 --> Language Class Initialized
ERROR - 2017-02-03 22:49:22 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:49:34 --> Config Class Initialized
INFO - 2017-02-03 22:49:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:34 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:34 --> URI Class Initialized
DEBUG - 2017-02-03 22:49:34 --> No URI present. Default controller set.
INFO - 2017-02-03 22:49:34 --> Router Class Initialized
INFO - 2017-02-03 22:49:34 --> Output Class Initialized
INFO - 2017-02-03 22:49:34 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:34 --> Input Class Initialized
INFO - 2017-02-03 22:49:34 --> Language Class Initialized
INFO - 2017-02-03 22:49:34 --> Language Class Initialized
INFO - 2017-02-03 22:49:34 --> Config Class Initialized
INFO - 2017-02-03 22:49:34 --> Loader Class Initialized
INFO - 2017-02-03 22:49:34 --> Helper loaded: url_helper
INFO - 2017-02-03 22:49:34 --> Helper loaded: file_helper
INFO - 2017-02-03 22:49:34 --> Database Driver Class Initialized
INFO - 2017-02-03 22:49:34 --> Model Class Initialized
INFO - 2017-02-03 22:49:34 --> Model Class Initialized
INFO - 2017-02-03 22:49:34 --> Controller Class Initialized
DEBUG - 2017-02-03 22:49:34 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:34 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:49:34 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:49:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:49:34 --> Final output sent to browser
DEBUG - 2017-02-03 22:49:34 --> Total execution time: 0.0714
INFO - 2017-02-03 22:49:35 --> Config Class Initialized
INFO - 2017-02-03 22:49:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:35 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:35 --> URI Class Initialized
INFO - 2017-02-03 22:49:35 --> Router Class Initialized
INFO - 2017-02-03 22:49:35 --> Output Class Initialized
INFO - 2017-02-03 22:49:35 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:35 --> Input Class Initialized
INFO - 2017-02-03 22:49:35 --> Language Class Initialized
ERROR - 2017-02-03 22:49:35 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:49:38 --> Config Class Initialized
INFO - 2017-02-03 22:49:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:38 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:38 --> URI Class Initialized
DEBUG - 2017-02-03 22:49:38 --> No URI present. Default controller set.
INFO - 2017-02-03 22:49:38 --> Router Class Initialized
INFO - 2017-02-03 22:49:38 --> Output Class Initialized
INFO - 2017-02-03 22:49:38 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:38 --> Input Class Initialized
INFO - 2017-02-03 22:49:38 --> Language Class Initialized
INFO - 2017-02-03 22:49:38 --> Language Class Initialized
INFO - 2017-02-03 22:49:38 --> Config Class Initialized
INFO - 2017-02-03 22:49:38 --> Loader Class Initialized
INFO - 2017-02-03 22:49:38 --> Helper loaded: url_helper
INFO - 2017-02-03 22:49:38 --> Helper loaded: file_helper
INFO - 2017-02-03 22:49:38 --> Database Driver Class Initialized
INFO - 2017-02-03 22:49:38 --> Model Class Initialized
INFO - 2017-02-03 22:49:38 --> Model Class Initialized
INFO - 2017-02-03 22:49:38 --> Controller Class Initialized
DEBUG - 2017-02-03 22:49:38 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:49:38 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:49:38 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:49:38 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:49:38 --> Final output sent to browser
DEBUG - 2017-02-03 22:49:38 --> Total execution time: 0.0640
INFO - 2017-02-03 22:49:38 --> Config Class Initialized
INFO - 2017-02-03 22:49:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:49:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:49:38 --> Utf8 Class Initialized
INFO - 2017-02-03 22:49:38 --> URI Class Initialized
INFO - 2017-02-03 22:49:38 --> Router Class Initialized
INFO - 2017-02-03 22:49:38 --> Output Class Initialized
INFO - 2017-02-03 22:49:38 --> Security Class Initialized
DEBUG - 2017-02-03 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:49:38 --> Input Class Initialized
INFO - 2017-02-03 22:49:38 --> Language Class Initialized
ERROR - 2017-02-03 22:49:38 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:51:16 --> Config Class Initialized
INFO - 2017-02-03 22:51:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:51:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:51:16 --> Utf8 Class Initialized
INFO - 2017-02-03 22:51:16 --> URI Class Initialized
DEBUG - 2017-02-03 22:51:16 --> No URI present. Default controller set.
INFO - 2017-02-03 22:51:16 --> Router Class Initialized
INFO - 2017-02-03 22:51:16 --> Output Class Initialized
INFO - 2017-02-03 22:51:16 --> Security Class Initialized
DEBUG - 2017-02-03 22:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:51:16 --> Input Class Initialized
INFO - 2017-02-03 22:51:16 --> Language Class Initialized
INFO - 2017-02-03 22:51:16 --> Language Class Initialized
INFO - 2017-02-03 22:51:16 --> Config Class Initialized
INFO - 2017-02-03 22:51:16 --> Loader Class Initialized
INFO - 2017-02-03 22:51:16 --> Helper loaded: url_helper
INFO - 2017-02-03 22:51:16 --> Helper loaded: file_helper
INFO - 2017-02-03 22:51:16 --> Database Driver Class Initialized
INFO - 2017-02-03 22:51:16 --> Model Class Initialized
INFO - 2017-02-03 22:51:16 --> Model Class Initialized
INFO - 2017-02-03 22:51:16 --> Controller Class Initialized
DEBUG - 2017-02-03 22:51:16 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:51:16 --> Severity: Notice --> Undefined variable: _ci_file /var/www/html/wartabandung/application/third_party/MX/Loader.php 336
INFO - 2017-02-03 22:51:16 --> Config Class Initialized
INFO - 2017-02-03 22:51:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:51:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:51:16 --> Utf8 Class Initialized
INFO - 2017-02-03 22:51:16 --> URI Class Initialized
INFO - 2017-02-03 22:51:16 --> Router Class Initialized
INFO - 2017-02-03 22:51:16 --> Output Class Initialized
INFO - 2017-02-03 22:51:16 --> Security Class Initialized
DEBUG - 2017-02-03 22:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:51:16 --> Input Class Initialized
INFO - 2017-02-03 22:51:16 --> Language Class Initialized
ERROR - 2017-02-03 22:51:16 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:52:28 --> Config Class Initialized
INFO - 2017-02-03 22:52:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:52:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:52:28 --> Utf8 Class Initialized
INFO - 2017-02-03 22:52:28 --> URI Class Initialized
DEBUG - 2017-02-03 22:52:28 --> No URI present. Default controller set.
INFO - 2017-02-03 22:52:28 --> Router Class Initialized
INFO - 2017-02-03 22:52:28 --> Output Class Initialized
INFO - 2017-02-03 22:52:28 --> Security Class Initialized
DEBUG - 2017-02-03 22:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:52:28 --> Input Class Initialized
INFO - 2017-02-03 22:52:28 --> Language Class Initialized
INFO - 2017-02-03 22:52:28 --> Language Class Initialized
INFO - 2017-02-03 22:52:28 --> Config Class Initialized
INFO - 2017-02-03 22:52:28 --> Loader Class Initialized
INFO - 2017-02-03 22:52:28 --> Helper loaded: url_helper
INFO - 2017-02-03 22:52:28 --> Helper loaded: file_helper
INFO - 2017-02-03 22:52:28 --> Database Driver Class Initialized
INFO - 2017-02-03 22:52:28 --> Model Class Initialized
INFO - 2017-02-03 22:52:28 --> Model Class Initialized
INFO - 2017-02-03 22:52:28 --> Controller Class Initialized
DEBUG - 2017-02-03 22:52:28 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:52:29 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:52:29 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:52:29 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:52:29 --> Final output sent to browser
DEBUG - 2017-02-03 22:52:29 --> Total execution time: 0.0715
INFO - 2017-02-03 22:52:29 --> Config Class Initialized
INFO - 2017-02-03 22:52:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:52:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:52:29 --> Utf8 Class Initialized
INFO - 2017-02-03 22:52:29 --> URI Class Initialized
INFO - 2017-02-03 22:52:29 --> Router Class Initialized
INFO - 2017-02-03 22:52:29 --> Output Class Initialized
INFO - 2017-02-03 22:52:29 --> Security Class Initialized
DEBUG - 2017-02-03 22:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:52:29 --> Input Class Initialized
INFO - 2017-02-03 22:52:29 --> Language Class Initialized
ERROR - 2017-02-03 22:52:29 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:53:48 --> Config Class Initialized
INFO - 2017-02-03 22:53:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:53:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:53:48 --> Utf8 Class Initialized
INFO - 2017-02-03 22:53:48 --> URI Class Initialized
DEBUG - 2017-02-03 22:53:48 --> No URI present. Default controller set.
INFO - 2017-02-03 22:53:48 --> Router Class Initialized
INFO - 2017-02-03 22:53:48 --> Output Class Initialized
INFO - 2017-02-03 22:53:48 --> Security Class Initialized
DEBUG - 2017-02-03 22:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:53:48 --> Input Class Initialized
INFO - 2017-02-03 22:53:48 --> Language Class Initialized
INFO - 2017-02-03 22:53:48 --> Language Class Initialized
INFO - 2017-02-03 22:53:48 --> Config Class Initialized
INFO - 2017-02-03 22:53:48 --> Loader Class Initialized
INFO - 2017-02-03 22:53:48 --> Helper loaded: url_helper
INFO - 2017-02-03 22:53:48 --> Helper loaded: file_helper
INFO - 2017-02-03 22:53:48 --> Database Driver Class Initialized
INFO - 2017-02-03 22:53:48 --> Model Class Initialized
INFO - 2017-02-03 22:53:48 --> Model Class Initialized
INFO - 2017-02-03 22:53:48 --> Controller Class Initialized
DEBUG - 2017-02-03 22:53:48 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:53:48 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:53:48 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:53:48 --> Final output sent to browser
DEBUG - 2017-02-03 22:53:48 --> Total execution time: 0.0599
INFO - 2017-02-03 22:53:48 --> Config Class Initialized
INFO - 2017-02-03 22:53:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:53:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:53:48 --> Utf8 Class Initialized
INFO - 2017-02-03 22:53:48 --> URI Class Initialized
INFO - 2017-02-03 22:53:48 --> Router Class Initialized
INFO - 2017-02-03 22:53:48 --> Output Class Initialized
INFO - 2017-02-03 22:53:48 --> Security Class Initialized
DEBUG - 2017-02-03 22:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:53:48 --> Input Class Initialized
INFO - 2017-02-03 22:53:48 --> Language Class Initialized
ERROR - 2017-02-03 22:53:48 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:53:54 --> Config Class Initialized
INFO - 2017-02-03 22:53:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:53:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:53:54 --> Utf8 Class Initialized
INFO - 2017-02-03 22:53:54 --> URI Class Initialized
DEBUG - 2017-02-03 22:53:54 --> No URI present. Default controller set.
INFO - 2017-02-03 22:53:54 --> Router Class Initialized
INFO - 2017-02-03 22:53:54 --> Output Class Initialized
INFO - 2017-02-03 22:53:54 --> Security Class Initialized
DEBUG - 2017-02-03 22:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:53:54 --> Input Class Initialized
INFO - 2017-02-03 22:53:54 --> Language Class Initialized
INFO - 2017-02-03 22:53:54 --> Language Class Initialized
INFO - 2017-02-03 22:53:54 --> Config Class Initialized
INFO - 2017-02-03 22:53:54 --> Loader Class Initialized
INFO - 2017-02-03 22:53:54 --> Helper loaded: url_helper
INFO - 2017-02-03 22:53:54 --> Helper loaded: file_helper
INFO - 2017-02-03 22:53:54 --> Database Driver Class Initialized
INFO - 2017-02-03 22:53:54 --> Model Class Initialized
INFO - 2017-02-03 22:53:54 --> Model Class Initialized
INFO - 2017-02-03 22:53:54 --> Controller Class Initialized
DEBUG - 2017-02-03 22:53:54 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:53:54 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:53:54 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:53:54 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:53:54 --> Final output sent to browser
DEBUG - 2017-02-03 22:53:54 --> Total execution time: 0.0454
INFO - 2017-02-03 22:53:54 --> Config Class Initialized
INFO - 2017-02-03 22:53:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:53:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:53:54 --> Utf8 Class Initialized
INFO - 2017-02-03 22:53:54 --> URI Class Initialized
INFO - 2017-02-03 22:53:54 --> Router Class Initialized
INFO - 2017-02-03 22:53:54 --> Output Class Initialized
INFO - 2017-02-03 22:53:54 --> Security Class Initialized
DEBUG - 2017-02-03 22:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:53:54 --> Input Class Initialized
INFO - 2017-02-03 22:53:54 --> Language Class Initialized
ERROR - 2017-02-03 22:53:54 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:54:32 --> Config Class Initialized
INFO - 2017-02-03 22:54:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:54:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:54:32 --> Utf8 Class Initialized
INFO - 2017-02-03 22:54:32 --> URI Class Initialized
DEBUG - 2017-02-03 22:54:32 --> No URI present. Default controller set.
INFO - 2017-02-03 22:54:32 --> Router Class Initialized
INFO - 2017-02-03 22:54:32 --> Output Class Initialized
INFO - 2017-02-03 22:54:32 --> Security Class Initialized
DEBUG - 2017-02-03 22:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:54:32 --> Input Class Initialized
INFO - 2017-02-03 22:54:32 --> Language Class Initialized
INFO - 2017-02-03 22:54:32 --> Language Class Initialized
INFO - 2017-02-03 22:54:32 --> Config Class Initialized
INFO - 2017-02-03 22:54:32 --> Loader Class Initialized
INFO - 2017-02-03 22:54:32 --> Helper loaded: url_helper
INFO - 2017-02-03 22:54:32 --> Helper loaded: file_helper
INFO - 2017-02-03 22:54:32 --> Database Driver Class Initialized
INFO - 2017-02-03 22:54:32 --> Model Class Initialized
INFO - 2017-02-03 22:54:32 --> Model Class Initialized
INFO - 2017-02-03 22:54:32 --> Controller Class Initialized
DEBUG - 2017-02-03 22:54:32 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:32 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:54:32 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:54:32 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:54:32 --> Final output sent to browser
DEBUG - 2017-02-03 22:54:32 --> Total execution time: 0.0712
INFO - 2017-02-03 22:54:32 --> Config Class Initialized
INFO - 2017-02-03 22:54:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:54:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:54:32 --> Utf8 Class Initialized
INFO - 2017-02-03 22:54:32 --> URI Class Initialized
INFO - 2017-02-03 22:54:32 --> Router Class Initialized
INFO - 2017-02-03 22:54:32 --> Output Class Initialized
INFO - 2017-02-03 22:54:32 --> Security Class Initialized
DEBUG - 2017-02-03 22:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:54:32 --> Input Class Initialized
INFO - 2017-02-03 22:54:32 --> Language Class Initialized
ERROR - 2017-02-03 22:54:32 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:54:37 --> Config Class Initialized
INFO - 2017-02-03 22:54:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:54:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:54:37 --> Utf8 Class Initialized
INFO - 2017-02-03 22:54:37 --> URI Class Initialized
DEBUG - 2017-02-03 22:54:37 --> No URI present. Default controller set.
INFO - 2017-02-03 22:54:37 --> Router Class Initialized
INFO - 2017-02-03 22:54:37 --> Output Class Initialized
INFO - 2017-02-03 22:54:37 --> Security Class Initialized
DEBUG - 2017-02-03 22:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:54:37 --> Input Class Initialized
INFO - 2017-02-03 22:54:37 --> Language Class Initialized
INFO - 2017-02-03 22:54:37 --> Language Class Initialized
INFO - 2017-02-03 22:54:37 --> Config Class Initialized
INFO - 2017-02-03 22:54:37 --> Loader Class Initialized
INFO - 2017-02-03 22:54:37 --> Helper loaded: url_helper
INFO - 2017-02-03 22:54:37 --> Helper loaded: file_helper
INFO - 2017-02-03 22:54:37 --> Database Driver Class Initialized
INFO - 2017-02-03 22:54:37 --> Model Class Initialized
INFO - 2017-02-03 22:54:37 --> Model Class Initialized
INFO - 2017-02-03 22:54:37 --> Controller Class Initialized
DEBUG - 2017-02-03 22:54:37 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:54:37 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:54:37 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:54:37 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:54:37 --> Final output sent to browser
DEBUG - 2017-02-03 22:54:37 --> Total execution time: 0.0716
INFO - 2017-02-03 22:54:37 --> Config Class Initialized
INFO - 2017-02-03 22:54:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:54:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:54:37 --> Utf8 Class Initialized
INFO - 2017-02-03 22:54:37 --> URI Class Initialized
INFO - 2017-02-03 22:54:37 --> Router Class Initialized
INFO - 2017-02-03 22:54:37 --> Output Class Initialized
INFO - 2017-02-03 22:54:37 --> Security Class Initialized
DEBUG - 2017-02-03 22:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:54:37 --> Input Class Initialized
INFO - 2017-02-03 22:54:37 --> Language Class Initialized
ERROR - 2017-02-03 22:54:37 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:56:33 --> Config Class Initialized
INFO - 2017-02-03 22:56:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:56:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:56:33 --> Utf8 Class Initialized
INFO - 2017-02-03 22:56:33 --> URI Class Initialized
DEBUG - 2017-02-03 22:56:33 --> No URI present. Default controller set.
INFO - 2017-02-03 22:56:33 --> Router Class Initialized
INFO - 2017-02-03 22:56:33 --> Output Class Initialized
INFO - 2017-02-03 22:56:33 --> Security Class Initialized
DEBUG - 2017-02-03 22:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:56:33 --> Input Class Initialized
INFO - 2017-02-03 22:56:33 --> Language Class Initialized
INFO - 2017-02-03 22:56:33 --> Language Class Initialized
INFO - 2017-02-03 22:56:33 --> Config Class Initialized
INFO - 2017-02-03 22:56:33 --> Loader Class Initialized
INFO - 2017-02-03 22:56:33 --> Helper loaded: url_helper
INFO - 2017-02-03 22:56:33 --> Helper loaded: file_helper
INFO - 2017-02-03 22:56:33 --> Database Driver Class Initialized
INFO - 2017-02-03 22:56:33 --> Model Class Initialized
INFO - 2017-02-03 22:56:33 --> Model Class Initialized
INFO - 2017-02-03 22:56:33 --> Controller Class Initialized
DEBUG - 2017-02-03 22:56:33 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:56:33 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:56:33 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:56:33 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:56:33 --> Final output sent to browser
DEBUG - 2017-02-03 22:56:33 --> Total execution time: 0.0453
INFO - 2017-02-03 22:56:33 --> Config Class Initialized
INFO - 2017-02-03 22:56:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:56:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:56:33 --> Utf8 Class Initialized
INFO - 2017-02-03 22:56:33 --> URI Class Initialized
INFO - 2017-02-03 22:56:33 --> Router Class Initialized
INFO - 2017-02-03 22:56:33 --> Output Class Initialized
INFO - 2017-02-03 22:56:33 --> Security Class Initialized
DEBUG - 2017-02-03 22:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:56:33 --> Input Class Initialized
INFO - 2017-02-03 22:56:33 --> Language Class Initialized
ERROR - 2017-02-03 22:56:33 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:59:08 --> Config Class Initialized
INFO - 2017-02-03 22:59:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:08 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:08 --> URI Class Initialized
DEBUG - 2017-02-03 22:59:08 --> No URI present. Default controller set.
INFO - 2017-02-03 22:59:08 --> Router Class Initialized
INFO - 2017-02-03 22:59:08 --> Output Class Initialized
INFO - 2017-02-03 22:59:08 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:08 --> Input Class Initialized
INFO - 2017-02-03 22:59:08 --> Language Class Initialized
INFO - 2017-02-03 22:59:08 --> Language Class Initialized
INFO - 2017-02-03 22:59:08 --> Config Class Initialized
INFO - 2017-02-03 22:59:08 --> Loader Class Initialized
INFO - 2017-02-03 22:59:08 --> Helper loaded: url_helper
INFO - 2017-02-03 22:59:08 --> Helper loaded: file_helper
INFO - 2017-02-03 22:59:08 --> Database Driver Class Initialized
INFO - 2017-02-03 22:59:08 --> Model Class Initialized
INFO - 2017-02-03 22:59:08 --> Model Class Initialized
INFO - 2017-02-03 22:59:08 --> Controller Class Initialized
DEBUG - 2017-02-03 22:59:08 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 22:59:08 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 22:59:08 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 22:59:08 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 22:59:08 --> Final output sent to browser
DEBUG - 2017-02-03 22:59:08 --> Total execution time: 0.0761
INFO - 2017-02-03 22:59:08 --> Config Class Initialized
INFO - 2017-02-03 22:59:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:08 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:08 --> URI Class Initialized
INFO - 2017-02-03 22:59:08 --> Router Class Initialized
INFO - 2017-02-03 22:59:08 --> Output Class Initialized
INFO - 2017-02-03 22:59:08 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:08 --> Input Class Initialized
INFO - 2017-02-03 22:59:08 --> Language Class Initialized
ERROR - 2017-02-03 22:59:08 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:59:13 --> Config Class Initialized
INFO - 2017-02-03 22:59:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:13 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:13 --> URI Class Initialized
INFO - 2017-02-03 22:59:13 --> Router Class Initialized
INFO - 2017-02-03 22:59:13 --> Output Class Initialized
INFO - 2017-02-03 22:59:13 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:13 --> Input Class Initialized
INFO - 2017-02-03 22:59:13 --> Language Class Initialized
ERROR - 2017-02-03 22:59:13 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:59:52 --> Config Class Initialized
INFO - 2017-02-03 22:59:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:52 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:52 --> URI Class Initialized
INFO - 2017-02-03 22:59:52 --> Router Class Initialized
INFO - 2017-02-03 22:59:52 --> Output Class Initialized
INFO - 2017-02-03 22:59:52 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:52 --> Input Class Initialized
INFO - 2017-02-03 22:59:52 --> Language Class Initialized
ERROR - 2017-02-03 22:59:52 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:59:53 --> Config Class Initialized
INFO - 2017-02-03 22:59:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:53 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:53 --> URI Class Initialized
INFO - 2017-02-03 22:59:53 --> Router Class Initialized
INFO - 2017-02-03 22:59:53 --> Output Class Initialized
INFO - 2017-02-03 22:59:53 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:53 --> Input Class Initialized
INFO - 2017-02-03 22:59:53 --> Language Class Initialized
ERROR - 2017-02-03 22:59:53 --> 404 Page Not Found: /index
INFO - 2017-02-03 22:59:54 --> Config Class Initialized
INFO - 2017-02-03 22:59:54 --> Hooks Class Initialized
DEBUG - 2017-02-03 22:59:54 --> UTF-8 Support Enabled
INFO - 2017-02-03 22:59:54 --> Utf8 Class Initialized
INFO - 2017-02-03 22:59:54 --> URI Class Initialized
INFO - 2017-02-03 22:59:54 --> Router Class Initialized
INFO - 2017-02-03 22:59:54 --> Output Class Initialized
INFO - 2017-02-03 22:59:54 --> Security Class Initialized
DEBUG - 2017-02-03 22:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 22:59:54 --> Input Class Initialized
INFO - 2017-02-03 22:59:54 --> Language Class Initialized
ERROR - 2017-02-03 22:59:54 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:08 --> Config Class Initialized
INFO - 2017-02-03 23:00:08 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:08 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:08 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:08 --> URI Class Initialized
INFO - 2017-02-03 23:00:08 --> Router Class Initialized
INFO - 2017-02-03 23:00:08 --> Output Class Initialized
INFO - 2017-02-03 23:00:08 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:08 --> Input Class Initialized
INFO - 2017-02-03 23:00:08 --> Language Class Initialized
ERROR - 2017-02-03 23:00:08 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:09 --> Config Class Initialized
INFO - 2017-02-03 23:00:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:09 --> URI Class Initialized
INFO - 2017-02-03 23:00:09 --> Router Class Initialized
INFO - 2017-02-03 23:00:09 --> Output Class Initialized
INFO - 2017-02-03 23:00:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:09 --> Input Class Initialized
INFO - 2017-02-03 23:00:09 --> Language Class Initialized
ERROR - 2017-02-03 23:00:09 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:09 --> Config Class Initialized
INFO - 2017-02-03 23:00:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:09 --> URI Class Initialized
INFO - 2017-02-03 23:00:09 --> Router Class Initialized
INFO - 2017-02-03 23:00:09 --> Output Class Initialized
INFO - 2017-02-03 23:00:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:09 --> Input Class Initialized
INFO - 2017-02-03 23:00:09 --> Language Class Initialized
ERROR - 2017-02-03 23:00:09 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:09 --> Config Class Initialized
INFO - 2017-02-03 23:00:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:09 --> URI Class Initialized
INFO - 2017-02-03 23:00:09 --> Router Class Initialized
INFO - 2017-02-03 23:00:09 --> Output Class Initialized
INFO - 2017-02-03 23:00:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:09 --> Input Class Initialized
INFO - 2017-02-03 23:00:09 --> Language Class Initialized
ERROR - 2017-02-03 23:00:09 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:09 --> Config Class Initialized
INFO - 2017-02-03 23:00:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:09 --> URI Class Initialized
INFO - 2017-02-03 23:00:09 --> Router Class Initialized
INFO - 2017-02-03 23:00:09 --> Output Class Initialized
INFO - 2017-02-03 23:00:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:09 --> Input Class Initialized
INFO - 2017-02-03 23:00:09 --> Language Class Initialized
ERROR - 2017-02-03 23:00:09 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:10 --> Config Class Initialized
INFO - 2017-02-03 23:00:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:10 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:10 --> URI Class Initialized
INFO - 2017-02-03 23:00:10 --> Router Class Initialized
INFO - 2017-02-03 23:00:10 --> Output Class Initialized
INFO - 2017-02-03 23:00:10 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:10 --> Input Class Initialized
INFO - 2017-02-03 23:00:10 --> Language Class Initialized
ERROR - 2017-02-03 23:00:10 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:10 --> Config Class Initialized
INFO - 2017-02-03 23:00:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:10 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:10 --> URI Class Initialized
INFO - 2017-02-03 23:00:10 --> Router Class Initialized
INFO - 2017-02-03 23:00:10 --> Output Class Initialized
INFO - 2017-02-03 23:00:10 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:10 --> Input Class Initialized
INFO - 2017-02-03 23:00:10 --> Language Class Initialized
ERROR - 2017-02-03 23:00:10 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:17 --> Config Class Initialized
INFO - 2017-02-03 23:00:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:17 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:17 --> URI Class Initialized
INFO - 2017-02-03 23:00:17 --> Router Class Initialized
INFO - 2017-02-03 23:00:17 --> Output Class Initialized
INFO - 2017-02-03 23:00:17 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:17 --> Input Class Initialized
INFO - 2017-02-03 23:00:17 --> Language Class Initialized
ERROR - 2017-02-03 23:00:17 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:00:32 --> Config Class Initialized
INFO - 2017-02-03 23:00:32 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:32 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:32 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:32 --> URI Class Initialized
INFO - 2017-02-03 23:00:32 --> Router Class Initialized
INFO - 2017-02-03 23:00:32 --> Output Class Initialized
INFO - 2017-02-03 23:00:32 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:32 --> Input Class Initialized
INFO - 2017-02-03 23:00:32 --> Language Class Initialized
INFO - 2017-02-03 23:00:32 --> Language Class Initialized
INFO - 2017-02-03 23:00:32 --> Config Class Initialized
INFO - 2017-02-03 23:00:32 --> Loader Class Initialized
INFO - 2017-02-03 23:00:32 --> Helper loaded: url_helper
INFO - 2017-02-03 23:00:32 --> Helper loaded: file_helper
INFO - 2017-02-03 23:00:32 --> Database Driver Class Initialized
INFO - 2017-02-03 23:00:32 --> Model Class Initialized
INFO - 2017-02-03 23:00:32 --> Model Class Initialized
INFO - 2017-02-03 23:00:32 --> Controller Class Initialized
ERROR - 2017-02-03 23:00:32 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:00:40 --> Config Class Initialized
INFO - 2017-02-03 23:00:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:00:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:00:40 --> Utf8 Class Initialized
INFO - 2017-02-03 23:00:40 --> URI Class Initialized
INFO - 2017-02-03 23:00:40 --> Router Class Initialized
INFO - 2017-02-03 23:00:40 --> Output Class Initialized
INFO - 2017-02-03 23:00:40 --> Security Class Initialized
DEBUG - 2017-02-03 23:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:00:40 --> Input Class Initialized
INFO - 2017-02-03 23:00:40 --> Language Class Initialized
INFO - 2017-02-03 23:00:40 --> Language Class Initialized
INFO - 2017-02-03 23:00:40 --> Config Class Initialized
INFO - 2017-02-03 23:00:40 --> Loader Class Initialized
INFO - 2017-02-03 23:00:40 --> Helper loaded: url_helper
INFO - 2017-02-03 23:00:40 --> Helper loaded: file_helper
INFO - 2017-02-03 23:00:40 --> Database Driver Class Initialized
INFO - 2017-02-03 23:00:40 --> Model Class Initialized
INFO - 2017-02-03 23:00:40 --> Model Class Initialized
INFO - 2017-02-03 23:00:40 --> Controller Class Initialized
ERROR - 2017-02-03 23:00:40 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:01:23 --> Config Class Initialized
INFO - 2017-02-03 23:01:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:01:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:01:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:01:23 --> URI Class Initialized
DEBUG - 2017-02-03 23:01:23 --> No URI present. Default controller set.
INFO - 2017-02-03 23:01:23 --> Router Class Initialized
INFO - 2017-02-03 23:01:23 --> Output Class Initialized
INFO - 2017-02-03 23:01:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:01:23 --> Input Class Initialized
INFO - 2017-02-03 23:01:23 --> Language Class Initialized
INFO - 2017-02-03 23:01:23 --> Language Class Initialized
INFO - 2017-02-03 23:01:23 --> Config Class Initialized
INFO - 2017-02-03 23:01:23 --> Loader Class Initialized
INFO - 2017-02-03 23:01:23 --> Helper loaded: url_helper
INFO - 2017-02-03 23:01:23 --> Helper loaded: file_helper
INFO - 2017-02-03 23:01:23 --> Database Driver Class Initialized
INFO - 2017-02-03 23:01:23 --> Model Class Initialized
INFO - 2017-02-03 23:01:23 --> Model Class Initialized
INFO - 2017-02-03 23:01:23 --> Controller Class Initialized
DEBUG - 2017-02-03 23:01:23 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:01:23 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 23:01:23 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 23:01:23 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:01:23 --> Final output sent to browser
DEBUG - 2017-02-03 23:01:23 --> Total execution time: 0.0589
INFO - 2017-02-03 23:01:23 --> Config Class Initialized
INFO - 2017-02-03 23:01:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:01:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:01:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:01:23 --> URI Class Initialized
INFO - 2017-02-03 23:01:23 --> Router Class Initialized
INFO - 2017-02-03 23:01:23 --> Output Class Initialized
INFO - 2017-02-03 23:01:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:01:23 --> Input Class Initialized
INFO - 2017-02-03 23:01:23 --> Language Class Initialized
ERROR - 2017-02-03 23:01:23 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:01:27 --> Config Class Initialized
INFO - 2017-02-03 23:01:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:01:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:01:27 --> Utf8 Class Initialized
INFO - 2017-02-03 23:01:27 --> URI Class Initialized
INFO - 2017-02-03 23:01:27 --> Router Class Initialized
INFO - 2017-02-03 23:01:27 --> Output Class Initialized
INFO - 2017-02-03 23:01:27 --> Security Class Initialized
DEBUG - 2017-02-03 23:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:01:27 --> Input Class Initialized
INFO - 2017-02-03 23:01:27 --> Language Class Initialized
INFO - 2017-02-03 23:01:27 --> Language Class Initialized
INFO - 2017-02-03 23:01:27 --> Config Class Initialized
INFO - 2017-02-03 23:01:27 --> Loader Class Initialized
INFO - 2017-02-03 23:01:27 --> Helper loaded: url_helper
INFO - 2017-02-03 23:01:27 --> Helper loaded: file_helper
INFO - 2017-02-03 23:01:27 --> Database Driver Class Initialized
INFO - 2017-02-03 23:01:27 --> Model Class Initialized
INFO - 2017-02-03 23:01:27 --> Model Class Initialized
INFO - 2017-02-03 23:01:27 --> Controller Class Initialized
ERROR - 2017-02-03 23:01:27 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:01:35 --> Config Class Initialized
INFO - 2017-02-03 23:01:35 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:01:35 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:01:35 --> Utf8 Class Initialized
INFO - 2017-02-03 23:01:35 --> URI Class Initialized
INFO - 2017-02-03 23:01:35 --> Router Class Initialized
INFO - 2017-02-03 23:01:35 --> Output Class Initialized
INFO - 2017-02-03 23:01:35 --> Security Class Initialized
DEBUG - 2017-02-03 23:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:01:35 --> Input Class Initialized
INFO - 2017-02-03 23:01:35 --> Language Class Initialized
INFO - 2017-02-03 23:01:35 --> Language Class Initialized
INFO - 2017-02-03 23:01:35 --> Config Class Initialized
INFO - 2017-02-03 23:01:35 --> Loader Class Initialized
INFO - 2017-02-03 23:01:35 --> Helper loaded: url_helper
INFO - 2017-02-03 23:01:35 --> Helper loaded: file_helper
INFO - 2017-02-03 23:01:35 --> Database Driver Class Initialized
INFO - 2017-02-03 23:01:35 --> Model Class Initialized
INFO - 2017-02-03 23:01:35 --> Model Class Initialized
INFO - 2017-02-03 23:01:35 --> Controller Class Initialized
ERROR - 2017-02-03 23:01:35 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:04:27 --> Config Class Initialized
INFO - 2017-02-03 23:04:27 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:04:27 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:04:27 --> Utf8 Class Initialized
INFO - 2017-02-03 23:04:27 --> URI Class Initialized
INFO - 2017-02-03 23:04:27 --> Router Class Initialized
INFO - 2017-02-03 23:04:27 --> Output Class Initialized
INFO - 2017-02-03 23:04:27 --> Security Class Initialized
DEBUG - 2017-02-03 23:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:04:27 --> Input Class Initialized
INFO - 2017-02-03 23:04:27 --> Language Class Initialized
INFO - 2017-02-03 23:04:27 --> Language Class Initialized
INFO - 2017-02-03 23:04:27 --> Config Class Initialized
INFO - 2017-02-03 23:04:27 --> Loader Class Initialized
INFO - 2017-02-03 23:04:27 --> Helper loaded: url_helper
INFO - 2017-02-03 23:04:27 --> Helper loaded: file_helper
INFO - 2017-02-03 23:04:27 --> Database Driver Class Initialized
INFO - 2017-02-03 23:04:27 --> Model Class Initialized
INFO - 2017-02-03 23:04:27 --> Model Class Initialized
INFO - 2017-02-03 23:04:27 --> Controller Class Initialized
ERROR - 2017-02-03 23:04:27 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/kuliner
INFO - 2017-02-03 23:04:50 --> Config Class Initialized
INFO - 2017-02-03 23:04:50 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:04:50 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:04:50 --> Utf8 Class Initialized
INFO - 2017-02-03 23:04:50 --> URI Class Initialized
DEBUG - 2017-02-03 23:04:50 --> No URI present. Default controller set.
INFO - 2017-02-03 23:04:50 --> Router Class Initialized
INFO - 2017-02-03 23:04:50 --> Output Class Initialized
INFO - 2017-02-03 23:04:50 --> Security Class Initialized
DEBUG - 2017-02-03 23:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:04:50 --> Input Class Initialized
INFO - 2017-02-03 23:04:50 --> Language Class Initialized
INFO - 2017-02-03 23:04:50 --> Language Class Initialized
INFO - 2017-02-03 23:04:50 --> Config Class Initialized
INFO - 2017-02-03 23:04:50 --> Loader Class Initialized
INFO - 2017-02-03 23:04:50 --> Helper loaded: url_helper
INFO - 2017-02-03 23:04:50 --> Helper loaded: file_helper
INFO - 2017-02-03 23:04:50 --> Database Driver Class Initialized
INFO - 2017-02-03 23:04:50 --> Model Class Initialized
INFO - 2017-02-03 23:04:50 --> Model Class Initialized
INFO - 2017-02-03 23:04:50 --> Controller Class Initialized
DEBUG - 2017-02-03 23:04:50 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:04:50 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 23:04:50 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 23:04:50 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:04:50 --> Final output sent to browser
DEBUG - 2017-02-03 23:04:50 --> Total execution time: 0.0799
INFO - 2017-02-03 23:04:51 --> Config Class Initialized
INFO - 2017-02-03 23:04:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:04:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:04:51 --> Utf8 Class Initialized
INFO - 2017-02-03 23:04:51 --> URI Class Initialized
INFO - 2017-02-03 23:04:51 --> Router Class Initialized
INFO - 2017-02-03 23:04:51 --> Output Class Initialized
INFO - 2017-02-03 23:04:51 --> Security Class Initialized
DEBUG - 2017-02-03 23:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:04:51 --> Input Class Initialized
INFO - 2017-02-03 23:04:51 --> Language Class Initialized
ERROR - 2017-02-03 23:04:51 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:04:53 --> Config Class Initialized
INFO - 2017-02-03 23:04:53 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:04:53 --> Utf8 Class Initialized
INFO - 2017-02-03 23:04:53 --> URI Class Initialized
INFO - 2017-02-03 23:04:53 --> Router Class Initialized
INFO - 2017-02-03 23:04:53 --> Output Class Initialized
INFO - 2017-02-03 23:04:53 --> Security Class Initialized
DEBUG - 2017-02-03 23:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:04:53 --> Input Class Initialized
INFO - 2017-02-03 23:04:53 --> Language Class Initialized
INFO - 2017-02-03 23:04:53 --> Language Class Initialized
INFO - 2017-02-03 23:04:53 --> Config Class Initialized
INFO - 2017-02-03 23:04:53 --> Loader Class Initialized
INFO - 2017-02-03 23:04:53 --> Helper loaded: url_helper
INFO - 2017-02-03 23:04:53 --> Helper loaded: file_helper
INFO - 2017-02-03 23:04:53 --> Database Driver Class Initialized
INFO - 2017-02-03 23:04:53 --> Model Class Initialized
INFO - 2017-02-03 23:04:53 --> Model Class Initialized
INFO - 2017-02-03 23:04:53 --> Controller Class Initialized
ERROR - 2017-02-03 23:04:53 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:04:58 --> Config Class Initialized
INFO - 2017-02-03 23:04:58 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:04:58 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:04:58 --> Utf8 Class Initialized
INFO - 2017-02-03 23:04:58 --> URI Class Initialized
INFO - 2017-02-03 23:04:58 --> Router Class Initialized
INFO - 2017-02-03 23:04:58 --> Output Class Initialized
INFO - 2017-02-03 23:04:58 --> Security Class Initialized
DEBUG - 2017-02-03 23:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:04:58 --> Input Class Initialized
INFO - 2017-02-03 23:04:58 --> Language Class Initialized
INFO - 2017-02-03 23:04:58 --> Language Class Initialized
INFO - 2017-02-03 23:04:58 --> Config Class Initialized
INFO - 2017-02-03 23:04:58 --> Loader Class Initialized
INFO - 2017-02-03 23:04:58 --> Helper loaded: url_helper
INFO - 2017-02-03 23:04:58 --> Helper loaded: file_helper
INFO - 2017-02-03 23:04:58 --> Database Driver Class Initialized
INFO - 2017-02-03 23:04:58 --> Model Class Initialized
INFO - 2017-02-03 23:04:58 --> Model Class Initialized
INFO - 2017-02-03 23:04:58 --> Controller Class Initialized
ERROR - 2017-02-03 23:04:58 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:05:02 --> Config Class Initialized
INFO - 2017-02-03 23:05:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:05:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:05:02 --> Utf8 Class Initialized
INFO - 2017-02-03 23:05:02 --> URI Class Initialized
INFO - 2017-02-03 23:05:02 --> Router Class Initialized
INFO - 2017-02-03 23:05:02 --> Output Class Initialized
INFO - 2017-02-03 23:05:02 --> Security Class Initialized
DEBUG - 2017-02-03 23:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:05:02 --> Input Class Initialized
INFO - 2017-02-03 23:05:02 --> Language Class Initialized
INFO - 2017-02-03 23:05:02 --> Language Class Initialized
INFO - 2017-02-03 23:05:02 --> Config Class Initialized
INFO - 2017-02-03 23:05:02 --> Loader Class Initialized
INFO - 2017-02-03 23:05:02 --> Helper loaded: url_helper
INFO - 2017-02-03 23:05:02 --> Helper loaded: file_helper
INFO - 2017-02-03 23:05:02 --> Database Driver Class Initialized
INFO - 2017-02-03 23:05:02 --> Model Class Initialized
INFO - 2017-02-03 23:05:02 --> Model Class Initialized
INFO - 2017-02-03 23:05:02 --> Controller Class Initialized
DEBUG - 2017-02-03 23:05:02 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:05:02 --> Config Class Initialized
INFO - 2017-02-03 23:05:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:05:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:05:02 --> Utf8 Class Initialized
INFO - 2017-02-03 23:05:02 --> URI Class Initialized
INFO - 2017-02-03 23:05:02 --> Router Class Initialized
INFO - 2017-02-03 23:05:02 --> Output Class Initialized
INFO - 2017-02-03 23:05:02 --> Security Class Initialized
DEBUG - 2017-02-03 23:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:05:02 --> Input Class Initialized
INFO - 2017-02-03 23:05:02 --> Language Class Initialized
ERROR - 2017-02-03 23:05:02 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:06:15 --> Config Class Initialized
INFO - 2017-02-03 23:06:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:06:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:06:15 --> Utf8 Class Initialized
INFO - 2017-02-03 23:06:15 --> URI Class Initialized
INFO - 2017-02-03 23:06:15 --> Router Class Initialized
INFO - 2017-02-03 23:06:15 --> Output Class Initialized
INFO - 2017-02-03 23:06:15 --> Security Class Initialized
DEBUG - 2017-02-03 23:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:06:15 --> Input Class Initialized
INFO - 2017-02-03 23:06:15 --> Language Class Initialized
INFO - 2017-02-03 23:06:15 --> Language Class Initialized
INFO - 2017-02-03 23:06:15 --> Config Class Initialized
INFO - 2017-02-03 23:06:15 --> Loader Class Initialized
INFO - 2017-02-03 23:06:15 --> Helper loaded: url_helper
INFO - 2017-02-03 23:06:15 --> Helper loaded: file_helper
INFO - 2017-02-03 23:06:15 --> Database Driver Class Initialized
INFO - 2017-02-03 23:06:15 --> Model Class Initialized
INFO - 2017-02-03 23:06:15 --> Model Class Initialized
INFO - 2017-02-03 23:06:15 --> Controller Class Initialized
DEBUG - 2017-02-03 23:06:15 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:06:15 --> Config Class Initialized
INFO - 2017-02-03 23:06:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:06:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:06:15 --> Utf8 Class Initialized
INFO - 2017-02-03 23:06:15 --> URI Class Initialized
INFO - 2017-02-03 23:06:15 --> Router Class Initialized
INFO - 2017-02-03 23:06:15 --> Output Class Initialized
INFO - 2017-02-03 23:06:15 --> Security Class Initialized
DEBUG - 2017-02-03 23:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:06:15 --> Input Class Initialized
INFO - 2017-02-03 23:06:15 --> Language Class Initialized
ERROR - 2017-02-03 23:06:15 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:06:16 --> Config Class Initialized
INFO - 2017-02-03 23:06:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:06:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:06:16 --> Utf8 Class Initialized
INFO - 2017-02-03 23:06:16 --> URI Class Initialized
INFO - 2017-02-03 23:06:16 --> Router Class Initialized
INFO - 2017-02-03 23:06:16 --> Output Class Initialized
INFO - 2017-02-03 23:06:16 --> Security Class Initialized
DEBUG - 2017-02-03 23:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:06:16 --> Input Class Initialized
INFO - 2017-02-03 23:06:16 --> Language Class Initialized
INFO - 2017-02-03 23:06:16 --> Language Class Initialized
INFO - 2017-02-03 23:06:16 --> Config Class Initialized
INFO - 2017-02-03 23:06:16 --> Loader Class Initialized
INFO - 2017-02-03 23:06:16 --> Helper loaded: url_helper
INFO - 2017-02-03 23:06:16 --> Helper loaded: file_helper
INFO - 2017-02-03 23:06:16 --> Database Driver Class Initialized
INFO - 2017-02-03 23:06:16 --> Model Class Initialized
INFO - 2017-02-03 23:06:16 --> Model Class Initialized
INFO - 2017-02-03 23:06:16 --> Controller Class Initialized
DEBUG - 2017-02-03 23:06:16 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:06:17 --> Config Class Initialized
INFO - 2017-02-03 23:06:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:06:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:06:17 --> Utf8 Class Initialized
INFO - 2017-02-03 23:06:17 --> URI Class Initialized
INFO - 2017-02-03 23:06:17 --> Router Class Initialized
INFO - 2017-02-03 23:06:17 --> Output Class Initialized
INFO - 2017-02-03 23:06:17 --> Security Class Initialized
DEBUG - 2017-02-03 23:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:06:17 --> Input Class Initialized
INFO - 2017-02-03 23:06:17 --> Language Class Initialized
ERROR - 2017-02-03 23:06:17 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:06:42 --> Config Class Initialized
INFO - 2017-02-03 23:06:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:06:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:06:42 --> Utf8 Class Initialized
INFO - 2017-02-03 23:06:42 --> URI Class Initialized
INFO - 2017-02-03 23:06:42 --> Router Class Initialized
INFO - 2017-02-03 23:06:42 --> Output Class Initialized
INFO - 2017-02-03 23:06:42 --> Security Class Initialized
DEBUG - 2017-02-03 23:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:06:42 --> Input Class Initialized
INFO - 2017-02-03 23:06:42 --> Language Class Initialized
INFO - 2017-02-03 23:06:42 --> Language Class Initialized
INFO - 2017-02-03 23:06:42 --> Config Class Initialized
INFO - 2017-02-03 23:06:42 --> Loader Class Initialized
INFO - 2017-02-03 23:06:42 --> Helper loaded: url_helper
INFO - 2017-02-03 23:06:42 --> Helper loaded: file_helper
INFO - 2017-02-03 23:06:42 --> Database Driver Class Initialized
INFO - 2017-02-03 23:06:42 --> Model Class Initialized
INFO - 2017-02-03 23:06:42 --> Model Class Initialized
INFO - 2017-02-03 23:06:42 --> Controller Class Initialized
DEBUG - 2017-02-03 23:06:42 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:06:42 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:06:42 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:06:42 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:06:42 --> Config Class Initialized
INFO - 2017-02-03 23:06:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:06:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:06:42 --> Utf8 Class Initialized
INFO - 2017-02-03 23:06:42 --> URI Class Initialized
INFO - 2017-02-03 23:06:42 --> Router Class Initialized
INFO - 2017-02-03 23:06:42 --> Output Class Initialized
INFO - 2017-02-03 23:06:42 --> Security Class Initialized
DEBUG - 2017-02-03 23:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:06:42 --> Input Class Initialized
INFO - 2017-02-03 23:06:42 --> Language Class Initialized
ERROR - 2017-02-03 23:06:42 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:07:59 --> Config Class Initialized
INFO - 2017-02-03 23:07:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:07:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:07:59 --> Utf8 Class Initialized
INFO - 2017-02-03 23:07:59 --> URI Class Initialized
INFO - 2017-02-03 23:07:59 --> Router Class Initialized
INFO - 2017-02-03 23:07:59 --> Output Class Initialized
INFO - 2017-02-03 23:07:59 --> Security Class Initialized
DEBUG - 2017-02-03 23:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:07:59 --> Input Class Initialized
INFO - 2017-02-03 23:07:59 --> Language Class Initialized
INFO - 2017-02-03 23:07:59 --> Language Class Initialized
INFO - 2017-02-03 23:07:59 --> Config Class Initialized
INFO - 2017-02-03 23:07:59 --> Loader Class Initialized
INFO - 2017-02-03 23:07:59 --> Helper loaded: url_helper
INFO - 2017-02-03 23:07:59 --> Helper loaded: file_helper
INFO - 2017-02-03 23:07:59 --> Database Driver Class Initialized
INFO - 2017-02-03 23:07:59 --> Model Class Initialized
INFO - 2017-02-03 23:07:59 --> Model Class Initialized
INFO - 2017-02-03 23:07:59 --> Controller Class Initialized
DEBUG - 2017-02-03 23:07:59 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:07:59 --> Severity: Notice --> Undefined index: page /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php 3
ERROR - 2017-02-03 23:07:59 --> Severity: Error --> Class 'PageNumber' not found /var/www/html/wartabandung/application/models/Main_model.php 610
INFO - 2017-02-03 23:07:59 --> Config Class Initialized
INFO - 2017-02-03 23:07:59 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:07:59 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:07:59 --> Utf8 Class Initialized
INFO - 2017-02-03 23:07:59 --> URI Class Initialized
INFO - 2017-02-03 23:07:59 --> Router Class Initialized
INFO - 2017-02-03 23:07:59 --> Output Class Initialized
INFO - 2017-02-03 23:07:59 --> Security Class Initialized
DEBUG - 2017-02-03 23:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:07:59 --> Input Class Initialized
INFO - 2017-02-03 23:07:59 --> Language Class Initialized
ERROR - 2017-02-03 23:07:59 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:08:45 --> Config Class Initialized
INFO - 2017-02-03 23:08:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:08:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:08:45 --> Utf8 Class Initialized
INFO - 2017-02-03 23:08:45 --> URI Class Initialized
INFO - 2017-02-03 23:08:45 --> Router Class Initialized
INFO - 2017-02-03 23:08:45 --> Output Class Initialized
INFO - 2017-02-03 23:08:45 --> Security Class Initialized
DEBUG - 2017-02-03 23:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:08:45 --> Input Class Initialized
INFO - 2017-02-03 23:08:45 --> Language Class Initialized
INFO - 2017-02-03 23:08:45 --> Language Class Initialized
INFO - 2017-02-03 23:08:45 --> Config Class Initialized
INFO - 2017-02-03 23:08:45 --> Loader Class Initialized
INFO - 2017-02-03 23:08:45 --> Helper loaded: url_helper
INFO - 2017-02-03 23:08:45 --> Helper loaded: file_helper
INFO - 2017-02-03 23:08:45 --> Database Driver Class Initialized
INFO - 2017-02-03 23:08:45 --> Model Class Initialized
INFO - 2017-02-03 23:08:45 --> Model Class Initialized
INFO - 2017-02-03 23:08:45 --> Controller Class Initialized
DEBUG - 2017-02-03 23:08:45 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:08:45 --> Severity: Error --> Class 'PageNumber' not found /var/www/html/wartabandung/application/models/Main_model.php 610
INFO - 2017-02-03 23:08:45 --> Config Class Initialized
INFO - 2017-02-03 23:08:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:08:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:08:45 --> Utf8 Class Initialized
INFO - 2017-02-03 23:08:45 --> URI Class Initialized
INFO - 2017-02-03 23:08:45 --> Router Class Initialized
INFO - 2017-02-03 23:08:45 --> Output Class Initialized
INFO - 2017-02-03 23:08:45 --> Security Class Initialized
DEBUG - 2017-02-03 23:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:08:45 --> Input Class Initialized
INFO - 2017-02-03 23:08:45 --> Language Class Initialized
ERROR - 2017-02-03 23:08:45 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:12:57 --> Config Class Initialized
INFO - 2017-02-03 23:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:12:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:12:57 --> URI Class Initialized
INFO - 2017-02-03 23:12:57 --> Router Class Initialized
INFO - 2017-02-03 23:12:57 --> Output Class Initialized
INFO - 2017-02-03 23:12:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:12:57 --> Input Class Initialized
INFO - 2017-02-03 23:12:57 --> Language Class Initialized
INFO - 2017-02-03 23:12:57 --> Language Class Initialized
INFO - 2017-02-03 23:12:57 --> Config Class Initialized
INFO - 2017-02-03 23:12:57 --> Loader Class Initialized
INFO - 2017-02-03 23:12:57 --> Helper loaded: url_helper
INFO - 2017-02-03 23:12:57 --> Helper loaded: file_helper
INFO - 2017-02-03 23:12:57 --> Database Driver Class Initialized
INFO - 2017-02-03 23:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:12:57 --> Pagination Class Initialized
INFO - 2017-02-03 23:12:57 --> Model Class Initialized
INFO - 2017-02-03 23:12:57 --> Model Class Initialized
INFO - 2017-02-03 23:12:57 --> Controller Class Initialized
DEBUG - 2017-02-03 23:12:57 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:12:57 --> Severity: Error --> Class 'PageNumber' not found /var/www/html/wartabandung/application/models/Main_model.php 610
INFO - 2017-02-03 23:12:57 --> Config Class Initialized
INFO - 2017-02-03 23:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:12:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:12:57 --> URI Class Initialized
INFO - 2017-02-03 23:12:57 --> Router Class Initialized
INFO - 2017-02-03 23:12:57 --> Output Class Initialized
INFO - 2017-02-03 23:12:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:12:57 --> Input Class Initialized
INFO - 2017-02-03 23:12:57 --> Language Class Initialized
ERROR - 2017-02-03 23:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:14:26 --> Config Class Initialized
INFO - 2017-02-03 23:14:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:14:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:14:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:14:26 --> URI Class Initialized
INFO - 2017-02-03 23:14:26 --> Router Class Initialized
INFO - 2017-02-03 23:14:26 --> Output Class Initialized
INFO - 2017-02-03 23:14:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:14:26 --> Input Class Initialized
INFO - 2017-02-03 23:14:26 --> Language Class Initialized
INFO - 2017-02-03 23:14:26 --> Language Class Initialized
INFO - 2017-02-03 23:14:26 --> Config Class Initialized
INFO - 2017-02-03 23:14:26 --> Loader Class Initialized
INFO - 2017-02-03 23:14:26 --> Helper loaded: url_helper
INFO - 2017-02-03 23:14:26 --> Helper loaded: file_helper
INFO - 2017-02-03 23:14:26 --> Database Driver Class Initialized
INFO - 2017-02-03 23:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:14:26 --> Pagination Class Initialized
INFO - 2017-02-03 23:14:26 --> Model Class Initialized
INFO - 2017-02-03 23:14:26 --> Model Class Initialized
INFO - 2017-02-03 23:14:26 --> Controller Class Initialized
DEBUG - 2017-02-03 23:14:26 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:14:26 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:14:26 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:14:26 --> Final output sent to browser
DEBUG - 2017-02-03 23:14:26 --> Total execution time: 0.0144
INFO - 2017-02-03 23:14:26 --> Config Class Initialized
INFO - 2017-02-03 23:14:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:14:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:14:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:14:26 --> URI Class Initialized
INFO - 2017-02-03 23:14:26 --> Router Class Initialized
INFO - 2017-02-03 23:14:26 --> Output Class Initialized
INFO - 2017-02-03 23:14:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:14:26 --> Input Class Initialized
INFO - 2017-02-03 23:14:26 --> Language Class Initialized
ERROR - 2017-02-03 23:14:26 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:15:15 --> Config Class Initialized
INFO - 2017-02-03 23:15:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:15:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:15:15 --> Utf8 Class Initialized
INFO - 2017-02-03 23:15:15 --> URI Class Initialized
INFO - 2017-02-03 23:15:15 --> Router Class Initialized
INFO - 2017-02-03 23:15:15 --> Output Class Initialized
INFO - 2017-02-03 23:15:15 --> Security Class Initialized
DEBUG - 2017-02-03 23:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:15:15 --> Input Class Initialized
INFO - 2017-02-03 23:15:15 --> Language Class Initialized
INFO - 2017-02-03 23:15:15 --> Language Class Initialized
INFO - 2017-02-03 23:15:15 --> Config Class Initialized
INFO - 2017-02-03 23:15:15 --> Loader Class Initialized
INFO - 2017-02-03 23:15:15 --> Helper loaded: url_helper
INFO - 2017-02-03 23:15:15 --> Helper loaded: file_helper
INFO - 2017-02-03 23:15:15 --> Database Driver Class Initialized
INFO - 2017-02-03 23:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:15:15 --> Pagination Class Initialized
INFO - 2017-02-03 23:15:15 --> Model Class Initialized
INFO - 2017-02-03 23:15:15 --> Model Class Initialized
INFO - 2017-02-03 23:15:15 --> Controller Class Initialized
DEBUG - 2017-02-03 23:15:15 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:15:15 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:15:15 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:15:15 --> Final output sent to browser
DEBUG - 2017-02-03 23:15:15 --> Total execution time: 0.0229
INFO - 2017-02-03 23:15:15 --> Config Class Initialized
INFO - 2017-02-03 23:15:15 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:15:15 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:15:15 --> Utf8 Class Initialized
INFO - 2017-02-03 23:15:15 --> URI Class Initialized
INFO - 2017-02-03 23:15:15 --> Router Class Initialized
INFO - 2017-02-03 23:15:15 --> Output Class Initialized
INFO - 2017-02-03 23:15:15 --> Security Class Initialized
DEBUG - 2017-02-03 23:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:15:15 --> Input Class Initialized
INFO - 2017-02-03 23:15:15 --> Language Class Initialized
ERROR - 2017-02-03 23:15:15 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:16:39 --> Config Class Initialized
INFO - 2017-02-03 23:16:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:16:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:16:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:16:39 --> URI Class Initialized
INFO - 2017-02-03 23:16:39 --> Router Class Initialized
INFO - 2017-02-03 23:16:39 --> Output Class Initialized
INFO - 2017-02-03 23:16:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:16:39 --> Input Class Initialized
INFO - 2017-02-03 23:16:39 --> Language Class Initialized
INFO - 2017-02-03 23:16:39 --> Language Class Initialized
INFO - 2017-02-03 23:16:39 --> Config Class Initialized
INFO - 2017-02-03 23:16:39 --> Loader Class Initialized
INFO - 2017-02-03 23:16:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:16:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:16:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:16:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:16:39 --> Model Class Initialized
INFO - 2017-02-03 23:16:39 --> Model Class Initialized
INFO - 2017-02-03 23:16:39 --> Controller Class Initialized
DEBUG - 2017-02-03 23:16:39 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:16:39 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:16:39 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:16:39 --> Final output sent to browser
DEBUG - 2017-02-03 23:16:39 --> Total execution time: 0.0124
INFO - 2017-02-03 23:16:40 --> Config Class Initialized
INFO - 2017-02-03 23:16:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:16:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:16:40 --> Utf8 Class Initialized
INFO - 2017-02-03 23:16:40 --> URI Class Initialized
INFO - 2017-02-03 23:16:40 --> Router Class Initialized
INFO - 2017-02-03 23:16:40 --> Output Class Initialized
INFO - 2017-02-03 23:16:40 --> Security Class Initialized
DEBUG - 2017-02-03 23:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:16:40 --> Input Class Initialized
INFO - 2017-02-03 23:16:40 --> Language Class Initialized
ERROR - 2017-02-03 23:16:40 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:16:43 --> Config Class Initialized
INFO - 2017-02-03 23:16:43 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:16:43 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:16:43 --> Utf8 Class Initialized
INFO - 2017-02-03 23:16:43 --> URI Class Initialized
INFO - 2017-02-03 23:16:43 --> Router Class Initialized
INFO - 2017-02-03 23:16:43 --> Output Class Initialized
INFO - 2017-02-03 23:16:43 --> Security Class Initialized
DEBUG - 2017-02-03 23:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:16:43 --> Input Class Initialized
INFO - 2017-02-03 23:16:43 --> Language Class Initialized
ERROR - 2017-02-03 23:16:43 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:18:06 --> Config Class Initialized
INFO - 2017-02-03 23:18:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:18:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:18:06 --> Utf8 Class Initialized
INFO - 2017-02-03 23:18:06 --> URI Class Initialized
INFO - 2017-02-03 23:18:06 --> Router Class Initialized
INFO - 2017-02-03 23:18:06 --> Output Class Initialized
INFO - 2017-02-03 23:18:06 --> Security Class Initialized
DEBUG - 2017-02-03 23:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:18:06 --> Input Class Initialized
INFO - 2017-02-03 23:18:06 --> Language Class Initialized
INFO - 2017-02-03 23:18:06 --> Language Class Initialized
INFO - 2017-02-03 23:18:06 --> Config Class Initialized
INFO - 2017-02-03 23:18:06 --> Loader Class Initialized
INFO - 2017-02-03 23:18:06 --> Helper loaded: url_helper
INFO - 2017-02-03 23:18:06 --> Helper loaded: file_helper
INFO - 2017-02-03 23:18:06 --> Database Driver Class Initialized
INFO - 2017-02-03 23:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:18:06 --> Pagination Class Initialized
INFO - 2017-02-03 23:18:06 --> Model Class Initialized
INFO - 2017-02-03 23:18:06 --> Model Class Initialized
INFO - 2017-02-03 23:18:06 --> Controller Class Initialized
DEBUG - 2017-02-03 23:18:06 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:18:06 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:18:06 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:18:06 --> Final output sent to browser
DEBUG - 2017-02-03 23:18:06 --> Total execution time: 0.0163
INFO - 2017-02-03 23:18:07 --> Config Class Initialized
INFO - 2017-02-03 23:18:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:18:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:18:07 --> Utf8 Class Initialized
INFO - 2017-02-03 23:18:07 --> URI Class Initialized
INFO - 2017-02-03 23:18:07 --> Router Class Initialized
INFO - 2017-02-03 23:18:07 --> Output Class Initialized
INFO - 2017-02-03 23:18:07 --> Security Class Initialized
DEBUG - 2017-02-03 23:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:18:07 --> Input Class Initialized
INFO - 2017-02-03 23:18:07 --> Language Class Initialized
ERROR - 2017-02-03 23:18:07 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:18:07 --> Config Class Initialized
INFO - 2017-02-03 23:18:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:18:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:18:07 --> Utf8 Class Initialized
INFO - 2017-02-03 23:18:07 --> URI Class Initialized
INFO - 2017-02-03 23:18:07 --> Router Class Initialized
INFO - 2017-02-03 23:18:07 --> Output Class Initialized
INFO - 2017-02-03 23:18:07 --> Security Class Initialized
DEBUG - 2017-02-03 23:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:18:07 --> Input Class Initialized
INFO - 2017-02-03 23:18:07 --> Language Class Initialized
ERROR - 2017-02-03 23:18:07 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:18:18 --> Config Class Initialized
INFO - 2017-02-03 23:18:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:18:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:18:18 --> Utf8 Class Initialized
INFO - 2017-02-03 23:18:18 --> URI Class Initialized
INFO - 2017-02-03 23:18:18 --> Router Class Initialized
INFO - 2017-02-03 23:18:18 --> Output Class Initialized
INFO - 2017-02-03 23:18:18 --> Security Class Initialized
DEBUG - 2017-02-03 23:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:18:18 --> Input Class Initialized
INFO - 2017-02-03 23:18:18 --> Language Class Initialized
INFO - 2017-02-03 23:18:18 --> Language Class Initialized
INFO - 2017-02-03 23:18:18 --> Config Class Initialized
INFO - 2017-02-03 23:18:18 --> Loader Class Initialized
INFO - 2017-02-03 23:18:18 --> Helper loaded: url_helper
INFO - 2017-02-03 23:18:18 --> Helper loaded: file_helper
INFO - 2017-02-03 23:18:18 --> Database Driver Class Initialized
INFO - 2017-02-03 23:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:18:18 --> Pagination Class Initialized
INFO - 2017-02-03 23:18:18 --> Model Class Initialized
INFO - 2017-02-03 23:18:18 --> Model Class Initialized
INFO - 2017-02-03 23:18:18 --> Controller Class Initialized
DEBUG - 2017-02-03 23:18:18 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:18:18 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:18:18 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:18:18 --> Final output sent to browser
DEBUG - 2017-02-03 23:18:18 --> Total execution time: 0.0153
INFO - 2017-02-03 23:18:18 --> Config Class Initialized
INFO - 2017-02-03 23:18:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:18:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:18:18 --> Utf8 Class Initialized
INFO - 2017-02-03 23:18:18 --> URI Class Initialized
INFO - 2017-02-03 23:18:18 --> Router Class Initialized
INFO - 2017-02-03 23:18:18 --> Output Class Initialized
INFO - 2017-02-03 23:18:18 --> Security Class Initialized
DEBUG - 2017-02-03 23:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:18:18 --> Input Class Initialized
INFO - 2017-02-03 23:18:18 --> Language Class Initialized
ERROR - 2017-02-03 23:18:18 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:18:19 --> Config Class Initialized
INFO - 2017-02-03 23:18:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:18:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:18:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:18:19 --> URI Class Initialized
INFO - 2017-02-03 23:18:19 --> Router Class Initialized
INFO - 2017-02-03 23:18:19 --> Output Class Initialized
INFO - 2017-02-03 23:18:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:18:19 --> Input Class Initialized
INFO - 2017-02-03 23:18:19 --> Language Class Initialized
ERROR - 2017-02-03 23:18:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:19:46 --> Config Class Initialized
INFO - 2017-02-03 23:19:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:19:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:19:46 --> Utf8 Class Initialized
INFO - 2017-02-03 23:19:46 --> URI Class Initialized
INFO - 2017-02-03 23:19:46 --> Router Class Initialized
INFO - 2017-02-03 23:19:46 --> Output Class Initialized
INFO - 2017-02-03 23:19:46 --> Security Class Initialized
DEBUG - 2017-02-03 23:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:19:46 --> Input Class Initialized
INFO - 2017-02-03 23:19:46 --> Language Class Initialized
ERROR - 2017-02-03 23:19:46 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 8
INFO - 2017-02-03 23:20:28 --> Config Class Initialized
INFO - 2017-02-03 23:20:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:20:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:20:28 --> Utf8 Class Initialized
INFO - 2017-02-03 23:20:28 --> URI Class Initialized
INFO - 2017-02-03 23:20:28 --> Router Class Initialized
INFO - 2017-02-03 23:20:28 --> Output Class Initialized
INFO - 2017-02-03 23:20:28 --> Security Class Initialized
DEBUG - 2017-02-03 23:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:20:28 --> Input Class Initialized
INFO - 2017-02-03 23:20:28 --> Language Class Initialized
INFO - 2017-02-03 23:20:28 --> Language Class Initialized
INFO - 2017-02-03 23:20:28 --> Config Class Initialized
INFO - 2017-02-03 23:20:28 --> Loader Class Initialized
INFO - 2017-02-03 23:20:28 --> Helper loaded: url_helper
INFO - 2017-02-03 23:20:28 --> Helper loaded: file_helper
INFO - 2017-02-03 23:20:28 --> Database Driver Class Initialized
INFO - 2017-02-03 23:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:20:28 --> Pagination Class Initialized
INFO - 2017-02-03 23:20:28 --> Model Class Initialized
INFO - 2017-02-03 23:20:28 --> Model Class Initialized
INFO - 2017-02-03 23:20:28 --> Controller Class Initialized
DEBUG - 2017-02-03 23:20:28 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:20:28 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:20:28 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:20:28 --> Final output sent to browser
DEBUG - 2017-02-03 23:20:28 --> Total execution time: 0.0196
INFO - 2017-02-03 23:20:28 --> Config Class Initialized
INFO - 2017-02-03 23:20:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:20:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:20:28 --> Utf8 Class Initialized
INFO - 2017-02-03 23:20:28 --> URI Class Initialized
INFO - 2017-02-03 23:20:28 --> Router Class Initialized
INFO - 2017-02-03 23:20:28 --> Output Class Initialized
INFO - 2017-02-03 23:20:28 --> Security Class Initialized
DEBUG - 2017-02-03 23:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:20:28 --> Input Class Initialized
INFO - 2017-02-03 23:20:28 --> Language Class Initialized
ERROR - 2017-02-03 23:20:28 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:20:28 --> Config Class Initialized
INFO - 2017-02-03 23:20:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:20:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:20:28 --> Utf8 Class Initialized
INFO - 2017-02-03 23:20:28 --> URI Class Initialized
INFO - 2017-02-03 23:20:28 --> Router Class Initialized
INFO - 2017-02-03 23:20:28 --> Output Class Initialized
INFO - 2017-02-03 23:20:28 --> Security Class Initialized
DEBUG - 2017-02-03 23:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:20:28 --> Input Class Initialized
INFO - 2017-02-03 23:20:28 --> Language Class Initialized
ERROR - 2017-02-03 23:20:28 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:21:29 --> Config Class Initialized
INFO - 2017-02-03 23:21:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:29 --> URI Class Initialized
INFO - 2017-02-03 23:21:29 --> Router Class Initialized
INFO - 2017-02-03 23:21:29 --> Output Class Initialized
INFO - 2017-02-03 23:21:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:29 --> Input Class Initialized
INFO - 2017-02-03 23:21:29 --> Language Class Initialized
INFO - 2017-02-03 23:21:29 --> Language Class Initialized
INFO - 2017-02-03 23:21:29 --> Config Class Initialized
INFO - 2017-02-03 23:21:29 --> Loader Class Initialized
INFO - 2017-02-03 23:21:29 --> Helper loaded: url_helper
INFO - 2017-02-03 23:21:29 --> Helper loaded: file_helper
INFO - 2017-02-03 23:21:29 --> Database Driver Class Initialized
INFO - 2017-02-03 23:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:21:29 --> Pagination Class Initialized
INFO - 2017-02-03 23:21:29 --> Model Class Initialized
INFO - 2017-02-03 23:21:29 --> Model Class Initialized
INFO - 2017-02-03 23:21:29 --> Controller Class Initialized
DEBUG - 2017-02-03 23:21:29 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:21:29 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:21:29 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:21:29 --> Final output sent to browser
DEBUG - 2017-02-03 23:21:29 --> Total execution time: 0.0158
INFO - 2017-02-03 23:21:30 --> Config Class Initialized
INFO - 2017-02-03 23:21:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:30 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:30 --> URI Class Initialized
INFO - 2017-02-03 23:21:30 --> Router Class Initialized
INFO - 2017-02-03 23:21:30 --> Output Class Initialized
INFO - 2017-02-03 23:21:30 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:30 --> Input Class Initialized
INFO - 2017-02-03 23:21:30 --> Language Class Initialized
ERROR - 2017-02-03 23:21:30 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:21:30 --> Config Class Initialized
INFO - 2017-02-03 23:21:30 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:30 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:30 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:30 --> URI Class Initialized
INFO - 2017-02-03 23:21:30 --> Router Class Initialized
INFO - 2017-02-03 23:21:30 --> Output Class Initialized
INFO - 2017-02-03 23:21:30 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:30 --> Input Class Initialized
INFO - 2017-02-03 23:21:30 --> Language Class Initialized
ERROR - 2017-02-03 23:21:30 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:21:34 --> Config Class Initialized
INFO - 2017-02-03 23:21:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:34 --> URI Class Initialized
INFO - 2017-02-03 23:21:34 --> Router Class Initialized
INFO - 2017-02-03 23:21:34 --> Output Class Initialized
INFO - 2017-02-03 23:21:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:34 --> Input Class Initialized
INFO - 2017-02-03 23:21:34 --> Language Class Initialized
ERROR - 2017-02-03 23:21:34 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:21:36 --> Config Class Initialized
INFO - 2017-02-03 23:21:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:36 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:36 --> URI Class Initialized
INFO - 2017-02-03 23:21:36 --> Router Class Initialized
INFO - 2017-02-03 23:21:36 --> Output Class Initialized
INFO - 2017-02-03 23:21:36 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:36 --> Input Class Initialized
INFO - 2017-02-03 23:21:36 --> Language Class Initialized
INFO - 2017-02-03 23:21:36 --> Language Class Initialized
INFO - 2017-02-03 23:21:36 --> Config Class Initialized
INFO - 2017-02-03 23:21:36 --> Loader Class Initialized
INFO - 2017-02-03 23:21:36 --> Helper loaded: url_helper
INFO - 2017-02-03 23:21:36 --> Helper loaded: file_helper
INFO - 2017-02-03 23:21:36 --> Database Driver Class Initialized
INFO - 2017-02-03 23:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:21:36 --> Pagination Class Initialized
INFO - 2017-02-03 23:21:36 --> Model Class Initialized
INFO - 2017-02-03 23:21:36 --> Model Class Initialized
INFO - 2017-02-03 23:21:36 --> Controller Class Initialized
DEBUG - 2017-02-03 23:21:36 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:21:36 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:21:36 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:21:36 --> Final output sent to browser
DEBUG - 2017-02-03 23:21:36 --> Total execution time: 0.0109
INFO - 2017-02-03 23:21:37 --> Config Class Initialized
INFO - 2017-02-03 23:21:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:37 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:37 --> URI Class Initialized
INFO - 2017-02-03 23:21:37 --> Router Class Initialized
INFO - 2017-02-03 23:21:37 --> Output Class Initialized
INFO - 2017-02-03 23:21:37 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:37 --> Input Class Initialized
INFO - 2017-02-03 23:21:37 --> Language Class Initialized
ERROR - 2017-02-03 23:21:37 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:21:37 --> Config Class Initialized
INFO - 2017-02-03 23:21:37 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:37 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:37 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:37 --> URI Class Initialized
INFO - 2017-02-03 23:21:37 --> Router Class Initialized
INFO - 2017-02-03 23:21:37 --> Output Class Initialized
INFO - 2017-02-03 23:21:37 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:37 --> Input Class Initialized
INFO - 2017-02-03 23:21:37 --> Language Class Initialized
ERROR - 2017-02-03 23:21:37 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:21:47 --> Config Class Initialized
INFO - 2017-02-03 23:21:47 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:47 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:47 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:47 --> URI Class Initialized
INFO - 2017-02-03 23:21:47 --> Router Class Initialized
INFO - 2017-02-03 23:21:47 --> Output Class Initialized
INFO - 2017-02-03 23:21:47 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:47 --> Input Class Initialized
INFO - 2017-02-03 23:21:47 --> Language Class Initialized
INFO - 2017-02-03 23:21:47 --> Language Class Initialized
INFO - 2017-02-03 23:21:47 --> Config Class Initialized
INFO - 2017-02-03 23:21:47 --> Loader Class Initialized
INFO - 2017-02-03 23:21:47 --> Helper loaded: url_helper
INFO - 2017-02-03 23:21:47 --> Helper loaded: file_helper
INFO - 2017-02-03 23:21:47 --> Database Driver Class Initialized
INFO - 2017-02-03 23:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:21:47 --> Pagination Class Initialized
INFO - 2017-02-03 23:21:47 --> Model Class Initialized
INFO - 2017-02-03 23:21:47 --> Model Class Initialized
INFO - 2017-02-03 23:21:47 --> Controller Class Initialized
DEBUG - 2017-02-03 23:21:47 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:21:47 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:21:47 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:21:47 --> Final output sent to browser
DEBUG - 2017-02-03 23:21:47 --> Total execution time: 0.0156
INFO - 2017-02-03 23:21:48 --> Config Class Initialized
INFO - 2017-02-03 23:21:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:48 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:48 --> URI Class Initialized
INFO - 2017-02-03 23:21:48 --> Router Class Initialized
INFO - 2017-02-03 23:21:48 --> Output Class Initialized
INFO - 2017-02-03 23:21:48 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:48 --> Input Class Initialized
INFO - 2017-02-03 23:21:48 --> Language Class Initialized
ERROR - 2017-02-03 23:21:48 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:21:48 --> Config Class Initialized
INFO - 2017-02-03 23:21:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:21:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:21:48 --> Utf8 Class Initialized
INFO - 2017-02-03 23:21:48 --> URI Class Initialized
INFO - 2017-02-03 23:21:48 --> Router Class Initialized
INFO - 2017-02-03 23:21:48 --> Output Class Initialized
INFO - 2017-02-03 23:21:48 --> Security Class Initialized
DEBUG - 2017-02-03 23:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:21:48 --> Input Class Initialized
INFO - 2017-02-03 23:21:48 --> Language Class Initialized
ERROR - 2017-02-03 23:21:48 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:22:16 --> Config Class Initialized
INFO - 2017-02-03 23:22:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:16 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:16 --> URI Class Initialized
INFO - 2017-02-03 23:22:16 --> Router Class Initialized
INFO - 2017-02-03 23:22:16 --> Output Class Initialized
INFO - 2017-02-03 23:22:16 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:16 --> Input Class Initialized
INFO - 2017-02-03 23:22:16 --> Language Class Initialized
INFO - 2017-02-03 23:22:16 --> Language Class Initialized
INFO - 2017-02-03 23:22:16 --> Config Class Initialized
INFO - 2017-02-03 23:22:16 --> Loader Class Initialized
INFO - 2017-02-03 23:22:16 --> Helper loaded: url_helper
INFO - 2017-02-03 23:22:16 --> Helper loaded: file_helper
INFO - 2017-02-03 23:22:16 --> Database Driver Class Initialized
INFO - 2017-02-03 23:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:22:16 --> Pagination Class Initialized
INFO - 2017-02-03 23:22:16 --> Model Class Initialized
INFO - 2017-02-03 23:22:16 --> Model Class Initialized
INFO - 2017-02-03 23:22:16 --> Controller Class Initialized
DEBUG - 2017-02-03 23:22:16 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:22:16 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:22:16 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:22:16 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:22:17 --> Config Class Initialized
INFO - 2017-02-03 23:22:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:17 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:17 --> URI Class Initialized
INFO - 2017-02-03 23:22:17 --> Router Class Initialized
INFO - 2017-02-03 23:22:17 --> Output Class Initialized
INFO - 2017-02-03 23:22:17 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:17 --> Input Class Initialized
INFO - 2017-02-03 23:22:17 --> Language Class Initialized
ERROR - 2017-02-03 23:22:17 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:22:17 --> Config Class Initialized
INFO - 2017-02-03 23:22:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:17 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:17 --> URI Class Initialized
INFO - 2017-02-03 23:22:17 --> Router Class Initialized
INFO - 2017-02-03 23:22:17 --> Output Class Initialized
INFO - 2017-02-03 23:22:17 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:17 --> Input Class Initialized
INFO - 2017-02-03 23:22:17 --> Language Class Initialized
ERROR - 2017-02-03 23:22:17 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:22:41 --> Config Class Initialized
INFO - 2017-02-03 23:22:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:41 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:41 --> URI Class Initialized
INFO - 2017-02-03 23:22:41 --> Router Class Initialized
INFO - 2017-02-03 23:22:41 --> Output Class Initialized
INFO - 2017-02-03 23:22:41 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:41 --> Input Class Initialized
INFO - 2017-02-03 23:22:41 --> Language Class Initialized
INFO - 2017-02-03 23:22:41 --> Language Class Initialized
INFO - 2017-02-03 23:22:41 --> Config Class Initialized
INFO - 2017-02-03 23:22:41 --> Loader Class Initialized
INFO - 2017-02-03 23:22:41 --> Helper loaded: url_helper
INFO - 2017-02-03 23:22:41 --> Helper loaded: file_helper
INFO - 2017-02-03 23:22:41 --> Database Driver Class Initialized
INFO - 2017-02-03 23:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:22:41 --> Pagination Class Initialized
INFO - 2017-02-03 23:22:41 --> Model Class Initialized
INFO - 2017-02-03 23:22:41 --> Model Class Initialized
INFO - 2017-02-03 23:22:41 --> Controller Class Initialized
DEBUG - 2017-02-03 23:22:41 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:22:41 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:22:41 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:22:41 --> Final output sent to browser
DEBUG - 2017-02-03 23:22:41 --> Total execution time: 0.0604
INFO - 2017-02-03 23:22:42 --> Config Class Initialized
INFO - 2017-02-03 23:22:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:42 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:42 --> URI Class Initialized
INFO - 2017-02-03 23:22:42 --> Router Class Initialized
INFO - 2017-02-03 23:22:42 --> Output Class Initialized
INFO - 2017-02-03 23:22:42 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:42 --> Input Class Initialized
INFO - 2017-02-03 23:22:42 --> Language Class Initialized
ERROR - 2017-02-03 23:22:42 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:22:42 --> Config Class Initialized
INFO - 2017-02-03 23:22:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:42 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:42 --> URI Class Initialized
INFO - 2017-02-03 23:22:42 --> Router Class Initialized
INFO - 2017-02-03 23:22:42 --> Output Class Initialized
INFO - 2017-02-03 23:22:42 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:42 --> Input Class Initialized
INFO - 2017-02-03 23:22:42 --> Language Class Initialized
ERROR - 2017-02-03 23:22:42 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:22:51 --> Config Class Initialized
INFO - 2017-02-03 23:22:51 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:51 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:51 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:51 --> URI Class Initialized
INFO - 2017-02-03 23:22:51 --> Router Class Initialized
INFO - 2017-02-03 23:22:51 --> Output Class Initialized
INFO - 2017-02-03 23:22:51 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:51 --> Input Class Initialized
INFO - 2017-02-03 23:22:51 --> Language Class Initialized
INFO - 2017-02-03 23:22:51 --> Language Class Initialized
INFO - 2017-02-03 23:22:51 --> Config Class Initialized
INFO - 2017-02-03 23:22:51 --> Loader Class Initialized
INFO - 2017-02-03 23:22:51 --> Helper loaded: url_helper
INFO - 2017-02-03 23:22:51 --> Helper loaded: file_helper
INFO - 2017-02-03 23:22:51 --> Database Driver Class Initialized
INFO - 2017-02-03 23:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:22:51 --> Pagination Class Initialized
INFO - 2017-02-03 23:22:51 --> Model Class Initialized
INFO - 2017-02-03 23:22:51 --> Model Class Initialized
INFO - 2017-02-03 23:22:51 --> Controller Class Initialized
ERROR - 2017-02-03 23:22:51 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:22:52 --> Config Class Initialized
INFO - 2017-02-03 23:22:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:22:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:22:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:22:52 --> URI Class Initialized
INFO - 2017-02-03 23:22:52 --> Router Class Initialized
INFO - 2017-02-03 23:22:52 --> Output Class Initialized
INFO - 2017-02-03 23:22:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:22:52 --> Input Class Initialized
INFO - 2017-02-03 23:22:52 --> Language Class Initialized
INFO - 2017-02-03 23:22:52 --> Language Class Initialized
INFO - 2017-02-03 23:22:52 --> Config Class Initialized
INFO - 2017-02-03 23:22:52 --> Loader Class Initialized
INFO - 2017-02-03 23:22:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:22:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:22:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:22:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:22:52 --> Model Class Initialized
INFO - 2017-02-03 23:22:52 --> Model Class Initialized
INFO - 2017-02-03 23:22:52 --> Controller Class Initialized
ERROR - 2017-02-03 23:22:52 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:23:25 --> Config Class Initialized
INFO - 2017-02-03 23:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:23:25 --> Utf8 Class Initialized
INFO - 2017-02-03 23:23:25 --> URI Class Initialized
INFO - 2017-02-03 23:23:25 --> Router Class Initialized
INFO - 2017-02-03 23:23:25 --> Output Class Initialized
INFO - 2017-02-03 23:23:25 --> Security Class Initialized
DEBUG - 2017-02-03 23:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:23:25 --> Input Class Initialized
INFO - 2017-02-03 23:23:25 --> Language Class Initialized
INFO - 2017-02-03 23:23:25 --> Language Class Initialized
INFO - 2017-02-03 23:23:25 --> Config Class Initialized
INFO - 2017-02-03 23:23:25 --> Loader Class Initialized
INFO - 2017-02-03 23:23:25 --> Helper loaded: url_helper
INFO - 2017-02-03 23:23:25 --> Helper loaded: file_helper
INFO - 2017-02-03 23:23:25 --> Database Driver Class Initialized
INFO - 2017-02-03 23:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:23:25 --> Pagination Class Initialized
INFO - 2017-02-03 23:23:25 --> Model Class Initialized
INFO - 2017-02-03 23:23:25 --> Model Class Initialized
INFO - 2017-02-03 23:23:25 --> Controller Class Initialized
DEBUG - 2017-02-03 23:23:25 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:23:25 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:23:25 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:23:25 --> Final output sent to browser
DEBUG - 2017-02-03 23:23:25 --> Total execution time: 0.0191
INFO - 2017-02-03 23:23:26 --> Config Class Initialized
INFO - 2017-02-03 23:23:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:23:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:23:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:23:26 --> URI Class Initialized
INFO - 2017-02-03 23:23:26 --> Router Class Initialized
INFO - 2017-02-03 23:23:26 --> Output Class Initialized
INFO - 2017-02-03 23:23:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:23:26 --> Input Class Initialized
INFO - 2017-02-03 23:23:26 --> Language Class Initialized
ERROR - 2017-02-03 23:23:26 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:23:26 --> Config Class Initialized
INFO - 2017-02-03 23:23:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:23:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:23:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:23:26 --> URI Class Initialized
INFO - 2017-02-03 23:23:26 --> Router Class Initialized
INFO - 2017-02-03 23:23:26 --> Output Class Initialized
INFO - 2017-02-03 23:23:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:23:26 --> Input Class Initialized
INFO - 2017-02-03 23:23:26 --> Language Class Initialized
ERROR - 2017-02-03 23:23:26 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:24:16 --> Config Class Initialized
INFO - 2017-02-03 23:24:16 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:24:16 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:24:16 --> Utf8 Class Initialized
INFO - 2017-02-03 23:24:16 --> URI Class Initialized
INFO - 2017-02-03 23:24:16 --> Router Class Initialized
INFO - 2017-02-03 23:24:16 --> Output Class Initialized
INFO - 2017-02-03 23:24:16 --> Security Class Initialized
DEBUG - 2017-02-03 23:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:24:16 --> Input Class Initialized
INFO - 2017-02-03 23:24:16 --> Language Class Initialized
INFO - 2017-02-03 23:24:16 --> Language Class Initialized
INFO - 2017-02-03 23:24:16 --> Config Class Initialized
INFO - 2017-02-03 23:24:16 --> Loader Class Initialized
INFO - 2017-02-03 23:24:16 --> Helper loaded: url_helper
INFO - 2017-02-03 23:24:16 --> Helper loaded: file_helper
INFO - 2017-02-03 23:24:16 --> Database Driver Class Initialized
INFO - 2017-02-03 23:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:24:16 --> Pagination Class Initialized
INFO - 2017-02-03 23:24:16 --> Model Class Initialized
INFO - 2017-02-03 23:24:16 --> Model Class Initialized
INFO - 2017-02-03 23:24:16 --> Controller Class Initialized
DEBUG - 2017-02-03 23:24:16 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:24:16 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:24:16 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:24:16 --> Final output sent to browser
DEBUG - 2017-02-03 23:24:16 --> Total execution time: 0.0087
INFO - 2017-02-03 23:24:17 --> Config Class Initialized
INFO - 2017-02-03 23:24:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:24:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:24:17 --> Utf8 Class Initialized
INFO - 2017-02-03 23:24:17 --> URI Class Initialized
INFO - 2017-02-03 23:24:17 --> Router Class Initialized
INFO - 2017-02-03 23:24:17 --> Output Class Initialized
INFO - 2017-02-03 23:24:17 --> Security Class Initialized
DEBUG - 2017-02-03 23:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:24:17 --> Input Class Initialized
INFO - 2017-02-03 23:24:17 --> Language Class Initialized
ERROR - 2017-02-03 23:24:17 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:24:17 --> Config Class Initialized
INFO - 2017-02-03 23:24:17 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:24:17 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:24:17 --> Utf8 Class Initialized
INFO - 2017-02-03 23:24:17 --> URI Class Initialized
INFO - 2017-02-03 23:24:17 --> Router Class Initialized
INFO - 2017-02-03 23:24:17 --> Output Class Initialized
INFO - 2017-02-03 23:24:17 --> Security Class Initialized
DEBUG - 2017-02-03 23:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:24:17 --> Input Class Initialized
INFO - 2017-02-03 23:24:17 --> Language Class Initialized
ERROR - 2017-02-03 23:24:17 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:25:06 --> Config Class Initialized
INFO - 2017-02-03 23:25:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:25:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:25:06 --> Utf8 Class Initialized
INFO - 2017-02-03 23:25:06 --> URI Class Initialized
INFO - 2017-02-03 23:25:06 --> Router Class Initialized
INFO - 2017-02-03 23:25:06 --> Output Class Initialized
INFO - 2017-02-03 23:25:06 --> Security Class Initialized
DEBUG - 2017-02-03 23:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:25:06 --> Input Class Initialized
INFO - 2017-02-03 23:25:06 --> Language Class Initialized
INFO - 2017-02-03 23:25:06 --> Language Class Initialized
INFO - 2017-02-03 23:25:06 --> Config Class Initialized
INFO - 2017-02-03 23:25:06 --> Loader Class Initialized
INFO - 2017-02-03 23:25:06 --> Helper loaded: url_helper
INFO - 2017-02-03 23:25:06 --> Helper loaded: file_helper
INFO - 2017-02-03 23:25:06 --> Database Driver Class Initialized
INFO - 2017-02-03 23:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:25:06 --> Pagination Class Initialized
INFO - 2017-02-03 23:25:06 --> Model Class Initialized
INFO - 2017-02-03 23:25:06 --> Model Class Initialized
INFO - 2017-02-03 23:25:06 --> Controller Class Initialized
DEBUG - 2017-02-03 23:25:06 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:25:06 --> Severity: Warning --> Missing argument 1 for Kategori::index() /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 6
ERROR - 2017-02-03 23:25:06 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 15
DEBUG - 2017-02-03 23:25:06 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:25:06 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:25:06 --> Final output sent to browser
DEBUG - 2017-02-03 23:25:06 --> Total execution time: 0.0474
INFO - 2017-02-03 23:25:06 --> Config Class Initialized
INFO - 2017-02-03 23:25:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:25:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:25:06 --> Utf8 Class Initialized
INFO - 2017-02-03 23:25:06 --> URI Class Initialized
INFO - 2017-02-03 23:25:06 --> Router Class Initialized
INFO - 2017-02-03 23:25:06 --> Output Class Initialized
INFO - 2017-02-03 23:25:06 --> Security Class Initialized
DEBUG - 2017-02-03 23:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:25:06 --> Input Class Initialized
INFO - 2017-02-03 23:25:06 --> Language Class Initialized
ERROR - 2017-02-03 23:25:06 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:25:06 --> Config Class Initialized
INFO - 2017-02-03 23:25:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:25:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:25:06 --> Utf8 Class Initialized
INFO - 2017-02-03 23:25:06 --> URI Class Initialized
INFO - 2017-02-03 23:25:06 --> Router Class Initialized
INFO - 2017-02-03 23:25:06 --> Output Class Initialized
INFO - 2017-02-03 23:25:06 --> Security Class Initialized
DEBUG - 2017-02-03 23:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:25:06 --> Input Class Initialized
INFO - 2017-02-03 23:25:06 --> Language Class Initialized
ERROR - 2017-02-03 23:25:06 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:26:01 --> Config Class Initialized
INFO - 2017-02-03 23:26:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:26:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:26:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:26:01 --> URI Class Initialized
INFO - 2017-02-03 23:26:01 --> Router Class Initialized
INFO - 2017-02-03 23:26:01 --> Output Class Initialized
INFO - 2017-02-03 23:26:01 --> Security Class Initialized
DEBUG - 2017-02-03 23:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:26:01 --> Input Class Initialized
INFO - 2017-02-03 23:26:01 --> Language Class Initialized
INFO - 2017-02-03 23:26:01 --> Language Class Initialized
INFO - 2017-02-03 23:26:01 --> Config Class Initialized
INFO - 2017-02-03 23:26:01 --> Loader Class Initialized
INFO - 2017-02-03 23:26:01 --> Helper loaded: url_helper
INFO - 2017-02-03 23:26:01 --> Helper loaded: file_helper
INFO - 2017-02-03 23:26:01 --> Database Driver Class Initialized
INFO - 2017-02-03 23:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:26:01 --> Pagination Class Initialized
INFO - 2017-02-03 23:26:01 --> Model Class Initialized
INFO - 2017-02-03 23:26:01 --> Model Class Initialized
INFO - 2017-02-03 23:26:01 --> Controller Class Initialized
DEBUG - 2017-02-03 23:26:01 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:26:01 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 15
DEBUG - 2017-02-03 23:26:01 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:26:01 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:26:01 --> Final output sent to browser
DEBUG - 2017-02-03 23:26:01 --> Total execution time: 0.0121
INFO - 2017-02-03 23:26:02 --> Config Class Initialized
INFO - 2017-02-03 23:26:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:26:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:26:02 --> Utf8 Class Initialized
INFO - 2017-02-03 23:26:02 --> URI Class Initialized
INFO - 2017-02-03 23:26:02 --> Router Class Initialized
INFO - 2017-02-03 23:26:02 --> Output Class Initialized
INFO - 2017-02-03 23:26:02 --> Security Class Initialized
DEBUG - 2017-02-03 23:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:26:02 --> Input Class Initialized
INFO - 2017-02-03 23:26:02 --> Language Class Initialized
ERROR - 2017-02-03 23:26:02 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:26:02 --> Config Class Initialized
INFO - 2017-02-03 23:26:02 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:26:02 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:26:02 --> Utf8 Class Initialized
INFO - 2017-02-03 23:26:02 --> URI Class Initialized
INFO - 2017-02-03 23:26:02 --> Router Class Initialized
INFO - 2017-02-03 23:26:02 --> Output Class Initialized
INFO - 2017-02-03 23:26:02 --> Security Class Initialized
DEBUG - 2017-02-03 23:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:26:02 --> Input Class Initialized
INFO - 2017-02-03 23:26:02 --> Language Class Initialized
ERROR - 2017-02-03 23:26:02 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:28:36 --> Config Class Initialized
INFO - 2017-02-03 23:28:36 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:28:36 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:28:36 --> Utf8 Class Initialized
INFO - 2017-02-03 23:28:36 --> URI Class Initialized
INFO - 2017-02-03 23:28:36 --> Router Class Initialized
INFO - 2017-02-03 23:28:36 --> Output Class Initialized
INFO - 2017-02-03 23:28:36 --> Security Class Initialized
DEBUG - 2017-02-03 23:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:28:36 --> Input Class Initialized
INFO - 2017-02-03 23:28:36 --> Language Class Initialized
ERROR - 2017-02-03 23:28:36 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:28:45 --> Config Class Initialized
INFO - 2017-02-03 23:28:45 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:28:45 --> Utf8 Class Initialized
INFO - 2017-02-03 23:28:45 --> URI Class Initialized
INFO - 2017-02-03 23:28:45 --> Router Class Initialized
INFO - 2017-02-03 23:28:45 --> Output Class Initialized
INFO - 2017-02-03 23:28:45 --> Security Class Initialized
DEBUG - 2017-02-03 23:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:28:45 --> Input Class Initialized
INFO - 2017-02-03 23:28:45 --> Language Class Initialized
ERROR - 2017-02-03 23:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:29:04 --> Config Class Initialized
INFO - 2017-02-03 23:29:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:04 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:04 --> URI Class Initialized
INFO - 2017-02-03 23:29:04 --> Router Class Initialized
INFO - 2017-02-03 23:29:04 --> Output Class Initialized
INFO - 2017-02-03 23:29:04 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:04 --> Input Class Initialized
INFO - 2017-02-03 23:29:04 --> Language Class Initialized
ERROR - 2017-02-03 23:29:04 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:29:39 --> Config Class Initialized
INFO - 2017-02-03 23:29:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:39 --> URI Class Initialized
INFO - 2017-02-03 23:29:39 --> Router Class Initialized
INFO - 2017-02-03 23:29:39 --> Output Class Initialized
INFO - 2017-02-03 23:29:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:39 --> Input Class Initialized
INFO - 2017-02-03 23:29:39 --> Language Class Initialized
ERROR - 2017-02-03 23:29:39 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:29:42 --> Config Class Initialized
INFO - 2017-02-03 23:29:42 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:42 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:42 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:42 --> URI Class Initialized
INFO - 2017-02-03 23:29:42 --> Router Class Initialized
INFO - 2017-02-03 23:29:42 --> Output Class Initialized
INFO - 2017-02-03 23:29:42 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:42 --> Input Class Initialized
INFO - 2017-02-03 23:29:42 --> Language Class Initialized
ERROR - 2017-02-03 23:29:42 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:29:46 --> Config Class Initialized
INFO - 2017-02-03 23:29:46 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:46 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:46 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:46 --> URI Class Initialized
INFO - 2017-02-03 23:29:46 --> Router Class Initialized
INFO - 2017-02-03 23:29:46 --> Output Class Initialized
INFO - 2017-02-03 23:29:46 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:46 --> Input Class Initialized
INFO - 2017-02-03 23:29:46 --> Language Class Initialized
ERROR - 2017-02-03 23:29:46 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:29:48 --> Config Class Initialized
INFO - 2017-02-03 23:29:48 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:48 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:48 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:48 --> URI Class Initialized
DEBUG - 2017-02-03 23:29:48 --> No URI present. Default controller set.
INFO - 2017-02-03 23:29:48 --> Router Class Initialized
INFO - 2017-02-03 23:29:48 --> Output Class Initialized
INFO - 2017-02-03 23:29:48 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:48 --> Input Class Initialized
INFO - 2017-02-03 23:29:48 --> Language Class Initialized
INFO - 2017-02-03 23:29:48 --> Language Class Initialized
INFO - 2017-02-03 23:29:48 --> Config Class Initialized
INFO - 2017-02-03 23:29:48 --> Loader Class Initialized
INFO - 2017-02-03 23:29:48 --> Helper loaded: url_helper
INFO - 2017-02-03 23:29:48 --> Helper loaded: file_helper
INFO - 2017-02-03 23:29:48 --> Database Driver Class Initialized
INFO - 2017-02-03 23:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:29:48 --> Pagination Class Initialized
INFO - 2017-02-03 23:29:48 --> Model Class Initialized
INFO - 2017-02-03 23:29:48 --> Model Class Initialized
INFO - 2017-02-03 23:29:48 --> Controller Class Initialized
DEBUG - 2017-02-03 23:29:48 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:48 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 23:29:48 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 23:29:48 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:29:48 --> Final output sent to browser
DEBUG - 2017-02-03 23:29:48 --> Total execution time: 0.2629
INFO - 2017-02-03 23:29:49 --> Config Class Initialized
INFO - 2017-02-03 23:29:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:49 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:49 --> URI Class Initialized
DEBUG - 2017-02-03 23:29:49 --> No URI present. Default controller set.
INFO - 2017-02-03 23:29:49 --> Router Class Initialized
INFO - 2017-02-03 23:29:49 --> Output Class Initialized
INFO - 2017-02-03 23:29:49 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:49 --> Input Class Initialized
INFO - 2017-02-03 23:29:49 --> Language Class Initialized
INFO - 2017-02-03 23:29:49 --> Language Class Initialized
INFO - 2017-02-03 23:29:49 --> Config Class Initialized
INFO - 2017-02-03 23:29:49 --> Loader Class Initialized
INFO - 2017-02-03 23:29:49 --> Helper loaded: url_helper
INFO - 2017-02-03 23:29:49 --> Helper loaded: file_helper
INFO - 2017-02-03 23:29:49 --> Database Driver Class Initialized
INFO - 2017-02-03 23:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:29:49 --> Pagination Class Initialized
INFO - 2017-02-03 23:29:49 --> Model Class Initialized
INFO - 2017-02-03 23:29:49 --> Model Class Initialized
INFO - 2017-02-03 23:29:49 --> Controller Class Initialized
DEBUG - 2017-02-03 23:29:49 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:29:49 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 23:29:49 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 23:29:49 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:29:49 --> Final output sent to browser
DEBUG - 2017-02-03 23:29:49 --> Total execution time: 0.0620
INFO - 2017-02-03 23:29:49 --> Config Class Initialized
INFO - 2017-02-03 23:29:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:49 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:49 --> URI Class Initialized
INFO - 2017-02-03 23:29:49 --> Router Class Initialized
INFO - 2017-02-03 23:29:49 --> Output Class Initialized
INFO - 2017-02-03 23:29:49 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:49 --> Input Class Initialized
INFO - 2017-02-03 23:29:49 --> Language Class Initialized
ERROR - 2017-02-03 23:29:49 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:29:49 --> Config Class Initialized
INFO - 2017-02-03 23:29:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:49 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:49 --> URI Class Initialized
INFO - 2017-02-03 23:29:49 --> Router Class Initialized
INFO - 2017-02-03 23:29:49 --> Output Class Initialized
INFO - 2017-02-03 23:29:49 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:49 --> Input Class Initialized
INFO - 2017-02-03 23:29:49 --> Language Class Initialized
ERROR - 2017-02-03 23:29:49 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:29:49 --> Config Class Initialized
INFO - 2017-02-03 23:29:49 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:29:49 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:29:49 --> Utf8 Class Initialized
INFO - 2017-02-03 23:29:49 --> URI Class Initialized
INFO - 2017-02-03 23:29:49 --> Router Class Initialized
INFO - 2017-02-03 23:29:49 --> Output Class Initialized
INFO - 2017-02-03 23:29:49 --> Security Class Initialized
DEBUG - 2017-02-03 23:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:29:49 --> Input Class Initialized
INFO - 2017-02-03 23:29:49 --> Language Class Initialized
ERROR - 2017-02-03 23:29:49 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:00 --> Config Class Initialized
INFO - 2017-02-03 23:30:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:00 --> URI Class Initialized
INFO - 2017-02-03 23:30:00 --> Router Class Initialized
INFO - 2017-02-03 23:30:00 --> Output Class Initialized
INFO - 2017-02-03 23:30:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:00 --> Input Class Initialized
INFO - 2017-02-03 23:30:00 --> Language Class Initialized
ERROR - 2017-02-03 23:30:00 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:04 --> Config Class Initialized
INFO - 2017-02-03 23:30:04 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:04 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:04 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:04 --> URI Class Initialized
INFO - 2017-02-03 23:30:04 --> Router Class Initialized
INFO - 2017-02-03 23:30:04 --> Output Class Initialized
INFO - 2017-02-03 23:30:04 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:04 --> Input Class Initialized
INFO - 2017-02-03 23:30:04 --> Language Class Initialized
ERROR - 2017-02-03 23:30:04 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:14 --> Config Class Initialized
INFO - 2017-02-03 23:30:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:14 --> URI Class Initialized
INFO - 2017-02-03 23:30:14 --> Router Class Initialized
INFO - 2017-02-03 23:30:14 --> Output Class Initialized
INFO - 2017-02-03 23:30:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:14 --> Input Class Initialized
INFO - 2017-02-03 23:30:14 --> Language Class Initialized
ERROR - 2017-02-03 23:30:14 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:18 --> Config Class Initialized
INFO - 2017-02-03 23:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:18 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:18 --> URI Class Initialized
DEBUG - 2017-02-03 23:30:18 --> No URI present. Default controller set.
INFO - 2017-02-03 23:30:18 --> Router Class Initialized
INFO - 2017-02-03 23:30:18 --> Output Class Initialized
INFO - 2017-02-03 23:30:18 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:18 --> Input Class Initialized
INFO - 2017-02-03 23:30:18 --> Language Class Initialized
INFO - 2017-02-03 23:30:18 --> Language Class Initialized
INFO - 2017-02-03 23:30:18 --> Config Class Initialized
INFO - 2017-02-03 23:30:18 --> Loader Class Initialized
INFO - 2017-02-03 23:30:18 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:18 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:18 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:18 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:18 --> Model Class Initialized
INFO - 2017-02-03 23:30:18 --> Model Class Initialized
INFO - 2017-02-03 23:30:18 --> Controller Class Initialized
DEBUG - 2017-02-03 23:30:18 --> Welcome MX_Controller Initialized
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-03 23:30:18 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-03 23:30:18 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-03 23:30:18 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:30:18 --> Final output sent to browser
DEBUG - 2017-02-03 23:30:18 --> Total execution time: 0.0800
INFO - 2017-02-03 23:30:18 --> Config Class Initialized
INFO - 2017-02-03 23:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:18 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:18 --> URI Class Initialized
INFO - 2017-02-03 23:30:18 --> Router Class Initialized
INFO - 2017-02-03 23:30:18 --> Output Class Initialized
INFO - 2017-02-03 23:30:18 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:18 --> Input Class Initialized
INFO - 2017-02-03 23:30:18 --> Language Class Initialized
ERROR - 2017-02-03 23:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:18 --> Config Class Initialized
INFO - 2017-02-03 23:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:18 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:18 --> URI Class Initialized
INFO - 2017-02-03 23:30:18 --> Router Class Initialized
INFO - 2017-02-03 23:30:18 --> Output Class Initialized
INFO - 2017-02-03 23:30:18 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:18 --> Input Class Initialized
INFO - 2017-02-03 23:30:18 --> Language Class Initialized
ERROR - 2017-02-03 23:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:18 --> Config Class Initialized
INFO - 2017-02-03 23:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:18 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:18 --> URI Class Initialized
INFO - 2017-02-03 23:30:18 --> Router Class Initialized
INFO - 2017-02-03 23:30:18 --> Output Class Initialized
INFO - 2017-02-03 23:30:18 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:18 --> Input Class Initialized
INFO - 2017-02-03 23:30:18 --> Language Class Initialized
ERROR - 2017-02-03 23:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:18 --> Config Class Initialized
INFO - 2017-02-03 23:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:18 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:18 --> URI Class Initialized
INFO - 2017-02-03 23:30:18 --> Router Class Initialized
INFO - 2017-02-03 23:30:18 --> Output Class Initialized
INFO - 2017-02-03 23:30:18 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:18 --> Input Class Initialized
INFO - 2017-02-03 23:30:18 --> Language Class Initialized
ERROR - 2017-02-03 23:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:19 --> Config Class Initialized
INFO - 2017-02-03 23:30:19 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:19 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:19 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:19 --> URI Class Initialized
INFO - 2017-02-03 23:30:19 --> Router Class Initialized
INFO - 2017-02-03 23:30:19 --> Output Class Initialized
INFO - 2017-02-03 23:30:19 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:19 --> Input Class Initialized
INFO - 2017-02-03 23:30:19 --> Language Class Initialized
ERROR - 2017-02-03 23:30:19 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:25 --> Config Class Initialized
INFO - 2017-02-03 23:30:25 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:25 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:25 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:25 --> URI Class Initialized
INFO - 2017-02-03 23:30:25 --> Router Class Initialized
INFO - 2017-02-03 23:30:25 --> Output Class Initialized
INFO - 2017-02-03 23:30:25 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:25 --> Input Class Initialized
INFO - 2017-02-03 23:30:25 --> Language Class Initialized
INFO - 2017-02-03 23:30:25 --> Language Class Initialized
INFO - 2017-02-03 23:30:25 --> Config Class Initialized
INFO - 2017-02-03 23:30:25 --> Loader Class Initialized
INFO - 2017-02-03 23:30:25 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:25 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:25 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:25 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:25 --> Model Class Initialized
INFO - 2017-02-03 23:30:25 --> Model Class Initialized
INFO - 2017-02-03 23:30:25 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:25 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:30:29 --> Config Class Initialized
INFO - 2017-02-03 23:30:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:29 --> URI Class Initialized
INFO - 2017-02-03 23:30:29 --> Router Class Initialized
INFO - 2017-02-03 23:30:29 --> Output Class Initialized
INFO - 2017-02-03 23:30:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:29 --> Input Class Initialized
INFO - 2017-02-03 23:30:29 --> Language Class Initialized
INFO - 2017-02-03 23:30:29 --> Language Class Initialized
INFO - 2017-02-03 23:30:29 --> Config Class Initialized
INFO - 2017-02-03 23:30:29 --> Loader Class Initialized
INFO - 2017-02-03 23:30:29 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:29 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:29 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:29 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:29 --> Model Class Initialized
INFO - 2017-02-03 23:30:29 --> Model Class Initialized
INFO - 2017-02-03 23:30:29 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:29 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:30:29 --> Config Class Initialized
INFO - 2017-02-03 23:30:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:29 --> URI Class Initialized
INFO - 2017-02-03 23:30:29 --> Router Class Initialized
INFO - 2017-02-03 23:30:29 --> Output Class Initialized
INFO - 2017-02-03 23:30:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:29 --> Input Class Initialized
INFO - 2017-02-03 23:30:29 --> Language Class Initialized
INFO - 2017-02-03 23:30:29 --> Language Class Initialized
INFO - 2017-02-03 23:30:29 --> Config Class Initialized
INFO - 2017-02-03 23:30:29 --> Loader Class Initialized
INFO - 2017-02-03 23:30:29 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:29 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:29 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:29 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:29 --> Model Class Initialized
INFO - 2017-02-03 23:30:29 --> Model Class Initialized
INFO - 2017-02-03 23:30:29 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:29 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:30:39 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 15
DEBUG - 2017-02-03 23:30:39 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:30:39 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:30:39 --> Final output sent to browser
DEBUG - 2017-02-03 23:30:39 --> Total execution time: 0.0928
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Loader Class Initialized
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:30:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:30:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Model Class Initialized
INFO - 2017-02-03 23:30:39 --> Controller Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:30:39 --> Config Class Initialized
INFO - 2017-02-03 23:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:30:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:30:39 --> URI Class Initialized
INFO - 2017-02-03 23:30:39 --> Router Class Initialized
INFO - 2017-02-03 23:30:39 --> Output Class Initialized
INFO - 2017-02-03 23:30:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:30:39 --> Input Class Initialized
INFO - 2017-02-03 23:30:39 --> Language Class Initialized
ERROR - 2017-02-03 23:30:39 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:31:00 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 15
DEBUG - 2017-02-03 23:31:00 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:31:00 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:31:00 --> Final output sent to browser
DEBUG - 2017-02-03 23:31:00 --> Total execution time: 0.0233
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Loader Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:00 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
INFO - 2017-02-03 23:31:00 --> Pagination Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Model Class Initialized
INFO - 2017-02-03 23:31:00 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:00 --> Config Class Initialized
INFO - 2017-02-03 23:31:00 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:00 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:00 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:00 --> URI Class Initialized
INFO - 2017-02-03 23:31:00 --> Router Class Initialized
INFO - 2017-02-03 23:31:00 --> Output Class Initialized
INFO - 2017-02-03 23:31:00 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:00 --> Input Class Initialized
INFO - 2017-02-03 23:31:00 --> Language Class Initialized
ERROR - 2017-02-03 23:31:00 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:31:06 --> Config Class Initialized
INFO - 2017-02-03 23:31:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:06 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:06 --> URI Class Initialized
INFO - 2017-02-03 23:31:06 --> Router Class Initialized
INFO - 2017-02-03 23:31:06 --> Output Class Initialized
INFO - 2017-02-03 23:31:06 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:06 --> Input Class Initialized
INFO - 2017-02-03 23:31:06 --> Language Class Initialized
ERROR - 2017-02-03 23:31:06 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:31:13 --> Config Class Initialized
INFO - 2017-02-03 23:31:13 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:13 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:13 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:13 --> URI Class Initialized
INFO - 2017-02-03 23:31:13 --> Router Class Initialized
INFO - 2017-02-03 23:31:13 --> Output Class Initialized
INFO - 2017-02-03 23:31:13 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:13 --> Input Class Initialized
INFO - 2017-02-03 23:31:13 --> Language Class Initialized
INFO - 2017-02-03 23:31:13 --> Language Class Initialized
INFO - 2017-02-03 23:31:13 --> Config Class Initialized
INFO - 2017-02-03 23:31:13 --> Loader Class Initialized
INFO - 2017-02-03 23:31:13 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:13 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:13 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:13 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:13 --> Model Class Initialized
INFO - 2017-02-03 23:31:13 --> Model Class Initialized
INFO - 2017-02-03 23:31:13 --> Controller Class Initialized
DEBUG - 2017-02-03 23:31:13 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:31:13 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 15
DEBUG - 2017-02-03 23:31:14 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:31:14 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:31:14 --> Final output sent to browser
DEBUG - 2017-02-03 23:31:14 --> Total execution time: 0.3268
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/images
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Loader Class Initialized
INFO - 2017-02-03 23:31:14 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:14 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:14 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:14 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Model Class Initialized
INFO - 2017-02-03 23:31:14 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:31:14 --> Config Class Initialized
INFO - 2017-02-03 23:31:14 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:14 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:14 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:14 --> URI Class Initialized
INFO - 2017-02-03 23:31:14 --> Router Class Initialized
INFO - 2017-02-03 23:31:14 --> Output Class Initialized
INFO - 2017-02-03 23:31:14 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:14 --> Input Class Initialized
INFO - 2017-02-03 23:31:14 --> Language Class Initialized
ERROR - 2017-02-03 23:31:14 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:31:21 --> Config Class Initialized
INFO - 2017-02-03 23:31:21 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:31:21 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:31:21 --> Utf8 Class Initialized
INFO - 2017-02-03 23:31:21 --> URI Class Initialized
INFO - 2017-02-03 23:31:21 --> Router Class Initialized
INFO - 2017-02-03 23:31:21 --> Output Class Initialized
INFO - 2017-02-03 23:31:21 --> Security Class Initialized
DEBUG - 2017-02-03 23:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:31:21 --> Input Class Initialized
INFO - 2017-02-03 23:31:21 --> Language Class Initialized
INFO - 2017-02-03 23:31:21 --> Language Class Initialized
INFO - 2017-02-03 23:31:21 --> Config Class Initialized
INFO - 2017-02-03 23:31:21 --> Loader Class Initialized
INFO - 2017-02-03 23:31:21 --> Helper loaded: url_helper
INFO - 2017-02-03 23:31:21 --> Helper loaded: file_helper
INFO - 2017-02-03 23:31:21 --> Database Driver Class Initialized
INFO - 2017-02-03 23:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:31:21 --> Pagination Class Initialized
INFO - 2017-02-03 23:31:21 --> Model Class Initialized
INFO - 2017-02-03 23:31:21 --> Model Class Initialized
INFO - 2017-02-03 23:31:21 --> Controller Class Initialized
ERROR - 2017-02-03 23:31:21 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/view
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:01 --> URI Class Initialized
INFO - 2017-02-03 23:32:01 --> Router Class Initialized
INFO - 2017-02-03 23:32:01 --> Output Class Initialized
INFO - 2017-02-03 23:32:01 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:01 --> Input Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Loader Class Initialized
INFO - 2017-02-03 23:32:01 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:01 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:01 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:01 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:32:01 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 54
DEBUG - 2017-02-03 23:32:01 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:01 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:01 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:01 --> URI Class Initialized
INFO - 2017-02-03 23:32:01 --> Router Class Initialized
INFO - 2017-02-03 23:32:01 --> Output Class Initialized
INFO - 2017-02-03 23:32:01 --> Security Class Initialized
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:01 --> Hooks Class Initialized
INFO - 2017-02-03 23:32:01 --> Input Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
DEBUG - 2017-02-03 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:01 --> URI Class Initialized
INFO - 2017-02-03 23:32:01 --> Router Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Output Class Initialized
INFO - 2017-02-03 23:32:01 --> Security Class Initialized
INFO - 2017-02-03 23:32:01 --> Loader Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:01 --> Input Class Initialized
INFO - 2017-02-03 23:32:01 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Loader Class Initialized
INFO - 2017-02-03 23:32:01 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:01 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:01 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:01 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:01 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Controller Class Initialized
ERROR - 2017-02-03 23:32:01 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:01 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Controller Class Initialized
ERROR - 2017-02-03 23:32:01 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:01 --> URI Class Initialized
INFO - 2017-02-03 23:32:01 --> Router Class Initialized
INFO - 2017-02-03 23:32:01 --> Output Class Initialized
INFO - 2017-02-03 23:32:01 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:01 --> Input Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
ERROR - 2017-02-03 23:32:01 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:01 --> URI Class Initialized
INFO - 2017-02-03 23:32:01 --> Router Class Initialized
INFO - 2017-02-03 23:32:01 --> Output Class Initialized
INFO - 2017-02-03 23:32:01 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:01 --> Input Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
ERROR - 2017-02-03 23:32:01 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:01 --> URI Class Initialized
INFO - 2017-02-03 23:32:01 --> Router Class Initialized
INFO - 2017-02-03 23:32:01 --> Output Class Initialized
INFO - 2017-02-03 23:32:01 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:01 --> Input Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Loader Class Initialized
INFO - 2017-02-03 23:32:01 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:01 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:01 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:01 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:01 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:01 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:01 --> URI Class Initialized
INFO - 2017-02-03 23:32:01 --> Router Class Initialized
INFO - 2017-02-03 23:32:01 --> Output Class Initialized
INFO - 2017-02-03 23:32:01 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:01 --> Input Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Language Class Initialized
INFO - 2017-02-03 23:32:01 --> Config Class Initialized
INFO - 2017-02-03 23:32:01 --> Loader Class Initialized
INFO - 2017-02-03 23:32:01 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:01 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:01 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Controller Class Initialized
INFO - 2017-02-03 23:32:01 --> Language file loaded: language/english/pagination_lang.php
ERROR - 2017-02-03 23:32:01 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:32:01 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Model Class Initialized
INFO - 2017-02-03 23:32:01 --> Controller Class Initialized
ERROR - 2017-02-03 23:32:01 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/iklan
INFO - 2017-02-03 23:32:10 --> Config Class Initialized
INFO - 2017-02-03 23:32:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:10 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:10 --> URI Class Initialized
INFO - 2017-02-03 23:32:10 --> Router Class Initialized
INFO - 2017-02-03 23:32:10 --> Output Class Initialized
INFO - 2017-02-03 23:32:10 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:10 --> Input Class Initialized
INFO - 2017-02-03 23:32:10 --> Language Class Initialized
INFO - 2017-02-03 23:32:10 --> Language Class Initialized
INFO - 2017-02-03 23:32:10 --> Config Class Initialized
INFO - 2017-02-03 23:32:10 --> Loader Class Initialized
INFO - 2017-02-03 23:32:10 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:10 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:10 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:10 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:10 --> Model Class Initialized
INFO - 2017-02-03 23:32:10 --> Model Class Initialized
INFO - 2017-02-03 23:32:10 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:10 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:32:10 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 54
DEBUG - 2017-02-03 23:32:10 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:10 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:10 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:10 --> Config Class Initialized
INFO - 2017-02-03 23:32:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:10 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:10 --> URI Class Initialized
INFO - 2017-02-03 23:32:10 --> Router Class Initialized
INFO - 2017-02-03 23:32:10 --> Output Class Initialized
INFO - 2017-02-03 23:32:10 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:10 --> Input Class Initialized
INFO - 2017-02-03 23:32:10 --> Language Class Initialized
INFO - 2017-02-03 23:32:10 --> Language Class Initialized
INFO - 2017-02-03 23:32:10 --> Config Class Initialized
INFO - 2017-02-03 23:32:10 --> Loader Class Initialized
INFO - 2017-02-03 23:32:10 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:10 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:10 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:10 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:10 --> Model Class Initialized
INFO - 2017-02-03 23:32:10 --> Model Class Initialized
INFO - 2017-02-03 23:32:10 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:10 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:32:10 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 54
DEBUG - 2017-02-03 23:32:10 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:10 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:10 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:10 --> Config Class Initialized
INFO - 2017-02-03 23:32:10 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:10 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:10 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:10 --> URI Class Initialized
INFO - 2017-02-03 23:32:10 --> Router Class Initialized
INFO - 2017-02-03 23:32:10 --> Output Class Initialized
INFO - 2017-02-03 23:32:10 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:10 --> Input Class Initialized
INFO - 2017-02-03 23:32:10 --> Language Class Initialized
INFO - 2017-02-03 23:32:10 --> Language Class Initialized
INFO - 2017-02-03 23:32:10 --> Config Class Initialized
INFO - 2017-02-03 23:32:10 --> Loader Class Initialized
INFO - 2017-02-03 23:32:10 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:10 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:10 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:10 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:10 --> Model Class Initialized
INFO - 2017-02-03 23:32:10 --> Model Class Initialized
INFO - 2017-02-03 23:32:10 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:10 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:32:10 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 54
DEBUG - 2017-02-03 23:32:10 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:10 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:10 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:11 --> Config Class Initialized
INFO - 2017-02-03 23:32:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:11 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:11 --> URI Class Initialized
INFO - 2017-02-03 23:32:11 --> Router Class Initialized
INFO - 2017-02-03 23:32:11 --> Output Class Initialized
INFO - 2017-02-03 23:32:11 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:11 --> Input Class Initialized
INFO - 2017-02-03 23:32:11 --> Language Class Initialized
ERROR - 2017-02-03 23:32:11 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:32:11 --> Config Class Initialized
INFO - 2017-02-03 23:32:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:11 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:11 --> URI Class Initialized
INFO - 2017-02-03 23:32:11 --> Router Class Initialized
INFO - 2017-02-03 23:32:11 --> Output Class Initialized
INFO - 2017-02-03 23:32:11 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:11 --> Input Class Initialized
INFO - 2017-02-03 23:32:11 --> Language Class Initialized
ERROR - 2017-02-03 23:32:11 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:32:11 --> Config Class Initialized
INFO - 2017-02-03 23:32:11 --> Config Class Initialized
INFO - 2017-02-03 23:32:11 --> Hooks Class Initialized
INFO - 2017-02-03 23:32:11 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:11 --> UTF-8 Support Enabled
DEBUG - 2017-02-03 23:32:11 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:11 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:11 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:11 --> URI Class Initialized
INFO - 2017-02-03 23:32:11 --> URI Class Initialized
INFO - 2017-02-03 23:32:11 --> Router Class Initialized
INFO - 2017-02-03 23:32:11 --> Router Class Initialized
INFO - 2017-02-03 23:32:11 --> Output Class Initialized
INFO - 2017-02-03 23:32:11 --> Output Class Initialized
INFO - 2017-02-03 23:32:11 --> Security Class Initialized
INFO - 2017-02-03 23:32:11 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-03 23:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:11 --> Input Class Initialized
INFO - 2017-02-03 23:32:11 --> Input Class Initialized
INFO - 2017-02-03 23:32:11 --> Language Class Initialized
INFO - 2017-02-03 23:32:11 --> Language Class Initialized
INFO - 2017-02-03 23:32:11 --> Language Class Initialized
INFO - 2017-02-03 23:32:11 --> Language Class Initialized
INFO - 2017-02-03 23:32:11 --> Config Class Initialized
INFO - 2017-02-03 23:32:11 --> Config Class Initialized
INFO - 2017-02-03 23:32:11 --> Loader Class Initialized
INFO - 2017-02-03 23:32:11 --> Loader Class Initialized
INFO - 2017-02-03 23:32:11 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:11 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:11 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:11 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:11 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:11 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:11 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:11 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:11 --> Model Class Initialized
INFO - 2017-02-03 23:32:11 --> Model Class Initialized
INFO - 2017-02-03 23:32:11 --> Model Class Initialized
INFO - 2017-02-03 23:32:11 --> Model Class Initialized
INFO - 2017-02-03 23:32:11 --> Controller Class Initialized
INFO - 2017-02-03 23:32:11 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:11 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:32:11 --> Kategori MX_Controller Initialized
ERROR - 2017-02-03 23:32:11 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 54
ERROR - 2017-02-03 23:32:11 --> Severity: Notice --> Undefined variable: kat /var/www/html/wartabandung/application/modules/kategori/controllers/Kategori.php 54
DEBUG - 2017-02-03 23:32:11 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:11 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:11 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
DEBUG - 2017-02-03 23:32:11 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:11 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:11 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:38 --> Config Class Initialized
INFO - 2017-02-03 23:32:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:38 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:38 --> URI Class Initialized
INFO - 2017-02-03 23:32:38 --> Router Class Initialized
INFO - 2017-02-03 23:32:38 --> Output Class Initialized
INFO - 2017-02-03 23:32:38 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:38 --> Input Class Initialized
INFO - 2017-02-03 23:32:38 --> Language Class Initialized
INFO - 2017-02-03 23:32:38 --> Language Class Initialized
INFO - 2017-02-03 23:32:38 --> Config Class Initialized
INFO - 2017-02-03 23:32:38 --> Loader Class Initialized
INFO - 2017-02-03 23:32:38 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:38 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:38 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:38 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:38 --> Model Class Initialized
INFO - 2017-02-03 23:32:38 --> Model Class Initialized
INFO - 2017-02-03 23:32:38 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:38 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:32:38 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:38 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:38 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:38 --> Config Class Initialized
INFO - 2017-02-03 23:32:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:38 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:38 --> URI Class Initialized
INFO - 2017-02-03 23:32:38 --> Router Class Initialized
INFO - 2017-02-03 23:32:38 --> Output Class Initialized
INFO - 2017-02-03 23:32:38 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:38 --> Input Class Initialized
INFO - 2017-02-03 23:32:38 --> Language Class Initialized
INFO - 2017-02-03 23:32:38 --> Language Class Initialized
INFO - 2017-02-03 23:32:38 --> Config Class Initialized
INFO - 2017-02-03 23:32:38 --> Loader Class Initialized
INFO - 2017-02-03 23:32:38 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:38 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:38 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:38 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:38 --> Model Class Initialized
INFO - 2017-02-03 23:32:38 --> Model Class Initialized
INFO - 2017-02-03 23:32:38 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:38 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:32:38 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:38 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:38 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:38 --> Config Class Initialized
INFO - 2017-02-03 23:32:38 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:38 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:38 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:38 --> URI Class Initialized
INFO - 2017-02-03 23:32:38 --> Router Class Initialized
INFO - 2017-02-03 23:32:38 --> Output Class Initialized
INFO - 2017-02-03 23:32:38 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:38 --> Input Class Initialized
INFO - 2017-02-03 23:32:38 --> Language Class Initialized
INFO - 2017-02-03 23:32:38 --> Language Class Initialized
INFO - 2017-02-03 23:32:38 --> Config Class Initialized
INFO - 2017-02-03 23:32:38 --> Loader Class Initialized
INFO - 2017-02-03 23:32:38 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:38 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:38 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:38 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:38 --> Model Class Initialized
INFO - 2017-02-03 23:32:38 --> Model Class Initialized
INFO - 2017-02-03 23:32:38 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:38 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:32:38 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:38 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:38 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:39 --> Config Class Initialized
INFO - 2017-02-03 23:32:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:39 --> URI Class Initialized
INFO - 2017-02-03 23:32:39 --> Router Class Initialized
INFO - 2017-02-03 23:32:39 --> Output Class Initialized
INFO - 2017-02-03 23:32:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:39 --> Input Class Initialized
INFO - 2017-02-03 23:32:39 --> Language Class Initialized
ERROR - 2017-02-03 23:32:39 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:32:39 --> Config Class Initialized
INFO - 2017-02-03 23:32:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:39 --> URI Class Initialized
INFO - 2017-02-03 23:32:39 --> Router Class Initialized
INFO - 2017-02-03 23:32:39 --> Output Class Initialized
INFO - 2017-02-03 23:32:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:39 --> Input Class Initialized
INFO - 2017-02-03 23:32:39 --> Language Class Initialized
INFO - 2017-02-03 23:32:39 --> Language Class Initialized
INFO - 2017-02-03 23:32:39 --> Config Class Initialized
INFO - 2017-02-03 23:32:39 --> Loader Class Initialized
INFO - 2017-02-03 23:32:39 --> Helper loaded: url_helper
INFO - 2017-02-03 23:32:39 --> Helper loaded: file_helper
INFO - 2017-02-03 23:32:39 --> Database Driver Class Initialized
INFO - 2017-02-03 23:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:32:39 --> Pagination Class Initialized
INFO - 2017-02-03 23:32:39 --> Model Class Initialized
INFO - 2017-02-03 23:32:39 --> Model Class Initialized
INFO - 2017-02-03 23:32:39 --> Controller Class Initialized
DEBUG - 2017-02-03 23:32:39 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:32:39 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:32:39 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:32:39 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:32:39 --> Config Class Initialized
INFO - 2017-02-03 23:32:39 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:32:39 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:32:39 --> Utf8 Class Initialized
INFO - 2017-02-03 23:32:39 --> URI Class Initialized
INFO - 2017-02-03 23:32:39 --> Router Class Initialized
INFO - 2017-02-03 23:32:39 --> Output Class Initialized
INFO - 2017-02-03 23:32:39 --> Security Class Initialized
DEBUG - 2017-02-03 23:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:32:39 --> Input Class Initialized
INFO - 2017-02-03 23:32:39 --> Language Class Initialized
ERROR - 2017-02-03 23:32:39 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:09 --> URI Class Initialized
INFO - 2017-02-03 23:33:09 --> Router Class Initialized
INFO - 2017-02-03 23:33:09 --> Output Class Initialized
INFO - 2017-02-03 23:33:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:09 --> Input Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Loader Class Initialized
INFO - 2017-02-03 23:33:09 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:09 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:09 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:09 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:09 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:09 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:09 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:09 --> URI Class Initialized
INFO - 2017-02-03 23:33:09 --> Router Class Initialized
INFO - 2017-02-03 23:33:09 --> Output Class Initialized
INFO - 2017-02-03 23:33:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:09 --> Input Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Loader Class Initialized
INFO - 2017-02-03 23:33:09 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:09 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:09 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:09 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:09 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:09 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:09 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:09 --> URI Class Initialized
INFO - 2017-02-03 23:33:09 --> Router Class Initialized
INFO - 2017-02-03 23:33:09 --> Output Class Initialized
INFO - 2017-02-03 23:33:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:09 --> Input Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Loader Class Initialized
INFO - 2017-02-03 23:33:09 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:09 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:09 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:09 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:09 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:09 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:09 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:09 --> URI Class Initialized
INFO - 2017-02-03 23:33:09 --> Router Class Initialized
INFO - 2017-02-03 23:33:09 --> Output Class Initialized
INFO - 2017-02-03 23:33:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:09 --> Input Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
ERROR - 2017-02-03 23:33:09 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:09 --> URI Class Initialized
INFO - 2017-02-03 23:33:09 --> Router Class Initialized
INFO - 2017-02-03 23:33:09 --> Output Class Initialized
INFO - 2017-02-03 23:33:09 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:09 --> Input Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
ERROR - 2017-02-03 23:33:09 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:09 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:09 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:09 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:09 --> URI Class Initialized
INFO - 2017-02-03 23:33:09 --> URI Class Initialized
INFO - 2017-02-03 23:33:09 --> Router Class Initialized
INFO - 2017-02-03 23:33:09 --> Router Class Initialized
INFO - 2017-02-03 23:33:09 --> Output Class Initialized
INFO - 2017-02-03 23:33:09 --> Security Class Initialized
INFO - 2017-02-03 23:33:09 --> Output Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:09 --> Input Class Initialized
INFO - 2017-02-03 23:33:09 --> Security Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Input Class Initialized
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Loader Class Initialized
INFO - 2017-02-03 23:33:09 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:09 --> Language Class Initialized
INFO - 2017-02-03 23:33:09 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:09 --> Config Class Initialized
INFO - 2017-02-03 23:33:09 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:09 --> Loader Class Initialized
INFO - 2017-02-03 23:33:09 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:09 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:09 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:09 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:09 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Model Class Initialized
INFO - 2017-02-03 23:33:09 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:09 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:09 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:09 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:09 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
DEBUG - 2017-02-03 23:33:09 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:09 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:09 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:28 --> Config Class Initialized
INFO - 2017-02-03 23:33:28 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:28 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:28 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:28 --> URI Class Initialized
INFO - 2017-02-03 23:33:28 --> Router Class Initialized
INFO - 2017-02-03 23:33:28 --> Output Class Initialized
INFO - 2017-02-03 23:33:28 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:28 --> Input Class Initialized
INFO - 2017-02-03 23:33:28 --> Language Class Initialized
INFO - 2017-02-03 23:33:28 --> Language Class Initialized
INFO - 2017-02-03 23:33:28 --> Config Class Initialized
INFO - 2017-02-03 23:33:28 --> Loader Class Initialized
INFO - 2017-02-03 23:33:28 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:28 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:28 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:28 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:28 --> Model Class Initialized
INFO - 2017-02-03 23:33:28 --> Model Class Initialized
INFO - 2017-02-03 23:33:28 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:28 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:28 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:28 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:28 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:29 --> URI Class Initialized
INFO - 2017-02-03 23:33:29 --> Router Class Initialized
INFO - 2017-02-03 23:33:29 --> Output Class Initialized
INFO - 2017-02-03 23:33:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:29 --> Input Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Loader Class Initialized
INFO - 2017-02-03 23:33:29 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:29 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:29 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:29 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:29 --> Model Class Initialized
INFO - 2017-02-03 23:33:29 --> Model Class Initialized
INFO - 2017-02-03 23:33:29 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:29 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:29 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:29 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:29 --> URI Class Initialized
INFO - 2017-02-03 23:33:29 --> Router Class Initialized
INFO - 2017-02-03 23:33:29 --> Output Class Initialized
INFO - 2017-02-03 23:33:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:29 --> Input Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Loader Class Initialized
INFO - 2017-02-03 23:33:29 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:29 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:29 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:29 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:29 --> Model Class Initialized
INFO - 2017-02-03 23:33:29 --> Model Class Initialized
INFO - 2017-02-03 23:33:29 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:29 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:29 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:29 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:29 --> URI Class Initialized
INFO - 2017-02-03 23:33:29 --> Router Class Initialized
INFO - 2017-02-03 23:33:29 --> Output Class Initialized
INFO - 2017-02-03 23:33:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:29 --> Input Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
ERROR - 2017-02-03 23:33:29 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:29 --> URI Class Initialized
INFO - 2017-02-03 23:33:29 --> Router Class Initialized
INFO - 2017-02-03 23:33:29 --> Output Class Initialized
INFO - 2017-02-03 23:33:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:29 --> Input Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Loader Class Initialized
INFO - 2017-02-03 23:33:29 --> Helper loaded: url_helper
INFO - 2017-02-03 23:33:29 --> Helper loaded: file_helper
INFO - 2017-02-03 23:33:29 --> Database Driver Class Initialized
INFO - 2017-02-03 23:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:33:29 --> Pagination Class Initialized
INFO - 2017-02-03 23:33:29 --> Model Class Initialized
INFO - 2017-02-03 23:33:29 --> Model Class Initialized
INFO - 2017-02-03 23:33:29 --> Controller Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:33:29 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:33:29 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:33:29 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:33:29 --> Config Class Initialized
INFO - 2017-02-03 23:33:29 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:33:29 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:33:29 --> Utf8 Class Initialized
INFO - 2017-02-03 23:33:29 --> URI Class Initialized
INFO - 2017-02-03 23:33:29 --> Router Class Initialized
INFO - 2017-02-03 23:33:29 --> Output Class Initialized
INFO - 2017-02-03 23:33:29 --> Security Class Initialized
DEBUG - 2017-02-03 23:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:33:29 --> Input Class Initialized
INFO - 2017-02-03 23:33:29 --> Language Class Initialized
ERROR - 2017-02-03 23:33:29 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:34:06 --> Config Class Initialized
INFO - 2017-02-03 23:34:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:34:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:34:06 --> Utf8 Class Initialized
INFO - 2017-02-03 23:34:06 --> URI Class Initialized
INFO - 2017-02-03 23:34:06 --> Router Class Initialized
INFO - 2017-02-03 23:34:06 --> Output Class Initialized
INFO - 2017-02-03 23:34:06 --> Security Class Initialized
DEBUG - 2017-02-03 23:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:34:06 --> Input Class Initialized
INFO - 2017-02-03 23:34:06 --> Language Class Initialized
INFO - 2017-02-03 23:34:06 --> Language Class Initialized
INFO - 2017-02-03 23:34:06 --> Config Class Initialized
INFO - 2017-02-03 23:34:06 --> Loader Class Initialized
INFO - 2017-02-03 23:34:06 --> Helper loaded: url_helper
INFO - 2017-02-03 23:34:06 --> Helper loaded: file_helper
INFO - 2017-02-03 23:34:06 --> Database Driver Class Initialized
INFO - 2017-02-03 23:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:34:06 --> Pagination Class Initialized
INFO - 2017-02-03 23:34:06 --> Model Class Initialized
INFO - 2017-02-03 23:34:06 --> Model Class Initialized
INFO - 2017-02-03 23:34:06 --> Controller Class Initialized
DEBUG - 2017-02-03 23:34:06 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:34:06 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:34:06 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:34:06 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:34:06 --> Config Class Initialized
INFO - 2017-02-03 23:34:06 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:34:06 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:34:06 --> Utf8 Class Initialized
INFO - 2017-02-03 23:34:06 --> URI Class Initialized
INFO - 2017-02-03 23:34:06 --> Router Class Initialized
INFO - 2017-02-03 23:34:06 --> Output Class Initialized
INFO - 2017-02-03 23:34:06 --> Security Class Initialized
DEBUG - 2017-02-03 23:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:34:06 --> Input Class Initialized
INFO - 2017-02-03 23:34:06 --> Language Class Initialized
INFO - 2017-02-03 23:34:06 --> Language Class Initialized
INFO - 2017-02-03 23:34:06 --> Config Class Initialized
INFO - 2017-02-03 23:34:06 --> Loader Class Initialized
INFO - 2017-02-03 23:34:06 --> Helper loaded: url_helper
INFO - 2017-02-03 23:34:06 --> Helper loaded: file_helper
INFO - 2017-02-03 23:34:06 --> Database Driver Class Initialized
INFO - 2017-02-03 23:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:34:06 --> Pagination Class Initialized
INFO - 2017-02-03 23:34:06 --> Model Class Initialized
INFO - 2017-02-03 23:34:06 --> Model Class Initialized
INFO - 2017-02-03 23:34:06 --> Controller Class Initialized
DEBUG - 2017-02-03 23:34:06 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:34:06 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:34:06 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:34:06 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:34:07 --> Config Class Initialized
INFO - 2017-02-03 23:34:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:34:07 --> Utf8 Class Initialized
INFO - 2017-02-03 23:34:07 --> URI Class Initialized
INFO - 2017-02-03 23:34:07 --> Router Class Initialized
INFO - 2017-02-03 23:34:07 --> Output Class Initialized
INFO - 2017-02-03 23:34:07 --> Security Class Initialized
DEBUG - 2017-02-03 23:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:34:07 --> Input Class Initialized
INFO - 2017-02-03 23:34:07 --> Language Class Initialized
INFO - 2017-02-03 23:34:07 --> Language Class Initialized
INFO - 2017-02-03 23:34:07 --> Config Class Initialized
INFO - 2017-02-03 23:34:07 --> Loader Class Initialized
INFO - 2017-02-03 23:34:07 --> Helper loaded: url_helper
INFO - 2017-02-03 23:34:07 --> Helper loaded: file_helper
INFO - 2017-02-03 23:34:07 --> Database Driver Class Initialized
INFO - 2017-02-03 23:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:34:07 --> Pagination Class Initialized
INFO - 2017-02-03 23:34:07 --> Model Class Initialized
INFO - 2017-02-03 23:34:07 --> Model Class Initialized
INFO - 2017-02-03 23:34:07 --> Controller Class Initialized
DEBUG - 2017-02-03 23:34:07 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:34:07 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
ERROR - 2017-02-03 23:34:07 --> Severity: Notice --> Undefined variable: main /var/www/html/wartabandung/module/right-page.php 4
ERROR - 2017-02-03 23:34:07 --> Severity: Error --> Call to a member function loadIklan() on null /var/www/html/wartabandung/module/right-page.php 4
INFO - 2017-02-03 23:34:07 --> Config Class Initialized
INFO - 2017-02-03 23:34:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:34:07 --> Utf8 Class Initialized
INFO - 2017-02-03 23:34:07 --> URI Class Initialized
INFO - 2017-02-03 23:34:07 --> Router Class Initialized
INFO - 2017-02-03 23:34:07 --> Output Class Initialized
INFO - 2017-02-03 23:34:07 --> Security Class Initialized
DEBUG - 2017-02-03 23:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:34:07 --> Input Class Initialized
INFO - 2017-02-03 23:34:07 --> Language Class Initialized
ERROR - 2017-02-03 23:34:07 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:34:07 --> Config Class Initialized
INFO - 2017-02-03 23:34:07 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:34:07 --> Utf8 Class Initialized
INFO - 2017-02-03 23:34:07 --> URI Class Initialized
INFO - 2017-02-03 23:34:07 --> Router Class Initialized
INFO - 2017-02-03 23:34:07 --> Output Class Initialized
INFO - 2017-02-03 23:34:07 --> Security Class Initialized
DEBUG - 2017-02-03 23:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:34:07 --> Input Class Initialized
INFO - 2017-02-03 23:34:07 --> Language Class Initialized
ERROR - 2017-02-03 23:34:07 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0488
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0114
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0098
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0094
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0081
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0099
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0128
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0120
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0130
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Loader Class Initialized
INFO - 2017-02-03 23:35:52 --> Helper loaded: url_helper
INFO - 2017-02-03 23:35:52 --> Helper loaded: file_helper
INFO - 2017-02-03 23:35:52 --> Database Driver Class Initialized
INFO - 2017-02-03 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:35:52 --> Pagination Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Model Class Initialized
INFO - 2017-02-03 23:35:52 --> Controller Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:35:52 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:35:52 --> Final output sent to browser
DEBUG - 2017-02-03 23:35:52 --> Total execution time: 0.0108
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
ERROR - 2017-02-03 23:35:52 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:35:52 --> Config Class Initialized
INFO - 2017-02-03 23:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:35:52 --> Utf8 Class Initialized
INFO - 2017-02-03 23:35:52 --> URI Class Initialized
INFO - 2017-02-03 23:35:52 --> Router Class Initialized
INFO - 2017-02-03 23:35:52 --> Output Class Initialized
INFO - 2017-02-03 23:35:52 --> Security Class Initialized
DEBUG - 2017-02-03 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:35:52 --> Input Class Initialized
INFO - 2017-02-03 23:35:52 --> Language Class Initialized
ERROR - 2017-02-03 23:35:52 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:20 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:20 --> URI Class Initialized
INFO - 2017-02-03 23:38:20 --> Router Class Initialized
INFO - 2017-02-03 23:38:20 --> Output Class Initialized
INFO - 2017-02-03 23:38:20 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:20 --> Input Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Loader Class Initialized
INFO - 2017-02-03 23:38:20 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:20 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:20 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:20 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:20 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:20 --> Total execution time: 0.0486
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:20 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:20 --> URI Class Initialized
INFO - 2017-02-03 23:38:20 --> Router Class Initialized
INFO - 2017-02-03 23:38:20 --> Output Class Initialized
INFO - 2017-02-03 23:38:20 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:20 --> Input Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Loader Class Initialized
INFO - 2017-02-03 23:38:20 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:20 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:20 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:20 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:20 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:20 --> Total execution time: 0.0123
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:20 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:20 --> URI Class Initialized
INFO - 2017-02-03 23:38:20 --> Router Class Initialized
INFO - 2017-02-03 23:38:20 --> Output Class Initialized
INFO - 2017-02-03 23:38:20 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:20 --> Input Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Loader Class Initialized
INFO - 2017-02-03 23:38:20 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:20 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:20 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:20 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:20 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:20 --> Total execution time: 0.0100
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:20 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:20 --> URI Class Initialized
INFO - 2017-02-03 23:38:20 --> Router Class Initialized
INFO - 2017-02-03 23:38:20 --> Output Class Initialized
INFO - 2017-02-03 23:38:20 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:20 --> Input Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Loader Class Initialized
INFO - 2017-02-03 23:38:20 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:20 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:20 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:20 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:20 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:20 --> Total execution time: 0.0121
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:20 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:20 --> URI Class Initialized
INFO - 2017-02-03 23:38:20 --> Router Class Initialized
INFO - 2017-02-03 23:38:20 --> Output Class Initialized
INFO - 2017-02-03 23:38:20 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:20 --> Input Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Loader Class Initialized
INFO - 2017-02-03 23:38:20 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:20 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:20 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:20 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Model Class Initialized
INFO - 2017-02-03 23:38:20 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:20 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:20 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:20 --> Total execution time: 0.0090
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:20 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:20 --> URI Class Initialized
INFO - 2017-02-03 23:38:20 --> Router Class Initialized
INFO - 2017-02-03 23:38:20 --> Output Class Initialized
INFO - 2017-02-03 23:38:20 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:20 --> Input Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
ERROR - 2017-02-03 23:38:20 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:38:20 --> Config Class Initialized
INFO - 2017-02-03 23:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:20 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:20 --> URI Class Initialized
INFO - 2017-02-03 23:38:20 --> Router Class Initialized
INFO - 2017-02-03 23:38:20 --> Output Class Initialized
INFO - 2017-02-03 23:38:20 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:20 --> Input Class Initialized
INFO - 2017-02-03 23:38:20 --> Language Class Initialized
ERROR - 2017-02-03 23:38:20 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:38:55 --> Config Class Initialized
INFO - 2017-02-03 23:38:55 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:55 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:55 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:55 --> URI Class Initialized
INFO - 2017-02-03 23:38:55 --> Router Class Initialized
INFO - 2017-02-03 23:38:55 --> Output Class Initialized
INFO - 2017-02-03 23:38:55 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:55 --> Input Class Initialized
INFO - 2017-02-03 23:38:55 --> Language Class Initialized
INFO - 2017-02-03 23:38:55 --> Language Class Initialized
INFO - 2017-02-03 23:38:55 --> Config Class Initialized
INFO - 2017-02-03 23:38:55 --> Loader Class Initialized
INFO - 2017-02-03 23:38:55 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:55 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:55 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:55 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:55 --> Model Class Initialized
INFO - 2017-02-03 23:38:55 --> Model Class Initialized
INFO - 2017-02-03 23:38:55 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:55 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:55 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:55 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:55 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:55 --> Total execution time: 0.5375
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Loader Class Initialized
INFO - 2017-02-03 23:38:56 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:56 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:56 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:56 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:56 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:56 --> Total execution time: 0.0115
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Loader Class Initialized
INFO - 2017-02-03 23:38:56 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:56 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:56 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:56 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:56 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:56 --> Total execution time: 0.0110
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Loader Class Initialized
INFO - 2017-02-03 23:38:56 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:56 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:56 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:56 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:56 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:56 --> Total execution time: 0.0148
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Loader Class Initialized
INFO - 2017-02-03 23:38:56 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:56 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:56 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Controller Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
ERROR - 2017-02-03 23:38:56 --> 404 Page Not Found: /index
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:56 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:56 --> Total execution time: 0.0120
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
ERROR - 2017-02-03 23:38:56 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Loader Class Initialized
INFO - 2017-02-03 23:38:56 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:56 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:56 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Hooks Class Initialized
INFO - 2017-02-03 23:38:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2017-02-03 23:38:56 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:38:56 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:56 --> Utf8 Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> URI Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Controller Class Initialized
INFO - 2017-02-03 23:38:56 --> Router Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:38:56 --> Output Class Initialized
INFO - 2017-02-03 23:38:56 --> Security Class Initialized
DEBUG - 2017-02-03 23:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:38:56 --> Input Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Language Class Initialized
INFO - 2017-02-03 23:38:56 --> Config Class Initialized
INFO - 2017-02-03 23:38:56 --> Loader Class Initialized
INFO - 2017-02-03 23:38:56 --> Helper loaded: url_helper
INFO - 2017-02-03 23:38:56 --> Helper loaded: file_helper
INFO - 2017-02-03 23:38:56 --> Database Driver Class Initialized
INFO - 2017-02-03 23:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:38:56 --> Pagination Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Model Class Initialized
INFO - 2017-02-03 23:38:56 --> Controller Class Initialized
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:56 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:56 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:56 --> Total execution time: 0.0098
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:38:56 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:38:56 --> Final output sent to browser
DEBUG - 2017-02-03 23:38:56 --> Total execution time: 0.0100
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:39:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:39:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:39:23 --> URI Class Initialized
INFO - 2017-02-03 23:39:23 --> Router Class Initialized
INFO - 2017-02-03 23:39:23 --> Output Class Initialized
INFO - 2017-02-03 23:39:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:39:23 --> Input Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Loader Class Initialized
INFO - 2017-02-03 23:39:23 --> Helper loaded: url_helper
INFO - 2017-02-03 23:39:23 --> Helper loaded: file_helper
INFO - 2017-02-03 23:39:23 --> Database Driver Class Initialized
INFO - 2017-02-03 23:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:39:23 --> Pagination Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Controller Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:39:23 --> Final output sent to browser
DEBUG - 2017-02-03 23:39:23 --> Total execution time: 0.0418
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:39:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:39:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:39:23 --> URI Class Initialized
INFO - 2017-02-03 23:39:23 --> Router Class Initialized
INFO - 2017-02-03 23:39:23 --> Output Class Initialized
INFO - 2017-02-03 23:39:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:39:23 --> Input Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Loader Class Initialized
INFO - 2017-02-03 23:39:23 --> Helper loaded: url_helper
INFO - 2017-02-03 23:39:23 --> Helper loaded: file_helper
INFO - 2017-02-03 23:39:23 --> Database Driver Class Initialized
INFO - 2017-02-03 23:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:39:23 --> Pagination Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Controller Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:39:23 --> Final output sent to browser
DEBUG - 2017-02-03 23:39:23 --> Total execution time: 0.0189
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:39:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:39:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:39:23 --> URI Class Initialized
INFO - 2017-02-03 23:39:23 --> Router Class Initialized
INFO - 2017-02-03 23:39:23 --> Output Class Initialized
INFO - 2017-02-03 23:39:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:39:23 --> Input Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Loader Class Initialized
INFO - 2017-02-03 23:39:23 --> Helper loaded: url_helper
INFO - 2017-02-03 23:39:23 --> Helper loaded: file_helper
INFO - 2017-02-03 23:39:23 --> Database Driver Class Initialized
INFO - 2017-02-03 23:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:39:23 --> Pagination Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Controller Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:39:23 --> Final output sent to browser
DEBUG - 2017-02-03 23:39:23 --> Total execution time: 0.0102
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:39:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:39:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:39:23 --> URI Class Initialized
INFO - 2017-02-03 23:39:23 --> Router Class Initialized
INFO - 2017-02-03 23:39:23 --> Output Class Initialized
INFO - 2017-02-03 23:39:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:39:23 --> Input Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Loader Class Initialized
INFO - 2017-02-03 23:39:23 --> Helper loaded: url_helper
INFO - 2017-02-03 23:39:23 --> Helper loaded: file_helper
INFO - 2017-02-03 23:39:23 --> Database Driver Class Initialized
INFO - 2017-02-03 23:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:39:23 --> Pagination Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Controller Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:39:23 --> Final output sent to browser
DEBUG - 2017-02-03 23:39:23 --> Total execution time: 0.0225
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:39:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:39:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:39:23 --> URI Class Initialized
INFO - 2017-02-03 23:39:23 --> Router Class Initialized
INFO - 2017-02-03 23:39:23 --> Output Class Initialized
INFO - 2017-02-03 23:39:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:39:23 --> Input Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Loader Class Initialized
INFO - 2017-02-03 23:39:23 --> Helper loaded: url_helper
INFO - 2017-02-03 23:39:23 --> Helper loaded: file_helper
INFO - 2017-02-03 23:39:23 --> Database Driver Class Initialized
INFO - 2017-02-03 23:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:39:23 --> Pagination Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Model Class Initialized
INFO - 2017-02-03 23:39:23 --> Controller Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:39:23 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:39:23 --> Final output sent to browser
DEBUG - 2017-02-03 23:39:23 --> Total execution time: 0.0100
INFO - 2017-02-03 23:39:23 --> Config Class Initialized
INFO - 2017-02-03 23:39:23 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:39:23 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:39:23 --> Utf8 Class Initialized
INFO - 2017-02-03 23:39:23 --> URI Class Initialized
INFO - 2017-02-03 23:39:23 --> Router Class Initialized
INFO - 2017-02-03 23:39:23 --> Output Class Initialized
INFO - 2017-02-03 23:39:23 --> Security Class Initialized
DEBUG - 2017-02-03 23:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:39:23 --> Input Class Initialized
INFO - 2017-02-03 23:39:23 --> Language Class Initialized
ERROR - 2017-02-03 23:39:23 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:39:24 --> Config Class Initialized
INFO - 2017-02-03 23:39:24 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:39:24 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:39:24 --> Utf8 Class Initialized
INFO - 2017-02-03 23:39:24 --> URI Class Initialized
INFO - 2017-02-03 23:39:24 --> Router Class Initialized
INFO - 2017-02-03 23:39:24 --> Output Class Initialized
INFO - 2017-02-03 23:39:24 --> Security Class Initialized
DEBUG - 2017-02-03 23:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:39:24 --> Input Class Initialized
INFO - 2017-02-03 23:39:24 --> Language Class Initialized
ERROR - 2017-02-03 23:39:24 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:40:33 --> Config Class Initialized
INFO - 2017-02-03 23:40:33 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:33 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:33 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:33 --> URI Class Initialized
INFO - 2017-02-03 23:40:33 --> Router Class Initialized
INFO - 2017-02-03 23:40:33 --> Output Class Initialized
INFO - 2017-02-03 23:40:33 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:33 --> Input Class Initialized
INFO - 2017-02-03 23:40:33 --> Language Class Initialized
INFO - 2017-02-03 23:40:33 --> Language Class Initialized
INFO - 2017-02-03 23:40:33 --> Config Class Initialized
INFO - 2017-02-03 23:40:33 --> Loader Class Initialized
INFO - 2017-02-03 23:40:33 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:33 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:33 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:33 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:33 --> Model Class Initialized
INFO - 2017-02-03 23:40:33 --> Model Class Initialized
INFO - 2017-02-03 23:40:33 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:33 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:34 --> Total execution time: 0.0495
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:34 --> URI Class Initialized
INFO - 2017-02-03 23:40:34 --> Router Class Initialized
INFO - 2017-02-03 23:40:34 --> Output Class Initialized
INFO - 2017-02-03 23:40:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:34 --> Input Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Loader Class Initialized
INFO - 2017-02-03 23:40:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:34 --> URI Class Initialized
INFO - 2017-02-03 23:40:34 --> Router Class Initialized
INFO - 2017-02-03 23:40:34 --> Output Class Initialized
INFO - 2017-02-03 23:40:34 --> Security Class Initialized
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:34 --> Hooks Class Initialized
INFO - 2017-02-03 23:40:34 --> Input Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
DEBUG - 2017-02-03 23:40:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
INFO - 2017-02-03 23:40:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Loader Class Initialized
INFO - 2017-02-03 23:40:34 --> URI Class Initialized
INFO - 2017-02-03 23:40:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Router Class Initialized
INFO - 2017-02-03 23:40:34 --> Hooks Class Initialized
INFO - 2017-02-03 23:40:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:34 --> Output Class Initialized
DEBUG - 2017-02-03 23:40:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:34 --> Input Class Initialized
INFO - 2017-02-03 23:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
INFO - 2017-02-03 23:40:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:40:34 --> Loader Class Initialized
INFO - 2017-02-03 23:40:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:34 --> URI Class Initialized
INFO - 2017-02-03 23:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:34 --> Router Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Controller Class Initialized
INFO - 2017-02-03 23:40:34 --> Output Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:40:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:34 --> Input Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Loader Class Initialized
INFO - 2017-02-03 23:40:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Model Class Initialized
INFO - 2017-02-03 23:40:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:34 --> URI Class Initialized
INFO - 2017-02-03 23:40:34 --> Router Class Initialized
INFO - 2017-02-03 23:40:34 --> Output Class Initialized
INFO - 2017-02-03 23:40:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:34 --> Input Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
ERROR - 2017-02-03 23:40:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:34 --> Total execution time: 0.0229
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:34 --> Total execution time: 0.0272
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:34 --> Total execution time: 0.0313
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:34 --> Total execution time: 0.0718
INFO - 2017-02-03 23:40:34 --> Config Class Initialized
INFO - 2017-02-03 23:40:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:34 --> URI Class Initialized
INFO - 2017-02-03 23:40:34 --> Router Class Initialized
INFO - 2017-02-03 23:40:34 --> Output Class Initialized
INFO - 2017-02-03 23:40:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:34 --> Input Class Initialized
INFO - 2017-02-03 23:40:34 --> Language Class Initialized
ERROR - 2017-02-03 23:40:34 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:57 --> URI Class Initialized
INFO - 2017-02-03 23:40:57 --> Router Class Initialized
INFO - 2017-02-03 23:40:57 --> Output Class Initialized
INFO - 2017-02-03 23:40:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:57 --> Input Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Loader Class Initialized
INFO - 2017-02-03 23:40:57 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:57 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:57 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:57 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:57 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:57 --> Total execution time: 0.0167
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:57 --> URI Class Initialized
INFO - 2017-02-03 23:40:57 --> Router Class Initialized
INFO - 2017-02-03 23:40:57 --> Output Class Initialized
INFO - 2017-02-03 23:40:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:57 --> Input Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Loader Class Initialized
INFO - 2017-02-03 23:40:57 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:57 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:57 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:57 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:57 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:57 --> Total execution time: 0.0101
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:57 --> URI Class Initialized
INFO - 2017-02-03 23:40:57 --> Router Class Initialized
INFO - 2017-02-03 23:40:57 --> Output Class Initialized
INFO - 2017-02-03 23:40:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:57 --> Input Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Loader Class Initialized
INFO - 2017-02-03 23:40:57 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:57 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:57 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:57 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:57 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:57 --> Total execution time: 0.0117
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:57 --> URI Class Initialized
INFO - 2017-02-03 23:40:57 --> Router Class Initialized
INFO - 2017-02-03 23:40:57 --> Output Class Initialized
INFO - 2017-02-03 23:40:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:57 --> Input Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Loader Class Initialized
INFO - 2017-02-03 23:40:57 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:57 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:57 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:57 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:57 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:57 --> Total execution time: 0.0105
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:57 --> URI Class Initialized
INFO - 2017-02-03 23:40:57 --> Router Class Initialized
INFO - 2017-02-03 23:40:57 --> Output Class Initialized
INFO - 2017-02-03 23:40:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:57 --> Input Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Loader Class Initialized
INFO - 2017-02-03 23:40:57 --> Helper loaded: url_helper
INFO - 2017-02-03 23:40:57 --> Helper loaded: file_helper
INFO - 2017-02-03 23:40:57 --> Database Driver Class Initialized
INFO - 2017-02-03 23:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:40:57 --> Pagination Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Model Class Initialized
INFO - 2017-02-03 23:40:57 --> Controller Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:40:57 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:40:57 --> Final output sent to browser
DEBUG - 2017-02-03 23:40:57 --> Total execution time: 0.0120
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:57 --> URI Class Initialized
INFO - 2017-02-03 23:40:57 --> Router Class Initialized
INFO - 2017-02-03 23:40:57 --> Output Class Initialized
INFO - 2017-02-03 23:40:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:57 --> Input Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
ERROR - 2017-02-03 23:40:57 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:40:57 --> Config Class Initialized
INFO - 2017-02-03 23:40:57 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:40:57 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:40:57 --> Utf8 Class Initialized
INFO - 2017-02-03 23:40:57 --> URI Class Initialized
INFO - 2017-02-03 23:40:57 --> Router Class Initialized
INFO - 2017-02-03 23:40:57 --> Output Class Initialized
INFO - 2017-02-03 23:40:57 --> Security Class Initialized
DEBUG - 2017-02-03 23:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:40:57 --> Input Class Initialized
INFO - 2017-02-03 23:40:57 --> Language Class Initialized
ERROR - 2017-02-03 23:40:57 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:26 --> URI Class Initialized
INFO - 2017-02-03 23:41:26 --> Router Class Initialized
INFO - 2017-02-03 23:41:26 --> Output Class Initialized
INFO - 2017-02-03 23:41:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:26 --> Input Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Loader Class Initialized
INFO - 2017-02-03 23:41:26 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:26 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:26 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:26 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:26 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:26 --> Total execution time: 0.0457
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:26 --> URI Class Initialized
INFO - 2017-02-03 23:41:26 --> Router Class Initialized
INFO - 2017-02-03 23:41:26 --> Output Class Initialized
INFO - 2017-02-03 23:41:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:26 --> Input Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
ERROR - 2017-02-03 23:41:26 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:26 --> URI Class Initialized
INFO - 2017-02-03 23:41:26 --> Router Class Initialized
INFO - 2017-02-03 23:41:26 --> Output Class Initialized
INFO - 2017-02-03 23:41:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:26 --> Input Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Loader Class Initialized
INFO - 2017-02-03 23:41:26 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:26 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:26 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:26 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:26 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:26 --> Total execution time: 0.0549
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:26 --> URI Class Initialized
INFO - 2017-02-03 23:41:26 --> Router Class Initialized
INFO - 2017-02-03 23:41:26 --> Output Class Initialized
INFO - 2017-02-03 23:41:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:26 --> Input Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Loader Class Initialized
INFO - 2017-02-03 23:41:26 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:26 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:26 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:26 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:26 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:26 --> Total execution time: 0.0098
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:26 --> URI Class Initialized
INFO - 2017-02-03 23:41:26 --> Router Class Initialized
INFO - 2017-02-03 23:41:26 --> Output Class Initialized
INFO - 2017-02-03 23:41:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:26 --> Input Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Loader Class Initialized
INFO - 2017-02-03 23:41:26 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:26 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:26 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:26 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:26 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:26 --> Total execution time: 0.0120
INFO - 2017-02-03 23:41:26 --> URI Class Initialized
INFO - 2017-02-03 23:41:26 --> Router Class Initialized
INFO - 2017-02-03 23:41:26 --> Output Class Initialized
INFO - 2017-02-03 23:41:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:26 --> Input Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Loader Class Initialized
INFO - 2017-02-03 23:41:26 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:26 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:26 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:26 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Model Class Initialized
INFO - 2017-02-03 23:41:26 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:26 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:26 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:26 --> Total execution time: 0.0106
INFO - 2017-02-03 23:41:26 --> Config Class Initialized
INFO - 2017-02-03 23:41:26 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:26 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:26 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:26 --> URI Class Initialized
INFO - 2017-02-03 23:41:26 --> Router Class Initialized
INFO - 2017-02-03 23:41:26 --> Output Class Initialized
INFO - 2017-02-03 23:41:26 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:26 --> Input Class Initialized
INFO - 2017-02-03 23:41:26 --> Language Class Initialized
ERROR - 2017-02-03 23:41:26 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:34 --> URI Class Initialized
INFO - 2017-02-03 23:41:34 --> Router Class Initialized
INFO - 2017-02-03 23:41:34 --> Output Class Initialized
INFO - 2017-02-03 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:34 --> Input Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Loader Class Initialized
INFO - 2017-02-03 23:41:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:34 --> Total execution time: 0.0203
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:34 --> URI Class Initialized
INFO - 2017-02-03 23:41:34 --> Router Class Initialized
INFO - 2017-02-03 23:41:34 --> Output Class Initialized
INFO - 2017-02-03 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:34 --> Input Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Loader Class Initialized
INFO - 2017-02-03 23:41:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:34 --> URI Class Initialized
INFO - 2017-02-03 23:41:34 --> Router Class Initialized
INFO - 2017-02-03 23:41:34 --> Output Class Initialized
INFO - 2017-02-03 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:34 --> Input Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Loader Class Initialized
INFO - 2017-02-03 23:41:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:34 --> Total execution time: 0.0260
INFO - 2017-02-03 23:41:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:34 --> Total execution time: 0.0176
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:34 --> URI Class Initialized
INFO - 2017-02-03 23:41:34 --> Router Class Initialized
INFO - 2017-02-03 23:41:34 --> Output Class Initialized
INFO - 2017-02-03 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:34 --> Input Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Loader Class Initialized
INFO - 2017-02-03 23:41:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:34 --> URI Class Initialized
INFO - 2017-02-03 23:41:34 --> Router Class Initialized
INFO - 2017-02-03 23:41:34 --> Output Class Initialized
INFO - 2017-02-03 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:34 --> Input Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
ERROR - 2017-02-03 23:41:34 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:34 --> URI Class Initialized
INFO - 2017-02-03 23:41:34 --> Router Class Initialized
INFO - 2017-02-03 23:41:34 --> Output Class Initialized
INFO - 2017-02-03 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:34 --> Input Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Loader Class Initialized
INFO - 2017-02-03 23:41:34 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:34 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:34 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:34 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Model Class Initialized
INFO - 2017-02-03 23:41:34 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
INFO - 2017-02-03 23:41:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:34 --> Total execution time: 0.0275
DEBUG - 2017-02-03 23:41:34 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:34 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:34 --> Total execution time: 0.0100
INFO - 2017-02-03 23:41:34 --> Config Class Initialized
INFO - 2017-02-03 23:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:34 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:34 --> URI Class Initialized
INFO - 2017-02-03 23:41:34 --> Router Class Initialized
INFO - 2017-02-03 23:41:34 --> Output Class Initialized
INFO - 2017-02-03 23:41:34 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:34 --> Input Class Initialized
INFO - 2017-02-03 23:41:34 --> Language Class Initialized
ERROR - 2017-02-03 23:41:34 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:40 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:40 --> URI Class Initialized
INFO - 2017-02-03 23:41:40 --> Router Class Initialized
INFO - 2017-02-03 23:41:40 --> Output Class Initialized
INFO - 2017-02-03 23:41:40 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:40 --> Input Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Loader Class Initialized
INFO - 2017-02-03 23:41:40 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:40 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:40 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:40 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:40 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:40 --> Total execution time: 0.3461
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:40 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:40 --> URI Class Initialized
INFO - 2017-02-03 23:41:40 --> Router Class Initialized
INFO - 2017-02-03 23:41:40 --> Output Class Initialized
INFO - 2017-02-03 23:41:40 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:40 --> Input Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Loader Class Initialized
INFO - 2017-02-03 23:41:40 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:40 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:40 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:40 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:40 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:40 --> Total execution time: 0.0110
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:40 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:40 --> URI Class Initialized
INFO - 2017-02-03 23:41:40 --> Router Class Initialized
INFO - 2017-02-03 23:41:40 --> Output Class Initialized
INFO - 2017-02-03 23:41:40 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:40 --> Input Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Loader Class Initialized
INFO - 2017-02-03 23:41:40 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:40 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:40 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:40 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:40 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:40 --> Total execution time: 0.0200
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:40 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:40 --> URI Class Initialized
INFO - 2017-02-03 23:41:40 --> Router Class Initialized
INFO - 2017-02-03 23:41:40 --> Output Class Initialized
INFO - 2017-02-03 23:41:40 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:40 --> Input Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Loader Class Initialized
INFO - 2017-02-03 23:41:40 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:40 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:40 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:40 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:40 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:40 --> Total execution time: 0.0106
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:40 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:40 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:40 --> URI Class Initialized
INFO - 2017-02-03 23:41:40 --> Router Class Initialized
INFO - 2017-02-03 23:41:40 --> Output Class Initialized
INFO - 2017-02-03 23:41:40 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:40 --> Input Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Language Class Initialized
INFO - 2017-02-03 23:41:40 --> Config Class Initialized
INFO - 2017-02-03 23:41:40 --> Loader Class Initialized
INFO - 2017-02-03 23:41:40 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:40 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:40 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:40 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Model Class Initialized
INFO - 2017-02-03 23:41:40 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:40 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:40 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:40 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:40 --> Total execution time: 0.0157
INFO - 2017-02-03 23:41:41 --> Config Class Initialized
INFO - 2017-02-03 23:41:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:41 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:41 --> URI Class Initialized
INFO - 2017-02-03 23:41:41 --> Router Class Initialized
INFO - 2017-02-03 23:41:41 --> Output Class Initialized
INFO - 2017-02-03 23:41:41 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:41 --> Input Class Initialized
INFO - 2017-02-03 23:41:41 --> Language Class Initialized
ERROR - 2017-02-03 23:41:41 --> 404 Page Not Found: /index
INFO - 2017-02-03 23:41:41 --> Config Class Initialized
INFO - 2017-02-03 23:41:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:41 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:41 --> URI Class Initialized
INFO - 2017-02-03 23:41:41 --> Router Class Initialized
INFO - 2017-02-03 23:41:41 --> Output Class Initialized
INFO - 2017-02-03 23:41:41 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:41 --> Input Class Initialized
INFO - 2017-02-03 23:41:41 --> Language Class Initialized
INFO - 2017-02-03 23:41:41 --> Language Class Initialized
INFO - 2017-02-03 23:41:41 --> Config Class Initialized
INFO - 2017-02-03 23:41:41 --> Config Class Initialized
INFO - 2017-02-03 23:41:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:41 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:41 --> URI Class Initialized
INFO - 2017-02-03 23:41:41 --> Router Class Initialized
INFO - 2017-02-03 23:41:41 --> Output Class Initialized
INFO - 2017-02-03 23:41:41 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:41 --> Input Class Initialized
INFO - 2017-02-03 23:41:41 --> Language Class Initialized
INFO - 2017-02-03 23:41:41 --> Language Class Initialized
INFO - 2017-02-03 23:41:41 --> Config Class Initialized
INFO - 2017-02-03 23:41:41 --> Loader Class Initialized
INFO - 2017-02-03 23:41:41 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:41 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:41 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:41 --> Loader Class Initialized
INFO - 2017-02-03 23:41:41 --> Helper loaded: url_helper
INFO - 2017-02-03 23:41:41 --> Helper loaded: file_helper
INFO - 2017-02-03 23:41:41 --> Database Driver Class Initialized
INFO - 2017-02-03 23:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:41 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:41 --> Model Class Initialized
INFO - 2017-02-03 23:41:41 --> Model Class Initialized
INFO - 2017-02-03 23:41:41 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:41 --> Kategori MX_Controller Initialized
INFO - 2017-02-03 23:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-03 23:41:41 --> Pagination Class Initialized
INFO - 2017-02-03 23:41:41 --> Model Class Initialized
INFO - 2017-02-03 23:41:41 --> Model Class Initialized
INFO - 2017-02-03 23:41:41 --> Controller Class Initialized
DEBUG - 2017-02-03 23:41:41 --> Kategori MX_Controller Initialized
DEBUG - 2017-02-03 23:41:41 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
DEBUG - 2017-02-03 23:41:41 --> File loaded: /var/www/html/wartabandung/application/views/index.php
DEBUG - 2017-02-03 23:41:41 --> File loaded: /var/www/html/wartabandung/application/modules/kategori/views/kategori_view.php
INFO - 2017-02-03 23:41:41 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:41 --> Total execution time: 0.0232
DEBUG - 2017-02-03 23:41:41 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-03 23:41:41 --> Final output sent to browser
DEBUG - 2017-02-03 23:41:41 --> Total execution time: 0.0217
INFO - 2017-02-03 23:41:41 --> Config Class Initialized
INFO - 2017-02-03 23:41:41 --> Hooks Class Initialized
DEBUG - 2017-02-03 23:41:41 --> UTF-8 Support Enabled
INFO - 2017-02-03 23:41:41 --> Utf8 Class Initialized
INFO - 2017-02-03 23:41:41 --> URI Class Initialized
INFO - 2017-02-03 23:41:41 --> Router Class Initialized
INFO - 2017-02-03 23:41:41 --> Output Class Initialized
INFO - 2017-02-03 23:41:41 --> Security Class Initialized
DEBUG - 2017-02-03 23:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-03 23:41:41 --> Input Class Initialized
INFO - 2017-02-03 23:41:41 --> Language Class Initialized
ERROR - 2017-02-03 23:41:41 --> 404 Page Not Found: /index
