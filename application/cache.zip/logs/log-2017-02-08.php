<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-08 21:25:57 --> Config Class Initialized
INFO - 2017-02-08 21:25:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:25:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:25:57 --> Utf8 Class Initialized
INFO - 2017-02-08 21:25:57 --> URI Class Initialized
DEBUG - 2017-02-08 21:25:58 --> No URI present. Default controller set.
INFO - 2017-02-08 21:25:58 --> Router Class Initialized
INFO - 2017-02-08 21:25:58 --> Output Class Initialized
INFO - 2017-02-08 21:25:58 --> Security Class Initialized
DEBUG - 2017-02-08 21:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:25:58 --> Input Class Initialized
INFO - 2017-02-08 21:25:58 --> Language Class Initialized
INFO - 2017-02-08 21:25:58 --> Language Class Initialized
INFO - 2017-02-08 21:25:58 --> Config Class Initialized
INFO - 2017-02-08 21:25:58 --> Loader Class Initialized
INFO - 2017-02-08 21:25:58 --> Helper loaded: url_helper
INFO - 2017-02-08 21:25:58 --> Helper loaded: file_helper
INFO - 2017-02-08 21:25:58 --> Database Driver Class Initialized
INFO - 2017-02-08 21:25:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-08 21:25:58 --> Pagination Class Initialized
INFO - 2017-02-08 21:25:58 --> Model Class Initialized
INFO - 2017-02-08 21:25:58 --> Model Class Initialized
INFO - 2017-02-08 21:25:58 --> Controller Class Initialized
DEBUG - 2017-02-08 21:25:58 --> Welcome MX_Controller Initialized
ERROR - 2017-02-08 21:25:58 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:25:59 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-08 21:25:59 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-08 21:25:59 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-08 21:25:59 --> Final output sent to browser
DEBUG - 2017-02-08 21:25:59 --> Total execution time: 1.4712
INFO - 2017-02-08 21:25:59 --> Config Class Initialized
INFO - 2017-02-08 21:25:59 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:25:59 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:25:59 --> Utf8 Class Initialized
INFO - 2017-02-08 21:25:59 --> URI Class Initialized
INFO - 2017-02-08 21:26:00 --> Router Class Initialized
INFO - 2017-02-08 21:26:00 --> Output Class Initialized
INFO - 2017-02-08 21:26:00 --> Security Class Initialized
DEBUG - 2017-02-08 21:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:26:00 --> Input Class Initialized
INFO - 2017-02-08 21:26:00 --> Language Class Initialized
ERROR - 2017-02-08 21:26:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 21:26:06 --> Config Class Initialized
INFO - 2017-02-08 21:26:06 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:26:06 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:26:06 --> Utf8 Class Initialized
INFO - 2017-02-08 21:26:06 --> URI Class Initialized
DEBUG - 2017-02-08 21:26:06 --> No URI present. Default controller set.
INFO - 2017-02-08 21:26:06 --> Router Class Initialized
INFO - 2017-02-08 21:26:06 --> Output Class Initialized
INFO - 2017-02-08 21:26:06 --> Security Class Initialized
DEBUG - 2017-02-08 21:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:26:06 --> Input Class Initialized
INFO - 2017-02-08 21:26:06 --> Language Class Initialized
INFO - 2017-02-08 21:26:06 --> Language Class Initialized
INFO - 2017-02-08 21:26:06 --> Config Class Initialized
INFO - 2017-02-08 21:26:06 --> Loader Class Initialized
INFO - 2017-02-08 21:26:06 --> Helper loaded: url_helper
INFO - 2017-02-08 21:26:06 --> Helper loaded: file_helper
INFO - 2017-02-08 21:26:06 --> Database Driver Class Initialized
INFO - 2017-02-08 21:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-08 21:26:06 --> Pagination Class Initialized
INFO - 2017-02-08 21:26:06 --> Model Class Initialized
INFO - 2017-02-08 21:26:06 --> Model Class Initialized
INFO - 2017-02-08 21:26:06 --> Controller Class Initialized
DEBUG - 2017-02-08 21:26:06 --> Welcome MX_Controller Initialized
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: id /var/www/html/wartabandung/application/models/Main_model.php 115
ERROR - 2017-02-08 21:26:06 --> Severity: Notice --> Undefined index: judul /var/www/html/wartabandung/application/models/Main_model.php 115
DEBUG - 2017-02-08 21:26:06 --> File loaded: /var/www/html/wartabandung/application/modules/Welcome/views/home.php
DEBUG - 2017-02-08 21:26:06 --> File loaded: /var/www/html/wartabandung/application/views/index.php
INFO - 2017-02-08 21:26:06 --> Final output sent to browser
DEBUG - 2017-02-08 21:26:06 --> Total execution time: 0.1312
INFO - 2017-02-08 21:26:06 --> Config Class Initialized
INFO - 2017-02-08 21:26:06 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:26:06 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:26:06 --> Utf8 Class Initialized
INFO - 2017-02-08 21:26:06 --> URI Class Initialized
INFO - 2017-02-08 21:26:06 --> Router Class Initialized
INFO - 2017-02-08 21:26:06 --> Output Class Initialized
INFO - 2017-02-08 21:26:06 --> Security Class Initialized
DEBUG - 2017-02-08 21:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:26:06 --> Input Class Initialized
INFO - 2017-02-08 21:26:06 --> Language Class Initialized
ERROR - 2017-02-08 21:26:06 --> 404 Page Not Found: /index
INFO - 2017-02-08 21:26:14 --> Config Class Initialized
INFO - 2017-02-08 21:26:14 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:26:15 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:26:15 --> Utf8 Class Initialized
INFO - 2017-02-08 21:26:15 --> URI Class Initialized
INFO - 2017-02-08 21:26:15 --> Router Class Initialized
INFO - 2017-02-08 21:26:15 --> Output Class Initialized
INFO - 2017-02-08 21:26:15 --> Security Class Initialized
DEBUG - 2017-02-08 21:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:26:15 --> Input Class Initialized
INFO - 2017-02-08 21:26:15 --> Language Class Initialized
INFO - 2017-02-08 21:26:15 --> Language Class Initialized
INFO - 2017-02-08 21:26:15 --> Config Class Initialized
INFO - 2017-02-08 21:26:15 --> Loader Class Initialized
INFO - 2017-02-08 21:26:15 --> Helper loaded: url_helper
INFO - 2017-02-08 21:26:15 --> Helper loaded: file_helper
INFO - 2017-02-08 21:26:15 --> Database Driver Class Initialized
INFO - 2017-02-08 21:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-08 21:26:15 --> Pagination Class Initialized
INFO - 2017-02-08 21:26:15 --> Model Class Initialized
INFO - 2017-02-08 21:26:15 --> Model Class Initialized
INFO - 2017-02-08 21:26:15 --> Controller Class Initialized
ERROR - 2017-02-08 21:26:15 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
INFO - 2017-02-08 21:27:10 --> Config Class Initialized
INFO - 2017-02-08 21:27:10 --> Hooks Class Initialized
DEBUG - 2017-02-08 21:27:10 --> UTF-8 Support Enabled
INFO - 2017-02-08 21:27:10 --> Utf8 Class Initialized
INFO - 2017-02-08 21:27:10 --> URI Class Initialized
INFO - 2017-02-08 21:27:10 --> Router Class Initialized
INFO - 2017-02-08 21:27:10 --> Output Class Initialized
INFO - 2017-02-08 21:27:10 --> Security Class Initialized
DEBUG - 2017-02-08 21:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 21:27:10 --> Input Class Initialized
INFO - 2017-02-08 21:27:10 --> Language Class Initialized
INFO - 2017-02-08 21:27:10 --> Language Class Initialized
INFO - 2017-02-08 21:27:10 --> Config Class Initialized
INFO - 2017-02-08 21:27:10 --> Loader Class Initialized
INFO - 2017-02-08 21:27:10 --> Helper loaded: url_helper
INFO - 2017-02-08 21:27:10 --> Helper loaded: file_helper
INFO - 2017-02-08 21:27:10 --> Database Driver Class Initialized
INFO - 2017-02-08 21:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-02-08 21:27:10 --> Pagination Class Initialized
INFO - 2017-02-08 21:27:10 --> Model Class Initialized
INFO - 2017-02-08 21:27:10 --> Model Class Initialized
INFO - 2017-02-08 21:27:10 --> Controller Class Initialized
ERROR - 2017-02-08 21:27:10 --> 404 Page Not Found: ../modules/kategori/controllers/Kategori/ekonomi
