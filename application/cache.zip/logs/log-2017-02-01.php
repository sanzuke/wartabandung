<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-01 04:29:24 --> Config Class Initialized
INFO - 2017-02-01 04:29:24 --> Hooks Class Initialized
DEBUG - 2017-02-01 04:29:24 --> UTF-8 Support Enabled
INFO - 2017-02-01 04:29:24 --> Utf8 Class Initialized
INFO - 2017-02-01 04:29:24 --> URI Class Initialized
DEBUG - 2017-02-01 04:29:24 --> No URI present. Default controller set.
INFO - 2017-02-01 04:29:24 --> Router Class Initialized
INFO - 2017-02-01 04:29:24 --> Output Class Initialized
INFO - 2017-02-01 04:29:24 --> Security Class Initialized
DEBUG - 2017-02-01 04:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-01 04:29:24 --> Input Class Initialized
INFO - 2017-02-01 04:29:24 --> Language Class Initialized
INFO - 2017-02-01 04:29:24 --> Language Class Initialized
INFO - 2017-02-01 04:29:24 --> Config Class Initialized
INFO - 2017-02-01 04:29:24 --> Loader Class Initialized
INFO - 2017-02-01 04:29:24 --> Controller Class Initialized
DEBUG - 2017-02-01 04:29:24 --> Welcome MX_Controller Initialized
DEBUG - 2017-02-01 04:29:24 --> File loaded: /var/www/html/wb/application/modules/Welcome/views/welcome_message.php
INFO - 2017-02-01 04:29:24 --> Final output sent to browser
DEBUG - 2017-02-01 04:29:24 --> Total execution time: 0.2287
